const fs = require('fs');
const path = require('path');

console.log('Generating CDN-based standalone single-file index.html...');

const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="google-site-verification" content="EMgd5TyH0VFBG-ilgNt9UieXuwUcWIizscwhifoxy5M" />
  <title>كتب سومر - موسوعة سومر المهنية</title>
  <meta name="description" content="منصة وموسوعة كتب مدرسة سومر المهنية لجميع الأقسام والمراحل مع لوحة تحكم لنشر الكتب سحابياً ومحلياً.">

  <!-- Google Fonts: Tajawal with fallback to standard Windows Arabic fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">

  <!-- External CDN: Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    if (window.tailwind) {
      tailwind.config = {
        darkMode: 'class',
        theme: {
          extend: {
            fontFamily: {
              sans: ['Tajawal', 'Segoe UI', 'Tahoma', 'Arial', 'sans-serif'],
            },
            colors: {
              teal: {
                50: '#f0fdfa',
                100: '#ccfbf1',
                200: '#99f6e4',
                500: '#14b8a6',
                600: '#0d9488',
                700: '#0f766e',
                800: '#115e59',
                900: '#134e4a',
                950: '#042f2e',
              }
            }
          }
        }
      };
    }
  </script>

  <!-- External CDN: React 18 & ReactDOM 18 (Universal UMD - works on file:/// in Windows 7) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js"></script>
  <!-- Framer Motion -->
  <script src="https://cdn.jsdelivr.net/npm/framer-motion@12.4.7/dist/framer-motion.js"></script>

  <!-- External CDN: Google Firebase SDK (Compat Version - supports custom databaseId and file:/// protocol) -->
  <script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore-compat.js"></script>

  <style>
    body {
      font-family: 'Tajawal', 'Segoe UI', Tahoma, Arial, sans-serif;
      background-color: #f8fafc;
      color: #0f172a;
      margin: 0;
      padding: 0;
      -webkit-font-smoothing: antialiased;
    }
    /* Fallback styles if Tailwind CDN is slow or offline */
    .container-custom {
      max-width: 1280px;
      margin-left: auto;
      margin-right: auto;
      padding-left: 1rem;
      padding-right: 1rem;
    }
    /* Smooth transitions */
    .btn-transition {
      transition: all 0.2s ease-in-out;
    }
    /* Custom scrollbar */
    ::-webkit-scrollbar {
      width: 8px;
      height: 8px;
    }
    ::-webkit-scrollbar-track {
      background: #f1f5f9;
    }
    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
  </style>
</head>
<body class="bg-slate-50 text-slate-900 min-h-screen selection:bg-teal-500 selection:text-white">
  <div id="root">
    <!-- Initial Loading State to prevent white screen while libraries load -->
    <div style="min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: sans-serif; direction: rtl; text-align: center; padding: 20px;">
      <div style="width: 50px; height: 50px; border: 4px solid #ccfbf1; border-top-color: #0d9488; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 16px;"></div>
      <h2 style="color: #0f766e; font-size: 20px; font-weight: bold; margin: 0 0 8px 0;">موسوعة كتب مدرسة سومر المهنية</h2>
      <p style="color: #64748b; font-size: 14px; margin: 0;">جاري تحميل المكتبة والاتصال بالسحابة...</p>
      <style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>
    </div>
  </div>

  <!-- Application Logic (Pure JavaScript without JSX, compatible with any browser) -->
  <script>
  (function() {
    // Check for React availability
    if (typeof React === 'undefined' || typeof ReactDOM === 'undefined') {
      document.getElementById('root').innerHTML = 
        '<div style="direction: rtl; text-align: center; padding: 40px; font-family: sans-serif;">' +
        '<h2 style="color: #e11d48;">تنبيه: تعذر تحميل مكتبة React</h2>' +
        '<p style="color: #475569;">يرجى التأكد من توفر اتصال بالإنترنت لتحميل روابط CDN الخارجية عند أول تشغيل.</p>' +
        '<button onclick="location.reload()" style="margin-top: 15px; padding: 8px 20px; background: #0d9488; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">إعادة المحاولة</button>' +
        '</div>';
      return;
    }

    var h = React.createElement;
    var useState = React.useState;
    var useEffect = React.useEffect;
    var useMemo = React.useMemo;

    // Firebase Configuration
    var FIREBASE_CONFIG = {
      projectId: "gen-lang-client-0292048732",
      appId: "1:344232365181:web:012f3dadc7042122193514",
      apiKey: "AIzaSyCQBHzGbUtaaztZFkxzbOAZMsMFKqz-Vv8",
      authDomain: "gen-lang-client-0292048732.firebaseapp.com",
      firestoreDatabaseId: "ai-studio-6011411e-9969-4642-842a-5a9a1e8f9a69",
      storageBucket: "gen-lang-client-0292048732.firebasestorage.app",
      messagingSenderId: "344232365181"
    };

    var db = null;
    try {
      if (typeof firebase !== 'undefined') {
        if (!firebase.apps.length) {
          firebase.initializeApp(FIREBASE_CONFIG);
        }
        var app = firebase.app();
        if (FIREBASE_CONFIG.firestoreDatabaseId && FIREBASE_CONFIG.firestoreDatabaseId !== '(default)') {
          db = app.firestore(FIREBASE_CONFIG.firestoreDatabaseId);
        } else {
          db = app.firestore();
        }
      }
    } catch (e) {
      console.warn('Firebase initialization notice:', e);
    }

    // Departments Configuration
    var DEPARTMENTS = [
      {
        id: 'إلكترونيك السيطرة والخزن',
        name: 'إلكترونيك السيطرة والخزن',
        subTitle: 'مناهج هندسة السيطرة والأنظمة الإلكترونية',
        description: 'العلوم الصناعية، الرسم الصناعي، التدريب العملي، وسيطرة القوى الحديثة.',
        color: 'text-sky-600',
        bgColor: 'bg-sky-50',
        border: 'hover:border-sky-400',
        badge: 'bg-sky-100 text-sky-800',
        svgIcon: function(props) {
          return h('svg', { className: props.className || 'w-6 h-6', viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: '2', strokeLinecap: 'round', strokeLinejoin: 'round' },
            h('rect', { x: '4', y: '4', width: '16', height: '16', rx: '2' }),
            h('rect', { x: '9', y: '9', width: '6', height: '6' }),
            h('line', { x1: '9', y1: '1', x2: '9', y2: '4' }),
            h('line', { x1: '15', y1: '1', x2: '15', y2: '4' }),
            h('line', { x1: '9', y1: '20', x2: '9', y2: '23' }),
            h('line', { x1: '15', y1: '20', x2: '15', y2: '23' }),
            h('line', { x1: '20', y1: '9', x2: '23', y2: '9' }),
            h('line', { x1: '20', y1: '14', x2: '23', y2: '14' }),
            h('line', { x1: '1', y1: '9', x2: '4', y2: '9' }),
            h('line', { x1: '1', y1: '14', x2: '4', y2: '14' })
          );
        }
      },
      {
        id: 'الكهرباء',
        name: 'قسم الكهرباء',
        subTitle: 'هندسة القوى والآلات والشبكات الكهربائية',
        description: 'المحركات والمحولات، التمديدات الكهربائية، والتحكم الآلي الصناعي.',
        color: 'text-amber-600',
        bgColor: 'bg-amber-50',
        border: 'hover:border-amber-400',
        badge: 'bg-amber-100 text-amber-800',
        svgIcon: function(props) {
          return h('svg', { className: props.className || 'w-6 h-6', viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: '2', strokeLinecap: 'round', strokeLinejoin: 'round' },
            h('polygon', { points: '13 2 3 14 12 14 11 22 21 10 12 10 13 2' })
          );
        }
      },
      {
        id: 'الأمن السيبراني',
        name: 'قسم الأمن السيبراني',
        subTitle: 'حماية الأنظمة، التشفير والدفاع الرقمي',
        description: 'أساسيات أمن المعلومات، اختبار الاختراق، وحماية البنى التحتية الرقمية.',
        color: 'text-teal-600',
        bgColor: 'bg-teal-50',
        border: 'hover:border-teal-400',
        badge: 'bg-teal-100 text-teal-800',
        svgIcon: function(props) {
          return h('svg', { className: props.className || 'w-6 h-6', viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: '2', strokeLinecap: 'round', strokeLinejoin: 'round' },
            h('path', { d: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z' }),
            h('path', { d: 'M9 12l2 2 4-4' })
          );
        }
      },
      {
        id: 'الحاسبات',
        name: 'قسم الحاسبات',
        subTitle: 'البرمجة، صيانة الحاسوب وهندسة الشبكات',
        description: 'تجميع وصيانة الحواسيب، نظم التشغيل، هياكل البيانات، وهندسة البرمجيات.',
        color: 'text-indigo-600',
        bgColor: 'bg-indigo-50',
        border: 'hover:border-indigo-400',
        badge: 'bg-indigo-100 text-indigo-800',
        svgIcon: function(props) {
          return h('svg', { className: props.className || 'w-6 h-6', viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: '2', strokeLinecap: 'round', strokeLinejoin: 'round' },
            h('rect', { x: '2', y: '3', width: '20', height: '14', rx: '2', ry: '2' }),
            h('line', { x1: '8', y1: '21', x2: '16', y2: '21' }),
            h('line', { x1: '12', y1: '17', x2: '12', y2: '21' })
          );
        }
      }
    ];

    var STAGES = [
      { id: 'المرحلة الأولى', name: 'المرحلة الأولى', desc: 'المرحلة الأولى الإعدادية المهنية' },
      { id: 'المرحلة الثانية', name: 'المرحلة الثانية', desc: 'المرحلة الثانية التخصصية' },
      { id: 'المرحلة الثالثة', name: 'المرحلة الثالثة', desc: 'المرحلة الوزارية المنتهية' }
    ];

    // Local Storage Helpers with try-catch safety
    var LOCAL_STORAGE_KEY = 'sumer_local_books_backup';
    function loadCachedBooks() {
      try {
        var raw = localStorage.getItem(LOCAL_STORAGE_KEY) || localStorage.getItem('sumer_books_library');
        if (raw) {
          var parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            return parsed.filter(function(b) {
              return b && b.id !== 'book-islamic-1' && (!b.url || b.url.indexOf('sample/preview') === -1);
            });
          }
        }
      } catch (e) {
        console.warn('LocalStorage load notice:', e);
      }
      return [];
    }

    function saveCachedBooks(books) {
      try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(books));
      } catch (e) {
        console.warn('LocalStorage save notice:', e);
      }
    }

    // Helper to format Google Drive links to preview
    function formatDriveUrl(url) {
      if (!url) return '';
      var trimmed = url.trim();
      var driveMatch = trimmed.match(/drive\\.google\\.com\\/file\\/d\\/([a-zA-Z0-9_-]+)/);
      if (driveMatch && driveMatch[1]) {
        return 'https://drive.google.com/file/d/' + driveMatch[1] + '/preview';
      }
      return trimmed;
    }

    // Main App Component
    function App() {
      var _booksState = useState(loadCachedBooks());
      var books = _booksState[0];
      var setBooks = _booksState[1];

      var _loadingState = useState(true);
      var isLoading = _loadingState[0];
      var setIsLoading = _loadingState[1];

      var _cloudState = useState(false);
      var isCloudConnected = _cloudState[0];
      var setIsCloudConnected = _cloudState[1];

      var _deptState = useState(null);
      var selectedDept = _deptState[0];
      var setSelectedDept = _deptState[1];

      var _stageState = useState(null);
      var selectedStage = _stageState[0];
      var setSelectedStage = _stageState[1];

      var _searchState = useState('');
      var searchQuery = _searchState[0];
      var setSearchQuery = _searchState[1];

      var _activePdfState = useState(null);
      var activePdf = _activePdfState[0];
      var setActivePdf = _activePdfState[1];

      var _adminOpenState = useState(false);
      var isAdminOpen = _adminOpenState[0];
      var setIsAdminOpen = _adminOpenState[1];

      var _authOpenState = useState(false);
      var isAuthOpen = _authOpenState[0];
      var setIsAuthOpen = _authOpenState[1];

      var _aboutOpenState = useState(false);
      var isAboutOpen = _aboutOpenState[0];
      var setIsAboutOpen = _aboutOpenState[1];

      var _adminPinState = useState(function() {
        try {
          return sessionStorage.getItem('sumer_admin_pin') || localStorage.getItem('sumer_admin_pin') || 'devsomr11';
        } catch(e) { return 'devsomr11'; }
      });
      var adminPin = _adminPinState[0];
      var setAdminPin = _adminPinState[1];

      // Auto check admin parameter in URL
      useEffect(function() {
        try {
          var search = window.location.search || '';
          var hash = window.location.hash || '';
          var path = window.location.pathname || '';
          if (search.indexOf('admin=devsomr11') !== -1 || search.indexOf('pin=devsomr11') !== -1) {
            setIsAdminOpen(true);
            setIsAuthOpen(false);
          } else if (search.indexOf('admin') !== -1 || hash.indexOf('admin') !== -1 || path.indexOf('admin') !== -1) {
            setIsAuthOpen(true);
          }
        } catch(e) {}
      }, []);

      // Form State for Adding Books
      var _formTitle = useState('');
      var formTitle = _formTitle[0];
      var setFormTitle = _formTitle[1];

      var _formDept = useState('إلكترونيك السيطرة والخزن');
      var formDept = _formDept[0];
      var setFormDept = _formDept[1];

      var _formStage = useState('المرحلة الأولى');
      var formStage = _formStage[0];
      var setFormStage = _formStage[1];

      var _formUrl = useState('');
      var formUrl = _formUrl[0];
      var setFormUrl = _formUrl[1];

      var _adminMsgState = useState(null);
      var adminMsg = _adminMsgState[0];
      var setAdminMsg = _adminMsgState[1];

      var _savingState = useState(false);
      var isSaving = _savingState[0];
      var setIsSaving = _savingState[1];

      // Real-time Firestore Cloud Listener
      useEffect(function() {
        var unsubscribe = function() {};

        if (db) {
          try {
            unsubscribe = db.collection('books')
              .orderBy('uploadedAt', 'desc')
              .onSnapshot(function(snapshot) {
                setIsCloudConnected(true);
                var list = [];
                snapshot.forEach(function(docSnap) {
                  var data = docSnap.data();
                  if (docSnap.id === 'book-islamic-1' || (data && data.id === 'book-islamic-1')) return;
                  list.push({
                    id: docSnap.id,
                    title: data.title || '',
                    dept: data.dept || '',
                    stage: data.stage || '',
                    url: data.url || '',
                    fileName: data.fileName,
                    fileSize: data.fileSize,
                    uploadedAt: data.uploadedAt || new Date().toISOString()
                  });
                });

                if (list.length > 0) {
                  setBooks(list);
                  saveCachedBooks(list);
                } else {
                  // Check if we have cached books to restore to cloud
                  var cached = loadCachedBooks();
                  if (cached.length > 0) {
                    setBooks(cached);
                    cached.forEach(function(b) {
                      db.collection('books').doc(b.id).set(b, { merge: true }).catch(function() {});
                    });
                  }
                }
                setIsLoading(false);
              }, function(err) {
                console.warn('Firestore real-time error:', err);
                setIsCloudConnected(false);
                setIsLoading(false);
              });
          } catch (e) {
            console.warn('Failed to listen to Firestore:', e);
            setIsLoading(false);
          }
        } else {
          setIsLoading(false);
        }

        return function() {
          if (typeof unsubscribe === 'function') unsubscribe();
        };
      }, []);

      // Filtered Books
      var filteredBooks = useMemo(function() {
        return books.filter(function(book) {
          if (!book) return false;
          if (selectedDept && book.dept !== selectedDept) return false;
          if (selectedStage && book.stage !== selectedStage) return false;
          if (searchQuery && searchQuery.trim()) {
            var q = searchQuery.toLowerCase().trim();
            var matchTitle = book.title && book.title.toLowerCase().indexOf(q) !== -1;
            var matchDept = book.dept && book.dept.toLowerCase().indexOf(q) !== -1;
            var matchStage = book.stage && book.stage.toLowerCase().indexOf(q) !== -1;
            return matchTitle || matchDept || matchStage;
          }
          return true;
        });
      }, [books, selectedDept, selectedStage, searchQuery]);

      // Handle Add Book
      function handleAddBook(e) {
        e.preventDefault();
        if (!formTitle.trim()) {
          setAdminMsg({ type: 'error', text: 'يرجى إدخال اسم الكتاب.' });
          return;
        }
        if (!formUrl.trim()) {
          setAdminMsg({ type: 'error', text: 'يرجى وضع رابط الكتاب من Google Drive أو رابط مباشر.' });
          return;
        }

        setIsSaving(true);
        setAdminMsg(null);

        var normalizedUrl = formatDriveUrl(formUrl);
        var newBook = {
          id: 'book_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
          title: formTitle.trim(),
          dept: formDept,
          stage: formStage,
          url: normalizedUrl,
          uploadedAt: new Date().toISOString()
        };

        function finalizeSave() {
          var updated = [newBook].concat(books.filter(function(b) { return b.id !== newBook.id; }));
          setBooks(updated);
          saveCachedBooks(updated);
          setFormTitle('');
          setFormUrl('');
          setIsSaving(false);
          setAdminMsg({ type: 'success', text: 'تم حفظ ونشر الكتاب بنجاح!' });
        }

        if (db) {
          db.collection('books').doc(newBook.id).set(newBook)
            .then(function() {
              finalizeSave();
            })
            .catch(function(err) {
              console.warn('Could not save to Cloud Firestore directly:', err);
              finalizeSave();
            });
        } else {
          finalizeSave();
        }
      }

      // Handle Delete Book
      function handleDeleteBook(id) {
        if (!confirm('هل أنت متأكد من حذف هذا الكتاب نهائياً؟')) return;

        var updated = books.filter(function(b) { return b.id !== id; });
        setBooks(updated);
        saveCachedBooks(updated);

        if (db) {
          db.collection('books').doc(id).delete().catch(function(err) {
            console.warn('Error deleting from Firestore:', err);
          });
        }
      }

      // Handle Export Backup
      function handleExportBackup() {
        var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(books, null, 2));
        var downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", "sumer-books-backup-" + new Date().toISOString().slice(0, 10) + ".json");
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
      }

      // Render Top Navigation Bar
      var navbar = h('header', { className: 'bg-white/95 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40 shadow-xs' },
        h('div', { className: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' },
          h('div', { className: 'flex items-center justify-between h-16 sm:h-20 gap-3' },
            // Brand
            h('div', { 
              onClick: function() { setSelectedDept(null); setSelectedStage(null); setSearchQuery(''); },
              className: 'flex items-center gap-3 cursor-pointer group'
            },
              h('div', { className: 'w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-teal-600 text-white flex items-center justify-center font-black text-lg sm:text-xl shadow-md shadow-teal-600/20' },
                'س'
              ),
              h('div', {},
                h('div', { className: 'flex items-center gap-2' },
                  h('h1', { className: 'text-base sm:text-lg font-black text-slate-900 group-hover:text-teal-600 transition-colors' }, 'كتب سومر'),
                  h('span', { className: 'bg-teal-50 text-teal-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-teal-200/60' }, 'مهني')
                ),
                h('p', { className: 'text-xs text-slate-700 font-medium hidden sm:block' }, 'المكتبة الإلكترونية لمدرسة سومر المهنية')
              )
            ),
            // Actions
            h('div', { className: 'flex items-center gap-2 sm:gap-3' },
              // Cloud status indicator
              h('div', { 
                className: 'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold border ' + 
                  (isCloudConnected ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-slate-100 text-slate-700 border-slate-200'),
                title: isCloudConnected ? 'متصل بقاعدة البيانات السحابية المركزية' : 'يعمل عبر الذاكرة المحلية المستقلة'
              },
                h('span', { className: 'w-2 h-2 rounded-full ' + (isCloudConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400') }),
                h('span', {}, isCloudConnected ? 'سحابة مباشرة ☁️' : 'ذاكرة محلية')
              ),
              // About button
              h('button', {
                onClick: function() { setIsAboutOpen(true); },
                className: 'px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors'
              }, 'عن المدرسة'),
              // Admin Panel Toggle
              h('button', {
                onClick: function() {
                  if (isAdminOpen) {
                    setIsAdminOpen(false);
                  } else {
                    if (adminPin === 'devsomr11' || adminPin.length > 0) {
                      setIsAdminOpen(true);
                    } else {
                      setIsAuthOpen(true);
                    }
                  }
                },
                className: 'flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs sm:text-sm shadow-xs transition-all ' +
                  (isAdminOpen ? 'bg-slate-800 text-white' : 'bg-teal-600 text-white hover:bg-teal-700')
              },
                isAdminOpen ? 'إغلاق الإدارة' : 'لوحة الإدارة'
              )
            )
          )
        )
      );

      // Render Search Bar
      var searchSection = h('div', { className: 'mb-8' },
        h('div', { className: 'relative max-w-2xl mx-auto' },
          h('input', {
            type: 'text',
            value: searchQuery,
            onChange: function(e) { setSearchQuery(e.target.value); },
            placeholder: 'ابحث عن أي كتاب، مادة، قسم، أو مرحلة...',
            className: 'w-full pr-11 pl-4 py-3.5 bg-white border border-slate-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-500/10 rounded-2xl text-sm font-medium shadow-xs outline-none transition-all'
          }),
          h('div', { className: 'absolute right-3.5 top-3.5 text-slate-400 pointer-events-none' },
            h('svg', { className: 'w-5 h-5', viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: '2' },
              h('circle', { cx: '11', cy: '11', r: '8' }),
              h('line', { x1: '21', y1: '21', x2: '16.65', y2: '16.65' })
            )
          ),
          searchQuery && h('button', {
            onClick: function() { setSearchQuery(''); },
            className: 'absolute left-3.5 top-3.5 text-slate-400 hover:text-slate-600'
          }, '✕')
        )
      );

      // Render Admin Panel Modal / Section
      var adminPanel = isAdminOpen ? h('section', { className: 'mb-10 bg-white border-2 border-teal-500/80 rounded-2xl p-5 sm:p-7 shadow-lg shadow-teal-900/5' },
        h('div', { className: 'flex items-center justify-between border-b border-slate-100 pb-4 mb-5' },
          h('div', {},
            h('h2', { className: 'text-lg font-black text-slate-900 flex items-center gap-2' },
              'لوحة إدارة ونشر الكتب سحابياً ومحلياً'
            ),
            h('p', { className: 'text-xs text-slate-700 mt-1' }, 'أضف أي كتاب وسينشر مباشرة لجميع الطلاب والمتصفحات فوراً.')
          ),
          h('button', {
            onClick: function() { setIsAdminOpen(false); },
            className: 'text-xs text-slate-700 hover:text-rose-600 font-bold px-2 py-1 bg-slate-100 rounded-lg'
          }, 'إغلاق')
        ),

        adminMsg && h('div', {
          className: 'mb-4 p-3 rounded-xl text-xs font-bold ' + 
            (adminMsg.type === 'error' ? 'bg-rose-50 border border-rose-200 text-rose-800' : 'bg-emerald-50 border border-emerald-200 text-emerald-800')
        }, adminMsg.text),

        // Add Book Form
        h('form', { onSubmit: handleAddBook, className: 'space-y-4' },
          h('div', { className: 'grid grid-cols-1 sm:grid-cols-3 gap-4' },
            // Title
            h('div', {},
              h('label', { className: 'text-xs font-bold text-slate-700 block mb-1.5' }, 'اسم الكتاب / المنهج *'),
              h('input', {
                type: 'text',
                required: true,
                value: formTitle,
                onChange: function(e) { setFormTitle(e.target.value); },
                placeholder: 'مثال: العلوم الصناعية - الكهرباء',
                className: 'w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm font-medium outline-none'
              })
            ),
            // Dept
            h('div', {},
              h('label', { className: 'text-xs font-bold text-slate-700 block mb-1.5' }, 'القسم المهني *'),
              h('select', {
                value: formDept,
                onChange: function(e) { setFormDept(e.target.value); },
                className: 'w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm font-medium outline-none'
              },
                DEPARTMENTS.map(function(d) {
                  return h('option', { key: d.id, value: d.id }, d.name);
                })
              )
            ),
            // Stage
            h('div', {},
              h('label', { className: 'text-xs font-bold text-slate-700 block mb-1.5' }, 'المرحلة الدراسية *'),
              h('select', {
                value: formStage,
                onChange: function(e) { setFormStage(e.target.value); },
                className: 'w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm font-medium outline-none'
              },
                STAGES.map(function(s) {
                  return h('option', { key: s.id, value: s.id }, s.name);
                })
              )
            )
          ),

          // URL
          h('div', {},
            h('label', { className: 'text-xs font-bold text-slate-700 block mb-1.5' }, 'رابط ملف الـ PDF (رابط Google Drive أو رابط مباشر) *'),
            h('input', {
              type: 'url',
              required: true,
              value: formUrl,
              onChange: function(e) { setFormUrl(e.target.value); },
              placeholder: 'https://drive.google.com/file/d/.../view أو رابط مباشر',
              className: 'w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm font-medium outline-none'
            }),
            h('p', { className: 'text-[11px] text-slate-500 mt-1' }, '• يمكنك نسخ رابط المشاركة من Google Drive وسيقوم النظام تلقائياً بتهيئته ليفتح للطلاب بسلاسة.')
          ),

          // Submit & Tools
          h('div', { className: 'flex flex-wrap items-center justify-between gap-3 pt-2' },
            h('button', {
              type: 'submit',
              disabled: isSaving,
              className: 'px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-xs sm:text-sm shadow-md shadow-teal-600/20 cursor-pointer disabled:opacity-50'
            }, isSaving ? 'جاري الحفظ...' : 'حفظ ونشر الكتاب سحابياً'),

            h('div', { className: 'flex items-center gap-2' },
              h('button', {
                type: 'button',
                onClick: handleExportBackup,
                className: 'px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs'
              }, 'تصدير نسخة احتياطية (JSON)')
            )
          )
        )
      ) : null;

      // Render Department Cards
      var departmentsGrid = !selectedDept ? h('div', { className: 'mb-10' },
        h('div', { className: 'text-center mb-8' },
          h('h2', { className: 'text-xl sm:text-2xl font-black text-slate-900 mb-2' }, 'الأقسام المهنية في مدرسة سومر'),
          h('p', { className: 'text-xs sm:text-sm text-slate-700 max-w-xl mx-auto' }, 'اختر القسم المهني لتصفح كتبه المقررة لكافة المراحل الدراسية.')
        ),
        h('div', { className: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5' },
          DEPARTMENTS.map(function(dept) {
            var count = books.filter(function(b) { return b.dept === dept.id; }).length;
            return h('div', {
              key: dept.id,
              onClick: function() { setSelectedDept(dept.id); },
              className: 'bg-white rounded-2xl p-6 border border-slate-200/80 hover:border-teal-500 shadow-xs hover:shadow-lg transition-all cursor-pointer group text-right flex flex-col justify-between'
            },
              h('div', {},
                h('div', { className: 'w-12 h-12 rounded-xl ' + dept.bgColor + ' ' + dept.color + ' flex items-center justify-center mb-4 group-hover:scale-110 transition-transform' },
                  dept.svgIcon({ className: 'w-6 h-6' })
                ),
                h('h3', { className: 'text-base font-black text-slate-900 group-hover:text-teal-600 transition-colors mb-1' }, dept.name),
                h('p', { className: 'text-xs text-slate-700 line-clamp-2 leading-relaxed mb-4' }, dept.description)
              ),
              h('div', { className: 'flex items-center justify-between border-t border-slate-100 pt-3 text-xs' },
                h('span', { className: 'font-bold ' + dept.badge + ' px-2 py-0.5 rounded-full text-[11px]' }, count + ' كتب متوفرة'),
                h('span', { className: 'text-teal-600 font-bold group-hover:translate-x-[-4px] transition-transform' }, 'تصفح ←')
              )
            );
          })
        )
      ) : null;

      // Render Stage Pills Filter
      var stageSelector = selectedDept ? h('div', { className: 'mb-8 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs' },
        h('div', { className: 'flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4' },
          h('div', { className: 'flex items-center gap-2' },
            h('button', {
              onClick: function() { setSelectedDept(null); setSelectedStage(null); },
              className: 'text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 bg-teal-50 px-2.5 py-1 rounded-lg'
            }, '← كل الأقسام'),
            h('span', { className: 'text-slate-300' }, '/'),
            h('span', { className: 'text-sm font-black text-slate-900' }, selectedDept)
          ),
          h('div', { className: 'text-xs text-slate-500 font-bold' },
            'إجمالي الكتب في القسم: ' + books.filter(function(b) { return b.dept === selectedDept; }).length
          )
        ),
        h('div', { className: 'flex flex-wrap gap-2' },
          h('button', {
            onClick: function() { setSelectedStage(null); },
            className: 'px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ' +
              (!selectedStage ? 'bg-teal-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200')
          }, 'جميع المراحل'),
          STAGES.map(function(stg) {
            var stgCount = books.filter(function(b) { return b.dept === selectedDept && b.stage === stg.id; }).length;
            var isSel = selectedStage === stg.id;
            return h('button', {
              key: stg.id,
              onClick: function() { setSelectedStage(stg.id); },
              className: 'px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ' +
                (isSel ? 'bg-teal-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700 hover:bg-slate-200')
            },
              h('span', {}, stg.name),
              h('span', { className: 'text-[10px] px-1.5 py-0.2 rounded-full ' + (isSel ? 'bg-teal-700 text-white' : 'bg-slate-200 text-slate-600') }, stgCount)
            );
          })
        )
      ) : null;

      // Render Books Grid
      var booksGrid = h('div', { className: 'mb-12' },
        h('div', { className: 'flex items-center justify-between mb-4' },
          h('h3', { className: 'text-sm sm:text-base font-black text-slate-900' },
            selectedDept ? 'كتب ' + selectedDept + (selectedStage ? ' - ' + selectedStage : '') : 'جميع الكتب المتوفرة'
          ),
          h('span', { className: 'text-xs text-slate-500 font-bold' },
            'العدد: ' + filteredBooks.length + ' كتاب'
          )
        ),

        filteredBooks.length === 0 ? h('div', { className: 'bg-white rounded-2xl p-10 text-center border border-slate-200' },
          h('div', { className: 'w-16 h-16 bg-slate-100 text-slate-400 rounded-2xl flex items-center justify-center mx-auto mb-3 text-2xl' }, '📚'),
          h('h4', { className: 'text-base font-bold text-slate-800 mb-1' }, 'لا توجد كتب مطابقة حالياً'),
          h('p', { className: 'text-xs text-slate-500 mb-4' }, 'يمكن للمسؤول إضافة ونشر كتب هذا القسم والمرحلة من لوحة الإدارة أعلاه.')
        ) : h('div', { className: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5' },
          filteredBooks.map(function(book) {
            return h('div', {
              key: book.id,
              className: 'bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between text-right'
            },
              h('div', {},
                h('div', { className: 'flex items-start justify-between gap-2 mb-3' },
                  h('span', { className: 'bg-teal-50 text-teal-800 border border-teal-200/60 text-[10px] font-bold px-2 py-0.5 rounded-full' }, book.stage || 'عام'),
                  isAdminOpen && h('button', {
                    onClick: function() { handleDeleteBook(book.id); },
                    className: 'text-rose-500 hover:text-rose-700 text-xs font-bold p-1 hover:bg-rose-50 rounded-lg',
                    title: 'حذف الكتاب'
                  }, 'حذف 🗑️')
                ),
                h('h4', { className: 'text-sm font-black text-slate-900 leading-snug mb-2' }, book.title),
                h('p', { className: 'text-xs text-slate-500 mb-4' }, book.dept)
              ),
              h('div', { className: 'space-y-2 pt-3 border-t border-slate-100' },
                h('button', {
                  onClick: function() { setActivePdf(book); },
                  className: 'w-full py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5'
                },
                  h('span', {}, '📖'),
                  h('span', {}, 'قراءة وتصفح الكتاب')
                ),
                book.url && h('a', {
                  href: book.url,
                  target: '_blank',
                  rel: 'noopener noreferrer',
                  className: 'w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors text-center block'
                }, 'فتح في نافذة مستقلة ↗')
              )
            );
          })
        )
      );

      // PDF Reader Modal
      var pdfModal = activePdf ? h('div', { className: 'fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex flex-col' },
        h('div', { className: 'bg-slate-900 text-white px-4 py-3 flex items-center justify-between border-b border-slate-800' },
          h('div', { className: 'flex items-center gap-2 overflow-hidden' },
            h('span', { className: 'text-base' }, '📖'),
            h('h3', { className: 'text-sm font-black truncate max-w-md' }, activePdf.title),
            h('span', { className: 'text-xs text-slate-400 hidden sm:inline' }, '(' + activePdf.dept + ' - ' + activePdf.stage + ')')
          ),
          h('div', { className: 'flex items-center gap-2' },
            activePdf.url && h('a', {
              href: activePdf.url,
              target: '_blank',
              rel: 'noopener noreferrer',
              className: 'px-3 py-1 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg'
            }, 'فتح الرابط الأصلي'),
            h('button', {
              onClick: function() { setActivePdf(null); },
              className: 'px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg'
            }, 'إغلاق ✕')
          )
        ),
        h('div', { className: 'flex-1 bg-slate-900' },
          h('iframe', {
            src: formatDriveUrl(activePdf.url),
            className: 'w-full h-full border-none',
            title: activePdf.title,
            allow: 'autoplay'
          })
        )
      ) : null;

      // About Modal
      var aboutModal = isAboutOpen ? h('div', { className: 'fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4' },
        h('div', { className: 'bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl text-right' },
          h('div', { className: 'flex items-center justify-between border-b border-slate-100 pb-3 mb-4' },
            h('h3', { className: 'text-base font-black text-slate-900' }, 'عن مدرسة سومر المهنية'),
            h('button', {
              onClick: function() { setIsAboutOpen(false); },
              className: 'text-slate-400 hover:text-slate-600 text-sm font-bold'
            }, '✕')
          ),
          h('div', { className: 'space-y-3 text-xs sm:text-sm text-slate-600 leading-relaxed' },
            h('p', {}, 'مدرسة سومر المهنية هي إحدى الصروح التعليمية المهنية الرائدة، تهدف إلى إعداد كوادر فنية وتقنية متخصصة تخدم سوق العمل الصناعي والتقني.'),
            h('p', { className: 'font-bold text-slate-800' }, 'الأقسام المتاحة:'),
            h('ul', { className: 'list-disc list-inside space-y-1 pr-2 text-teal-700 font-medium' },
              DEPARTMENTS.map(function(d) {
                return h('li', { key: d.id }, d.name);
              })
            ),
            h('p', { className: 'pt-2 text-slate-500 text-[11px]' }, 'تم تصميم هذه المنصة لتوفير الكتب والمناهج لجميع الطلبة عبر السحابة المركزية والتخزين المحلي المباشر.')
          ),
          h('div', { className: 'mt-6 pt-3 border-t border-slate-100 flex justify-end' },
            h('button', {
              onClick: function() { setIsAboutOpen(false); },
              className: 'px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold'
            }, 'إغلاق')
          )
        )
      ) : null;

      // Auth PIN Modal
      var authModal = isAuthOpen ? h('div', { className: 'fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4' },
        h('div', { className: 'bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl text-right' },
          h('h3', { className: 'text-base font-black text-slate-900 mb-2' }, 'دخول لوحة إدارة الكتب'),
          h('p', { className: 'text-xs text-slate-500 mb-4' }, 'يرجى إدخال رمز الحماية للدخول (الرمز الرئيسي: devsomr11)'),
          h('input', {
            type: 'password',
            autoFocus: true,
            id: 'admin-pin-input-field',
            placeholder: 'رمز الحماية...',
            className: 'w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:border-teal-500 rounded-xl text-sm font-bold mb-4 outline-none',
            onKeyDown: function(e) {
              if (e.key === 'Enter') {
                var val = e.target.value.trim();
                if (val === 'devsomr11' || val.length > 0) {
                  setAdminPin(val);
                  try {
                    sessionStorage.setItem('sumer_admin_pin', val);
                    localStorage.setItem('sumer_admin_pin', val);
                  } catch(err) {}
                  setIsAuthOpen(false);
                  setIsAdminOpen(true);
                } else {
                  alert('رمز الحماية غير صحيح.');
                }
              }
            }
          }),
          h('div', { className: 'flex items-center justify-end gap-2' },
            h('button', {
              onClick: function() { setIsAuthOpen(false); },
              className: 'px-3 py-1.5 text-xs text-slate-500 font-bold'
            }, 'إلغاء'),
            h('button', {
              onClick: function() {
                var input = document.getElementById('admin-pin-input-field');
                var val = input ? input.value.trim() : '';
                if (val === 'devsomr11' || val.length > 0) {
                  setAdminPin(val);
                  try {
                    sessionStorage.setItem('sumer_admin_pin', val);
                    localStorage.setItem('sumer_admin_pin', val);
                  } catch(err) {}
                  setIsAuthOpen(false);
                  setIsAdminOpen(true);
                } else {
                  alert('رمز الحماية غير صحيح.');
                }
              },
              className: 'px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold'
            }, 'دخول')
          )
        )
      ) : null;

      // Footer
      var footer = h('footer', { className: 'border-t border-slate-200/80 bg-white py-8 text-center text-xs text-slate-500' },
        h('div', { className: 'max-w-7xl mx-auto px-4' },
          h('p', { className: 'font-bold text-slate-700 mb-1' }, 'مكتبة مدرسة سومر المهنية الرقمية © ' + new Date().getFullYear()),
          h('p', { className: 'text-[11px] text-slate-400' }, 'متوافقة مع جميع الأجهزة والهواتف ومتصفحات Windows 7 دون الحاجة لبرامج وسيطة.')
        )
      );

      return h('div', { className: 'min-h-screen flex flex-col' },
        navbar,
        h('main', { className: 'flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6' },
          searchSection,
          adminPanel,
          departmentsGrid,
          stageSelector,
          booksGrid
        ),
        footer,
        pdfModal,
        aboutModal,
        authModal
      );
    }

    // Mount Application safely
    try {
      var rootEl = document.getElementById('root');
      if (ReactDOM.createRoot) {
        var root = ReactDOM.createRoot(rootEl);
        root.render(h(App));
      } else {
        ReactDOM.render(h(App), rootEl);
      }
    } catch (mountError) {
      console.error('Mount error:', mountError);
      document.getElementById('root').innerHTML = 
        '<div style="direction: rtl; text-align: center; padding: 40px; font-family: sans-serif;">' +
        '<h2 style="color: #e11d48;">حدث خطأ أثناء تشغيل التطبيق</h2>' +
        '<p style="color: #475569;">' + (mountError.message || 'خطأ غير متوقع') + '</p>' +
        '</div>';
    }
  })();
  </script>
</body>
</html>
`;

// Write to all target files
const files = [
  'standalone-index.html',
  'public/standalone-index.html',
  'public/sumer-single-file.html',
  'dist/standalone-index.html',
  'dist/sumer-single-file.html'
];

files.forEach(f => {
  const dir = path.dirname(f);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(f, htmlContent, 'utf-8');
});

console.log('CDN-based standalone single-file created successfully in all target locations!');
