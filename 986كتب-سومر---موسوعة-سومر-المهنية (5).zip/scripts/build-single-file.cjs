const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');

console.log('Generating standalone single-file HTML for Windows 7 & offline use...');

// 1. Bundle JavaScript using esbuild
const jsBuild = esbuild.buildSync({
  entryPoints: ['src/main.tsx'],
  bundle: true,
  minify: true,
  format: 'iife',
  external: ['*.css'],
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  write: false,
});

let bundledJs = jsBuild.outputFiles[0].text;
// Escape closing script tags to avoid breaking HTML parser
bundledJs = bundledJs.replace(/<\/script/gi, '<\\/script');

// 2. Read compiled CSS from dist/assets if available
let bundledCss = '';
const distAssets = path.join(process.cwd(), 'dist', 'assets');
if (fs.existsSync(distAssets)) {
  const cssFiles = fs.readdirSync(distAssets).filter(f => f.endsWith('.css'));
  if (cssFiles.length > 0) {
    bundledCss = fs.readFileSync(path.join(distAssets, cssFiles[0]), 'utf-8');
  }
}

// 3. Assemble the single-file HTML document
const singleHtml = `<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="google-site-verification" content="EMgd5TyH0VFBG-ilgNt9UieXuwUcWIizscwhifoxy5M" />
    <title>كتب سومر - موسوعة سومر المهنية</title>
    <meta name="description" content="منصة وموسوعة كتب مدرسة سومر المهنية لجميع الأقسام والمراحل مع لوحة تحكم لنشر الكتب عبر جميع المتصفحات والأجهزة." />
    <meta property="og:title" content="كتب سومر - موسوعة سومر المهنية" />
    <meta property="og:description" content="منصة وموسوعة كتب مدرسة سومر المهنية لجميع الأقسام والمراحل مع لوحة تحكم لنشر الكتب عبر جميع المتصفحات والأجهزة." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />

    <!-- Google Fonts: Tajawal -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS (Loads via CDN if online, with fallback stylesheet below) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            fontFamily: {
              sans: ['Tajawal', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
            },
            colors: {
              teal: {
                50: '#f0fdfa',
                100: '#ccfbf1',
                200: '#99f6e4',
                500: '#14b8a6',
                600: '#0d9488',
                700: '#0f766e',
                800: '#115e59',
                900: '#134e4a',
                950: '#042f2e',
              }
            }
          }
        }
      }
    </script>

    <!-- Embedded CSS Stylesheet for Offline & Windows 7 file:/// support -->
    <style>
      ${bundledCss}
    </style>
  </head>
  <body class="bg-slate-50 text-slate-900 min-h-screen font-sans antialiased selection:bg-teal-500 selection:text-white">
    <div id="root"></div>

    <!-- Complete Bundled React Application with Firebase Cloud integration -->
    <script>
      ${bundledJs}
    </script>
  </body>
</html>
`;

// Save standalone file in multiple locations for convenience
const targetFiles = [
  'standalone-index.html',
  'public/standalone-index.html',
  'public/sumer-single-file.html',
  'dist/standalone-index.html',
  'dist/sumer-single-file.html'
];

targetFiles.forEach(file => {
  const dir = path.dirname(file);
  if (fs.existsSync(dir)) {
    fs.writeFileSync(file, singleHtml, 'utf-8');
  }
});

console.log('Standalone single-file created successfully! Size:', Math.round(singleHtml.length / 1024), 'KB');
