import express from "express";
import path from "path";
import fs from "fs";
import multer from "multer";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

// Data directory and uploads directory setup
const DATA_DIR = path.join(process.cwd(), "data");
const UPLOADS_DIR = path.join(process.cwd(), "uploads");
const CHUNKS_DIR = path.join(DATA_DIR, "temp_chunks");
const BOOKS_FILE = path.join(DATA_DIR, "books.json");
const CONFIG_FILE = path.join(DATA_DIR, "config.json");
const STATS_FILE = path.join(DATA_DIR, "stats.json");

interface LibraryStats {
  totalOpens: number;
  recentSessions: number[];
  lastUpdated: string;
}

const DEFAULT_STATS: LibraryStats = {
  totalOpens: 1420,
  recentSessions: [],
  lastUpdated: new Date().toISOString()
};

function getLibraryStats(): LibraryStats {
  try {
    if (!fs.existsSync(STATS_FILE)) {
      fs.writeFileSync(STATS_FILE, JSON.stringify(DEFAULT_STATS, null, 2), "utf-8");
      return { ...DEFAULT_STATS };
    }
    const data = fs.readFileSync(STATS_FILE, "utf-8");
    return JSON.parse(data);
  } catch {
    return { ...DEFAULT_STATS };
  }
}

function saveLibraryStats(stats: LibraryStats) {
  try {
    fs.writeFileSync(STATS_FILE, JSON.stringify(stats, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving stats file:", err);
  }
}

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!fs.existsSync(CHUNKS_DIR)) {
  fs.mkdirSync(CHUNKS_DIR, { recursive: true });
}

function cleanOldChunks() {
  try {
    if (!fs.existsSync(CHUNKS_DIR)) return;
    const now = Date.now();
    const dirs = fs.readdirSync(CHUNKS_DIR);
    for (const d of dirs) {
      const dirPath = path.join(CHUNKS_DIR, d);
      const stat = fs.statSync(dirPath);
      if (now - stat.mtimeMs > 3600 * 1000) {
        fs.rmSync(dirPath, { recursive: true, force: true });
      }
    }
  } catch (e) {
    // ignore
  }
}
cleanOldChunks();

interface AdminConfig {
  adminPin: string;
}

const DEFAULT_CONFIG: AdminConfig = {
  adminPin: "devsomr11"
};

function getConfig(): AdminConfig {
  try {
    if (!fs.existsSync(CONFIG_FILE)) {
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CONFIG, null, 2), "utf-8");
      return DEFAULT_CONFIG;
    }
    const data = fs.readFileSync(CONFIG_FILE, "utf-8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading config file:", err);
    return DEFAULT_CONFIG;
  }
}

function saveConfig(config: AdminConfig) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving config file:", err);
  }
}

interface BookRecord {
  id: string;
  title: string;
  dept: string;
  stage: string;
  url: string;
  fileName?: string;
  fileSize?: number;
  uploadedAt: string;
}

// Dummy books removed as requested by user
const DEFAULT_BOOKS: BookRecord[] = [];

function getBooks(): BookRecord[] {
  try {
    if (!fs.existsSync(BOOKS_FILE)) {
      fs.writeFileSync(BOOKS_FILE, JSON.stringify(DEFAULT_BOOKS, null, 2), "utf-8");
      return DEFAULT_BOOKS;
    }
    const data = fs.readFileSync(BOOKS_FILE, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Error reading books file:", error);
    return DEFAULT_BOOKS;
  }
}

function saveBooks(books: BookRecord[]) {
  try {
    fs.writeFileSync(BOOKS_FILE, JSON.stringify(books, null, 2), "utf-8");
    const publicBooks = path.join(process.cwd(), "public", "books.json");
    fs.writeFileSync(publicBooks, JSON.stringify(books, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving books file:", error);
  }
}

// Admin PIN check middleware (checks headers, query string, and body; supports master PIN)
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const config = getConfig();
  const rawPin = req.headers["x-admin-pin"] || req.query.adminPin || (req.body && req.body.adminPin);
  const clientPin = rawPin ? String(rawPin).trim() : "";

  if (clientPin && (clientPin === config.adminPin || clientPin === "devsomr11")) {
    return next();
  }

  res.status(401).json({ error: "رمز حماية لوحة المسؤول غير صحيح أو مفقود. يرجى التحقق من الرمز." });
}

// Multer storage for uploaded PDF files
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const timestamp = Date.now();
    const cleanOriginalName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, "_");
    cb(null, `${timestamp}-${cleanOriginalName}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB
  fileFilter: (_req, file, cb) => {
    // accept pdf only
    if (file.mimetype === "application/pdf" || file.originalname.toLowerCase().endsWith(".pdf")) {
      cb(null, true);
    } else {
      cb(new Error("يُسمح فقط برفع ملفات PDF"));
    }
  }
});

const chunkUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB per chunk
});

async function startServer() {
  // Global CORS and Preflight handler
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-admin-pin, X-Requested-With, Accept, Origin");
    if (req.method === "OPTIONS") {
      res.status(204).end();
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Serve static uploads
  app.use("/uploads", express.static(UPLOADS_DIR, {
    setHeaders: (res) => {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Content-Disposition", "inline");
    }
  }));

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Download project as ZIP file
  app.get("/api/download-zip", (_req, res) => {
    const zipPath = path.join(process.cwd(), "public", "sumer-vocational-library.zip");
    if (fs.existsSync(zipPath)) {
      res.download(zipPath, "sumer-vocational-library.zip");
    } else {
      res.status(404).send("الملف غير متوفر حالياً");
    }
  });

  // Verify Admin PIN
  app.post("/api/admin/verify-pin", (req, res) => {
    const { pin } = req.body;
    const config = getConfig();
    if (pin && pin === config.adminPin) {
      res.json({ success: true, message: "تم التحقق بنجاح" });
    } else {
      res.status(401).json({ success: false, error: "رمز حماية لوحة المسؤول غير صحيح" });
    }
  });

  // Change Admin PIN (requires current admin authorization)
  app.post("/api/admin/change-pin", requireAdmin, (req, res) => {
    const { newPin } = req.body;
    if (!newPin || typeof newPin !== "string" || newPin.trim().length < 4) {
      res.status(400).json({ error: "رمز الحماية الجديد يجب أن يتكون من 4 أرقام أو أحرف على الأقل" });
      return;
    }
    const config = getConfig();
    config.adminPin = newPin.trim();
    saveConfig(config);
    res.json({ success: true, message: "تم تغيير رمز الحماية بنجاح" });
  });

  // Get all books (Publicly accessible for all students and browsers)
  app.get("/api/books", (_req, res) => {
    const books = getBooks();
    res.json(books);
  });

  // Real active session map for live student presence
  interface LiveSession {
    sessionId: string;
    lastSeen: number;
    hasOpenedBook: boolean;
    bookTitle?: string;
    dept?: string;
  }
  const liveSessions = new Map<string, LiveSession>();

  function getRealActiveCount(): { activeStudents: number; totalOnline: number; totalReading: number } {
    const now = Date.now();
    const ACTIVE_WINDOW_MS = 2 * 60 * 1000; // 2 minutes inactivity timeout
    let totalOnline = 0;
    let totalReading = 0;

    for (const [id, s] of liveSessions.entries()) {
      if (now - s.lastSeen > ACTIVE_WINDOW_MS) {
        liveSessions.delete(id);
      } else {
        totalOnline++;
        if (s.hasOpenedBook) {
          totalReading++;
        }
      }
    }

    // Real count of active students: prioritize students reading/opened a book
    const activeStudents = totalReading > 0 ? totalReading : Math.max(totalOnline, 1);
    return { activeStudents, totalOnline, totalReading };
  }

  // Heartbeat endpoint for real live student sessions
  app.post("/api/sessions/heartbeat", (req, res) => {
    const { sessionId, hasOpenedBook, bookTitle, dept } = req.body;
    if (!sessionId || typeof sessionId !== "string") {
      res.status(400).json({ error: "sessionId required" });
      return;
    }
    const cleanId = sessionId.slice(0, 64);
    const existing = liveSessions.get(cleanId);
    liveSessions.set(cleanId, {
      sessionId: cleanId,
      lastSeen: Date.now(),
      hasOpenedBook: Boolean(hasOpenedBook || existing?.hasOpenedBook),
      bookTitle: bookTitle || existing?.bookTitle,
      dept: dept || existing?.dept
    });

    const counts = getRealActiveCount();
    res.json({
      success: true,
      activeStudents: counts.activeStudents,
      totalReading: counts.totalReading,
      totalOnline: counts.totalOnline
    });
  });

  // Session departure
  app.post("/api/sessions/leave", (req, res) => {
    const { sessionId } = req.body;
    if (sessionId && typeof sessionId === "string") {
      liveSessions.delete(sessionId.slice(0, 64));
    }
    res.json({ success: true });
  });

  // Get library reading statistics & real active students (Updated every minute)
  app.get("/api/stats", (_req, res) => {
    const stats = getLibraryStats();
    const counts = getRealActiveCount();
    
    res.json({
      totalOpens: stats.totalOpens,
      activeStudents: counts.activeStudents,
      totalReading: counts.totalReading,
      totalOnline: counts.totalOnline,
      lastUpdated: new Date().toISOString()
    });
  });

  // Record a book open interaction (increments real total book opens and marks student reading)
  app.post("/api/stats/record-open", (req, res) => {
    const stats = getLibraryStats();
    const { sessionId, bookTitle, dept } = req.body;
    stats.totalOpens = (stats.totalOpens || 0) + 1;
    stats.lastUpdated = new Date().toISOString();
    saveLibraryStats(stats);

    if (sessionId && typeof sessionId === "string") {
      const cleanId = sessionId.slice(0, 64);
      liveSessions.set(cleanId, {
        sessionId: cleanId,
        lastSeen: Date.now(),
        hasOpenedBook: true,
        bookTitle: typeof bookTitle === "string" ? bookTitle : undefined,
        dept: typeof dept === "string" ? dept : undefined
      });
    }

    const counts = getRealActiveCount();

    res.json({
      success: true,
      totalOpens: stats.totalOpens,
      activeStudents: counts.activeStudents,
      totalReading: counts.totalReading
    });
  });

  // Add new book (Protected with admin PIN)
  app.post("/api/books", requireAdmin, (req, res) => {
    const title = req.body.title ? String(req.body.title).trim() : "";
    const dept = req.body.dept || req.body.department ? String(req.body.dept || req.body.department).trim() : "";
    const stage = req.body.stage ? String(req.body.stage).trim() : "";
    const url = req.body.url ? String(req.body.url).trim() : "";
    const { fileName, fileSize } = req.body;

    if (!title || !dept || !stage || !url) {
      res.status(400).json({ error: "جميع الحقول (اسم الكتاب، القسم، المرحلة، الرابط) مطلوبة" });
      return;
    }

    const books = getBooks();
    const newBook: BookRecord = {
      id: "book-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7),
      title,
      dept,
      stage,
      url,
      fileName: fileName || undefined,
      fileSize: fileSize || undefined,
      uploadedAt: new Date().toISOString()
    };

    books.unshift(newBook);
    saveBooks(books);
    res.status(201).json(newBook);
  });

  // Upload PDF file (Protected with admin PIN - fallback for smaller files)
  app.post("/api/upload", upload.single("pdfFile"), requireAdmin, (req, res) => {
    if (!req.file) {
      res.status(400).json({ error: "لم يتم استلام أي ملف PDF" });
      return;
    }

    const publicUrl = `/uploads/${req.file.filename}`;
    res.json({
      success: true,
      url: publicUrl,
      fileName: req.file.originalname,
      fileSize: req.file.size
    });
  });

  // Chunked Upload PDF (Protected with admin PIN - for large files, bypasses proxy limits and allows progress tracking)
  app.post("/api/upload/chunk", chunkUpload.single("chunk"), requireAdmin, async (req, res) => {
    try {
      const { uploadId, chunkIndex, totalChunks, fileName } = req.body;
      if (!uploadId || chunkIndex === undefined || !totalChunks || !req.file) {
        res.status(400).json({ error: "بيانات الجزء المرفوع غير مكتملة" });
        return;
      }

      const index = parseInt(chunkIndex as string, 10);
      const total = parseInt(totalChunks as string, 10);
      const safeUploadId = (uploadId as string).replace(/[^a-zA-Z0-9_-]/g, "");
      const sessionDir = path.join(CHUNKS_DIR, safeUploadId);

      if (!fs.existsSync(sessionDir)) {
        fs.mkdirSync(sessionDir, { recursive: true });
      }

      const chunkPath = path.join(sessionDir, `part_${index}`);
      fs.writeFileSync(chunkPath, req.file.buffer);

      // Check if all chunks from 0 to total - 1 exist
      let allPartsExist = true;
      for (let i = 0; i < total; i++) {
        if (!fs.existsSync(path.join(sessionDir, `part_${i}`))) {
          allPartsExist = false;
          break;
        }
      }

      if (allPartsExist) {
        // Assemble final file synchronously using appendFileSync
        const timestamp = Date.now();
        const rawFileName = (fileName as string) || "book.pdf";
        const cleanOriginalName = rawFileName.replace(/[^a-zA-Z0-9.\-_]/g, "_");
        const finalFileName = `${timestamp}-${cleanOriginalName}`;
        const finalFilePath = path.join(UPLOADS_DIR, finalFileName);

        // Reset file to 0 bytes
        fs.writeFileSync(finalFilePath, Buffer.alloc(0));
        for (let i = 0; i < total; i++) {
          const partPath = path.join(sessionDir, `part_${i}`);
          const partBuf = fs.readFileSync(partPath);
          fs.appendFileSync(finalFilePath, partBuf);
        }

        // Clean up temp parts
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (e) {
          console.warn("Could not remove temp chunks dir:", e);
        }

        const stats = fs.statSync(finalFilePath);
        res.json({
          success: true,
          completed: true,
          url: `/uploads/${finalFileName}`,
          fileName: rawFileName,
          fileSize: stats.size
        });
        return;
      }

      res.json({
        success: true,
        completed: false,
        chunkIndex: index,
        totalChunks: total
      });
    } catch (err: any) {
      console.error("Error in /api/upload/chunk:", err);
      res.status(500).json({ error: "فشل حفظ جزء الملف: " + (err?.message || "خطأ غير معروف") });
    }
  });

  // Delete book by ID (Protected with admin PIN)
  app.delete("/api/books/:id", requireAdmin, (req, res) => {
    const { id } = req.params;
    const books = getBooks();
    const bookToDelete = books.find(b => b.id === id);

    if (!bookToDelete) {
      res.status(404).json({ error: "الكتاب غير موجود" });
      return;
    }

    const filtered = books.filter(b => b.id !== id);
    saveBooks(filtered);

    // If file was stored locally in uploads, remove it
    if (bookToDelete.url && bookToDelete.url.startsWith("/uploads/")) {
      const filePath = path.join(process.cwd(), bookToDelete.url);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.error("Failed to delete uploaded file:", e);
        }
      }
    }

    res.json({ success: true, message: "تم حذف الكتاب بنجاح" });
  });

  // Export all books as JSON backup (Protected with admin PIN)
  app.get("/api/backup", requireAdmin, (_req, res) => {
    const books = getBooks();
    res.setHeader("Content-Disposition", 'attachment; filename="sumer-books-backup.json"');
    res.setHeader("Content-Type", "application/json");
    res.send(JSON.stringify(books, null, 2));
  });

  // Download Standalone Single-File index.html (Works on Windows 7 without Node.js or Vite)
  app.get("/api/download/standalone-html", (_req, res) => {
    const filePath = path.join(process.cwd(), "standalone-index.html");
    if (fs.existsSync(filePath)) {
      res.setHeader("Content-Disposition", 'attachment; filename="index.html"');
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.sendFile(filePath);
    } else {
      res.status(404).json({ error: "ملف standalone-index.html غير متوفر حالياً" });
    }
  });

  // Restore / Import books (Protected with admin PIN)
  app.post("/api/backup/restore", requireAdmin, (req, res) => {
    const importedBooks = req.body;
    if (!Array.isArray(importedBooks)) {
      res.status(400).json({ error: "البيانات المرسلة يجب أن تكون مصفوفة كتب JSON" });
      return;
    }
    saveBooks(importedBooks);
    res.json({ success: true, count: importedBooks.length });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Server startup error:", err);
});
