/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Book, DepartmentId, StageId, DepartmentItem } from './types';
import { Navbar } from './components/Navbar';
import { AdminPanel } from './components/AdminPanel';
import { DepartmentsView } from './components/DepartmentsView';
import { StagesView } from './components/StagesView';
import { BooksView } from './components/BooksView';
import { CyberStageSelector } from './components/CyberStageSelector';
import { CyberBooksVault } from './components/CyberBooksVault';
import { ElectricStageSelector } from './components/ElectricStageSelector';
import { ElectricBooksVault } from './components/ElectricBooksVault';
import { ComputerStageSelector } from './components/ComputerStageSelector';
import { ComputerBooksVault } from './components/ComputerBooksVault';
import { ElectronicsStageSelector } from './components/ElectronicsStageSelector';
import { ElectronicsBooksVault } from './components/ElectronicsBooksVault';
import { PdfReaderModal } from './components/PdfReaderModal';
import { AboutModal } from './components/AboutModal';
import { 
  LocalUserAccount, 
  getActiveLocalUser, 
  ADMIN_EMAILS, 
  logoutLocalUser 
} from './lib/userAuth';
import { BottomNavBar, TabType } from './components/BottomNavBar';
import { FavoritesView } from './components/FavoritesView';
import { RecentView } from './components/RecentView';
import { AccountView } from './components/AccountView';
import { RecentlyAddedSection } from './components/RecentlyAddedSection';
import { SumerHomeView } from './components/SumerHomeView';
import { AnimatePresence, motion } from 'framer-motion';
import { Loader2, RefreshCw, ArrowRight, ArrowLeft } from 'lucide-react';
import { 
  apiUrl, 
  getLocalBooks, 
  saveLocalBooks, 
  getFavoriteBookIds, 
  toggleFavoriteBookId, 
  getRecentlyViewedRecords, 
  recordRecentlyViewed,
  clearRecentlyViewed,
  RecentViewRecord,
  addDeletedBookId,
  getDeletedBookIds
} from './lib/storage';
import { DEFAULT_BOOKS } from './data/defaultBooks';
import { 
  subscribeToCloudBooks, 
  fetchCloudBooks, 
  saveBookToCloud, 
  deleteBookFromCloud 
} from './lib/cloudBooks';
import { 
  getLocalDepartments, 
  fetchCloudDepartments, 
  subscribeToCloudDepartments, 
  saveDepartmentToCloud, 
  deleteDepartmentFromCloud 
} from './lib/departments';
import { recordBookInteraction } from './lib/analytics';
import { ActiveReadersBadge } from './components/ActiveReadersBadge';

export default function App() {
  const parseAdminFromUrl = () => {
    return {
      isAdminUrl: false,
      directPin: null
    };
  };

  const [isAdminRoute, setIsAdminRoute] = useState<boolean>(false);
  const [departments, setDepartments] = useState<DepartmentItem[]>(() => getLocalDepartments());

  const [books, setBooks] = useState<Book[]>(() => {
    return getLocalBooks();
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isCloudConnected, setIsCloudConnected] = useState<boolean>(true);
  // Local User Authentication State (Zero Cloud Storage)
  const [currentUser, setCurrentUser] = useState<LocalUserAccount | null>(() => getActiveLocalUser());
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    const active = getActiveLocalUser();
    return Boolean(active?.isAdmin || (active?.email && ADMIN_EMAILS.includes(active.email.toLowerCase())));
  });
  const [adminPin, setAdminPin] = useState<string>(() => 
    sessionStorage.getItem('sumer_admin_pin') || 
    localStorage.getItem('sumer_admin_pin') || 
    'devsomr11'
  );

  // Bottom Navigation Bar Tab state
  const [activeTab, setActiveTab] = useState<TabType>('home');
  // Student Favorites state (stored locally per account)
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => 
    getFavoriteBookIds(getActiveLocalUser()?.email)
  );
  // Student Recently Viewed state (stored locally per account)
  const [recentRecords, setRecentRecords] = useState<RecentViewRecord[]>(() => 
    getRecentlyViewedRecords(getActiveLocalUser()?.email)
  );

  const [currentDept, setCurrentDept] = useState<DepartmentId | null>(null);
  const [currentStage, setCurrentStage] = useState<StageId | null>(null);
  const [readingBook, setReadingBook] = useState<Book | null>(null);
  const [isAboutOpen, setIsAboutOpen] = useState<boolean>(false);

  // Toggle favorite book for active user
  const handleToggleFavorite = useCallback((bookId: string) => {
    toggleFavoriteBookId(bookId, currentUser?.email);
    setFavoriteIds(getFavoriteBookIds(currentUser?.email));
  }, [currentUser]);

  // Clear reading history for active user
  const handleClearRecent = useCallback(() => {
    clearRecentlyViewed(currentUser?.email);
    setRecentRecords([]);
  }, [currentUser]);

  // Record reading interaction and history
  const handleReadBook = useCallback((book: Book) => {
    recordBookInteraction(book.id, book.dept, book.title);
    recordRecentlyViewed(book.id, currentUser?.email);
    setRecentRecords(getRecentlyViewedRecords(currentUser?.email));
    setReadingBook(book);
  }, [currentUser]);

  // Handle User Login / Register / Profile update / Logout
  const handleUserAuthChange = (user: LocalUserAccount | null) => {
    setCurrentUser(user);
    if (user) {
      const isUserAdmin = Boolean(user.isAdmin || ADMIN_EMAILS.includes(user.email.toLowerCase()));
      setIsAdmin(isUserAdmin);
      setIsAdminRoute(isUserAdmin);
      // Automatically load their personal favorites & recently viewed books
      setFavoriteIds(getFavoriteBookIds(user.email));
      setRecentRecords(getRecentlyViewedRecords(user.email));
      // If admin logs in, open admin section immediately
      if (isUserAdmin) {
        setActiveTab('admin');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } else {
      setIsAdmin(false);
      setIsAdminRoute(false);
      // Return to guest favorites & recent reads
      setFavoriteIds(getFavoriteBookIds(null));
      setRecentRecords(getRecentlyViewedRecords(null));
    }
  };

  const handleSignOutLocal = () => {
    logoutLocalUser();
    handleUserAuthChange(null);
    setActiveTab('home');
  };
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Dark Mode State with localStorage persistence and system preference support (defaults to dark)
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('sumer_theme');
      if (savedTheme) {
        return savedTheme === 'dark';
      }
      return true; // Default to dark mode for the premium Sumerian dark navy theme
    }
    return true;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('sumer_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('sumer_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Fetch and subscribe to Cloud Departments
  useEffect(() => {
    fetchCloudDepartments().then(setDepartments).catch(console.warn);
    const unsubscribe = subscribeToCloudDepartments((liveDepts) => {
      setDepartments(liveDepts);
    });
    return unsubscribe;
  }, []);

  const toggleAdmin = () => {
    if (isAdmin) {
      setActiveTab('admin');
    } else {
      setActiveTab('account');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExitAdmin = () => {
    setActiveTab('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddDepartment = async (newDept: {
    name: string;
    title?: string;
    description?: string;
    iconName: string;
    colorTheme?: string;
  }) => {
    try {
      const saved = await saveDepartmentToCloud({
        ...newDept,
        title: newDept.title || newDept.name,
        dept: newDept.name,
      });
      setDepartments((prev) => [...prev.filter((d) => d.id !== saved.id && d.name !== saved.name), saved]);
      return true;
    } catch (err) {
      console.error('Failed to save department:', err);
      return false;
    }
  };

  const handleDeleteDepartment = async (deptId: string) => {
    try {
      await deleteDepartmentFromCloud(deptId);
      setDepartments((prev) => prev.filter((d) => d.id !== deptId));
      return true;
    } catch (err) {
      console.error('Failed to delete department:', err);
      return false;
    }
  };

  const handlePinChanged = (newPin: string) => {
    setAdminPin(newPin);
    sessionStorage.setItem('sumer_admin_pin', newPin);
    localStorage.setItem('sumer_admin_pin', newPin);
  };

  // Fetch all books from Firebase Cloud (with fallback to server and local storage)
  const fetchBooks = async (silent = false) => {
    if (!silent) setIsLoading(true);
    else setIsRefreshing(true);

    try {
      // 1. Fetch from Firebase Cloud Firestore
      const cloudData = await fetchCloudBooks();
      const deletedIds = getDeletedBookIds();
      const validBooks = cloudData.filter(
        (b) => b && !deletedIds.includes(b.id)
      );

      if (validBooks.length > 0) {
        setBooks(validBooks);
        saveLocalBooks(validBooks);
        setIsCloudConnected(true);
      } else {
        setBooks([]);
        saveLocalBooks([]);
      }
    } catch (err) {
      console.warn('Could not fetch from Firebase Cloud, using local cache:', err);
      setIsCloudConnected(false);
      const local = getLocalBooks();
      setBooks(local);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // Setup real-time listener with Google Firebase Cloud Firestore
  useEffect(() => {
    setIsLoading(true);

    // Initial quick load from local cache to prevent empty screen flicker
    const initialLocal = getLocalBooks();
    if (initialLocal.length > 0) {
      setBooks(initialLocal);
    }

    // Subscribe to Firebase Cloud Firestore for real-time synchronization across all devices
    const unsubscribe = subscribeToCloudBooks(
      async (cloudBooks) => {
        setIsCloudConnected(true);
        const deletedIds = getDeletedBookIds();
        const validBooks = cloudBooks.filter(
          (b) => b && !deletedIds.includes(b.id)
        );

        if (validBooks.length > 0) {
          setBooks(validBooks);
          saveLocalBooks(validBooks);
        } else {
          setBooks([]);
          saveLocalBooks([]);
        }
        setIsLoading(false);
        setIsRefreshing(false);
      },
      (err) => {
        console.warn('Real-time Firestore listener notice:', err);
        setIsCloudConnected(false);
        const local = getLocalBooks();
        setBooks(local);
        setIsLoading(false);
        setIsRefreshing(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  // Add book directly to Firebase Cloud
  const handleAddBook = async (newBookData: {
    title: string;
    dept: string;
    stage: string;
    url: string;
    fileName?: string;
    fileSize?: number;
  }): Promise<boolean> => {
    try {
      const bookToAdd: Book = {
        id: `book_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        title: newBookData.title.trim(),
        dept: newBookData.dept,
        stage: newBookData.stage,
        url: newBookData.url.trim(),
        fileName: newBookData.fileName,
        fileSize: newBookData.fileSize,
        uploadedAt: new Date().toISOString()
      };

      // 1. Publish directly to Firebase Cloud Firestore
      const cloudSuccess = await saveBookToCloud(bookToAdd);
      if (cloudSuccess) {
        setIsCloudConnected(true);
      }

      // 2. Also notify backend if available
      try {
        const effectivePin = adminPin || 
          sessionStorage.getItem('sumer_admin_pin') || 
          localStorage.getItem('sumer_admin_pin') || 
          'devsomr11';

        await fetch(apiUrl(`/api/books?adminPin=${encodeURIComponent(effectivePin)}`), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-pin': effectivePin
          },
          body: JSON.stringify({
            ...bookToAdd,
            adminPin: effectivePin
          })
        });
      } catch {
        // Backend not running (normal on Netlify)
      }

      // 3. Immediately update UI state & local backup
      setBooks((prev) => {
        const updated = [bookToAdd, ...prev.filter((b) => b.id !== bookToAdd.id && b.id !== 'book-islamic-1')];
        saveLocalBooks(updated);
        return updated;
      });

      return true;
    } catch (error) {
      console.error('Error adding book to cloud:', error);
      return false;
    }
  };

  // Delete book from Firebase Cloud
  const handleDeleteBook = async (id: string): Promise<boolean> => {
    try {
      // 1. Record ID in local blacklist so it can never reappear
      addDeletedBookId(id);

      // 2. Immediately update state & local storage for instant responsiveness
      setBooks((prev) => {
        const updated = prev.filter((b) => b.id !== id);
        saveLocalBooks(updated);
        return updated;
      });

      // 3. Delete from Firebase Cloud Firestore
      await deleteBookFromCloud(id);

      // 4. Delete from backend if running
      try {
        const effectivePin = adminPin || 
          sessionStorage.getItem('sumer_admin_pin') || 
          localStorage.getItem('sumer_admin_pin') || 
          'devsomr11';

        await fetch(apiUrl(`/api/books/${id}?adminPin=${encodeURIComponent(effectivePin)}`), {
          method: 'DELETE',
          headers: {
            'x-admin-pin': effectivePin
          }
        });
      } catch {
        // static hosting
      }

      return true;
    } catch (error) {
      console.error('Error deleting book from cloud:', error);
      return false;
    }
  };

  // Sync all current books to Cloud Firestore
  const handleSyncAllToCloud = async (): Promise<boolean> => {
    try {
      setIsRefreshing(true);
      const validBooks = books.filter(
        (b) => b && b.id !== 'book-islamic-1' && !b.url?.includes('sample/preview')
      );
      for (const b of validBooks) {
        await saveBookToCloud(b);
      }
      setIsCloudConnected(true);
      return true;
    } catch (err) {
      console.error('Error syncing all books to cloud:', err);
      return false;
    } finally {
      setIsRefreshing(false);
    }
  };

  // Backup download (works universally)
  const handleExportBackup = () => {
    try {
      const validBooks = books.filter(
        (b) => b && b.id !== 'book-islamic-1' && !b.url?.includes('sample/preview')
      );
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(validBooks, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `sumer_library_backup_${new Date().toISOString().slice(0, 10)}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    } catch {
      window.location.href = apiUrl(`/api/backup?adminPin=${encodeURIComponent(adminPin)}`);
    }
  };

  // Import backup & sync to Firebase Cloud
  const handleImportBackup = async (importedBooks: Book[]): Promise<boolean> => {
    try {
      const validBooks = importedBooks.filter(
        (b) => b && b.id !== 'book-islamic-1' && !b.url?.includes('sample/preview')
      );

      // Save each to Firebase Cloud Firestore
      for (const b of validBooks) {
        await saveBookToCloud(b);
      }

      try {
        await fetch(apiUrl('/api/backup/restore'), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-pin': adminPin
          },
          body: JSON.stringify(validBooks)
        });
      } catch {
        // ignore on static host
      }

      setBooks(validBooks);
      saveLocalBooks(validBooks);
      return true;
    } catch (e) {
      console.error('Error restoring backup:', e);
      return false;
    }
  };

  const handleHomeClick = () => {
    setActiveTab('home');
    setCurrentDept(null);
    setCurrentStage(null);
  };

  return (
    <div className={`min-h-screen flex flex-col relative overflow-x-hidden ${
      isDarkMode ? 'bg-[#070e1e] text-slate-100' : 'bg-[#fcfaf3] text-slate-950'
    } font-sans antialiased transition-colors duration-300`}>
      {/* Light Mode / Dark Mode Dynamic Ambient Lighting Halos */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {/* Crisp Technical Grid Mesh */}
        <div className={`absolute inset-0 ${
          isDarkMode
            ? 'bg-[radial-gradient(#94a3b8_0.85px,transparent_0.85px)] opacity-10'
            : 'bg-[radial-gradient(#d97706_0.85px,transparent_0.85px)] opacity-12'
        } [background-size:24px_24px]`} />

        {/* Ambient Orb 1: Royal Golden Yellow in Top Right */}
        <div className={`absolute -top-24 -right-24 w-[32rem] h-[32rem] rounded-full ${
          isDarkMode
            ? 'bg-gradient-to-br from-teal-300/35 via-emerald-200/25 to-transparent opacity-20'
            : 'bg-gradient-to-br from-amber-400/30 via-yellow-300/25 to-transparent opacity-35'
        } blur-3xl animate-pulse [animation-duration:8s]`} />

        {/* Ambient Orb 2: Warm Champagne Gold in Top Left */}
        <div className={`absolute top-48 -left-28 w-[28rem] h-[28rem] rounded-full ${
          isDarkMode
            ? 'bg-gradient-to-tr from-indigo-300/30 via-sky-200/20 to-transparent opacity-20'
            : 'bg-gradient-to-tr from-yellow-400/25 via-amber-300/20 to-transparent opacity-30'
        } blur-3xl`} />

        {/* Ambient Orb 3: Deep Gold in Center Right */}
        <div className={`absolute top-[45%] right-10 w-[30rem] h-[30rem] rounded-full ${
          isDarkMode
            ? 'bg-gradient-to-bl from-amber-200/30 via-yellow-100/20 to-transparent opacity-15'
            : 'bg-gradient-to-bl from-amber-500/20 via-yellow-200/20 to-transparent opacity-25'
        } blur-3xl`} />

        {/* Ambient Orb 4: Subtle Gold Glow in Bottom Left */}
        <div className={`absolute bottom-20 left-10 w-[24rem] h-[24rem] rounded-full ${
          isDarkMode
            ? 'bg-gradient-to-tr from-cyan-200/30 via-teal-100/15 to-transparent opacity-15'
            : 'bg-gradient-to-tr from-yellow-300/20 via-amber-200/15 to-transparent opacity-20'
        } blur-3xl`} />
      </div>

      {/* Top Navigation - shown when inside a department or in tabs */}
      {(currentDept || activeTab !== 'home') && (
        <Navbar
          isAdmin={isAdmin}
          isCloudConnected={isCloudConnected}
          isDarkMode={isDarkMode}
          onToggleDarkMode={toggleDarkMode}
          onToggleAdmin={toggleAdmin}
          onOpenAdminAuth={toggleAdmin}
          onRefreshData={() => fetchBooks(true)}
          isRefreshing={isRefreshing}
          onOpenAbout={() => setIsAboutOpen(true)}
          onHomeClick={handleHomeClick}
          currentDept={currentDept || undefined}
          currentStage={currentStage || undefined}
          currentUserEmail={currentUser?.email || null}
          onOpenGoogleAuth={() => {
            setActiveTab('account');
            setCurrentDept(null);
            setCurrentStage(null);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}

      {/* Main Container with bottom safe padding for fixed BottomNavBar */}
      <main className={`flex-1 max-w-4xl w-full mx-auto px-3 sm:px-5 relative z-10 ${
        activeTab === 'home' && !currentDept ? 'py-2 pb-16 sm:py-3 sm:pb-20' : 'py-3 sm:py-4 pb-24'
      }`}>
        {/* Admin Management Section (If unlocked via PIN outside the admin tab) */}
        {isAdmin && activeTab !== 'admin' && (
          <AdminPanel
            adminPin={adminPin}
            isCloudConnected={isCloudConnected}
            onPinChanged={handlePinChanged}
            onAddBook={handleAddBook}
            onDeleteBook={handleDeleteBook}
            onExportBackup={handleExportBackup}
            onImportBackup={handleImportBackup}
            onSyncAllToCloud={handleSyncAllToCloud}
            totalBooksCount={books.length}
            books={books}
            departments={departments}
            onAddDepartment={async (newDept) => {
              const res = await saveDepartmentToCloud(newDept);
              if (res) {
                const refreshed = await fetchCloudDepartments();
                setDepartments(refreshed);
              }
              return res;
            }}
            onDeleteDepartment={async (deptId) => {
              const res = await deleteDepartmentFromCloud(deptId);
              if (res) {
                const refreshed = await fetchCloudDepartments();
                setDepartments(refreshed);
              }
              return res;
            }}
            onExitAdmin={() => setIsAdmin(false)}
            currentUserEmail={currentUser?.email || null}
            onSignOut={handleSignOutLocal}
          />
        )}

        {/* Loading Indicator */}
        {isLoading ? (
          <div className="py-20 text-center space-y-3">
            <Loader2 className="w-8 h-8 animate-spin text-amber-400 mx-auto" />
            <p className="text-xs sm:text-sm font-bold text-slate-400">
              جارٍ جلب الكتب والمناهج من الخادم المركزي...
            </p>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            {/* Tab 2: Favorites (الكتب المفضلة) */}
            {activeTab === 'favorites' && (
              <motion.div
                key="favorites-view"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.25 }}
              >
                <FavoritesView
                  books={books}
                  favoriteIds={favoriteIds}
                  onToggleFavorite={handleToggleFavorite}
                  onReadBook={handleReadBook}
                  onGoToHome={handleHomeClick}
                />
              </motion.div>
            )}

            {/* Tab 3: Recently Viewed (آخر المشاهدة) */}
            {activeTab === 'recent' && (
              <motion.div
                key="recent-view"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.25 }}
              >
                <RecentView
                  books={books}
                  recentRecords={recentRecords}
                  onReadBook={handleReadBook}
                  favoriteIds={favoriteIds}
                  onToggleFavorite={handleToggleFavorite}
                  onGoToHome={handleHomeClick}
                  onClearRecent={handleClearRecent}
                />
              </motion.div>
            )}

            {/* Tab 5: Admin Panel View (لوحة تحكم الإدارة الخاصة بالمطور - حصراً من حساب الإدارة) */}
            {activeTab === 'admin' && (
              isAdmin ? (
                <motion.div
                  key="developer-admin-view"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.25 }}
                >
                  <AdminPanel
                    adminPin={adminPin}
                    isCloudConnected={isCloudConnected}
                    onPinChanged={handlePinChanged}
                    onAddBook={handleAddBook}
                    onDeleteBook={handleDeleteBook}
                    onExportBackup={handleExportBackup}
                    onImportBackup={handleImportBackup}
                    onSyncAllToCloud={handleSyncAllToCloud}
                    totalBooksCount={books.length}
                    books={books}
                    departments={departments}
                    onAddDepartment={async (newDept) => {
                      const res = await saveDepartmentToCloud(newDept);
                      if (res) {
                        const refreshed = await fetchCloudDepartments();
                        setDepartments(refreshed);
                      }
                      return res;
                    }}
                    onDeleteDepartment={async (deptId) => {
                      const res = await deleteDepartmentFromCloud(deptId);
                      if (res) {
                        const refreshed = await fetchCloudDepartments();
                        setDepartments(refreshed);
                      }
                      return res;
                    }}
                    onExitAdmin={() => setActiveTab('home')}
                    currentUserEmail={currentUser?.email || null}
                    onSignOut={handleSignOutLocal}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="admin-account-required"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.25 }}
                >
                  <AccountView
                    currentUser={currentUser}
                    isAdmin={isAdmin}
                    favoritesCount={favoriteIds.length}
                    recentCount={recentRecords.length}
                    departments={departments}
                    onGoToHome={handleHomeClick}
                    onUserAuthChange={handleUserAuthChange}
                    onGoToAdminTab={() => {
                      setActiveTab('admin');
                      setIsAdmin(true);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                </motion.div>
              )
            )}

            {/* Tab 4: Account (الحساب) */}
            {activeTab === 'account' && (
              <motion.div
                key="account-view"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.25 }}
              >
                <AccountView
                  currentUser={currentUser}
                  isAdmin={isAdmin}
                  favoritesCount={favoriteIds.length}
                  recentCount={recentRecords.length}
                  departments={departments}
                  onGoToHome={handleHomeClick}
                  onUserAuthChange={handleUserAuthChange}
                  onGoToAdminTab={() => {
                    setActiveTab('admin');
                    setIsAdmin(true);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              </motion.div>
            )}

            {/* Tab 1: Home (الرئيسية) - Sumerian Interface matching the screenshot */}
            {activeTab === 'home' && !currentDept && (
              <motion.div
                key="sumer-home-view"
                initial={{ opacity: 0, y: 16, filter: 'blur(4px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -16, filter: 'blur(4px)' }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              >
                <SumerHomeView
                  books={books}
                  departments={departments}
                  onSelectDept={(dept) => {
                    setCurrentDept(dept);
                    setCurrentStage(null);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onReadBook={handleReadBook}
                  favoriteIds={favoriteIds}
                  onToggleFavorite={handleToggleFavorite}
                  isAdmin={isAdmin}
                  onOpenAdmin={toggleAdmin}
                  isDarkMode={isDarkMode}
                  onToggleDarkMode={toggleDarkMode}
                  onOpenAbout={() => setIsAboutOpen(true)}
                  onRefreshData={() => fetchBooks(true)}
                  isRefreshing={isRefreshing}
                  onViewAllBooks={() => {
                    window.scrollTo({ top: 380, behavior: 'smooth' });
                  }}
                  currentUserEmail={currentUser?.email || null}
                  onOpenGoogleAuth={() => {
                    setActiveTab('account');
                    setCurrentDept(null);
                    setCurrentStage(null);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              </motion.div>
            )}

            {/* Home - View 2: Stages */}
            {activeTab === 'home' && currentDept && !currentStage && (
              <motion.div
                key={`stages-${currentDept}`}
                initial={{ opacity: 0, y: 20, scale: 0.98, filter: 'blur(4px)' }}
                animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -20, scale: 0.98, filter: 'blur(4px)' }}
                transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
                className="space-y-4 sm:space-y-5"
              >
                {currentDept === 'الأمن السيبراني' ? (
                  <CyberStageSelector
                    books={books}
                    onBackToDepts={() => {
                      setCurrentDept(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onSelectStage={(stage) => {
                      setCurrentStage(stage);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : currentDept === 'الكهرباء' ? (
                  <ElectricStageSelector
                    books={books}
                    onBackToDepts={() => {
                      setCurrentDept(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onSelectStage={(stage) => {
                      setCurrentStage(stage);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : currentDept === 'الحاسبات' ? (
                  <ComputerStageSelector
                    books={books}
                    onBackToDepts={() => {
                      setCurrentDept(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onSelectStage={(stage) => {
                      setCurrentStage(stage);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : currentDept === 'إلكترونيك السيطرة والخزن' ? (
                  <ElectronicsStageSelector
                    books={books}
                    onBackToDepts={() => {
                      setCurrentDept(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onSelectStage={(stage) => {
                      setCurrentStage(stage);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : (
                  <StagesView
                    currentDept={currentDept}
                    onBackToDepts={() => {
                      setCurrentDept(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onSelectStage={(stage) => {
                      setCurrentStage(stage);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    books={books}
                    onReadBook={handleReadBook}
                    favoriteIds={favoriteIds}
                    onToggleFavorite={handleToggleFavorite}
                  />
                )}

                {/* "وجوه تظهر آخر الكتب أضافه للتطبيق" (Recently Added in this Department or Overall) */}
                <div className="pt-2">
                  <RecentlyAddedSection
                    books={books.filter((b) => b.dept === currentDept).length > 0 ? books.filter((b) => b.dept === currentDept) : books}
                    onReadBook={handleReadBook}
                    favoriteIds={favoriteIds}
                    onToggleFavorite={handleToggleFavorite}
                    title={`آخر الكتب المضافة لـ ${currentDept}`}
                    subTitle="أحدث المناهج والكتب المقررة لهذا التخصص"
                    limit={6}
                  />
                </div>
              </motion.div>
            )}

            {/* Home - View 3: Books */}
            {activeTab === 'home' && currentDept && currentStage && (
              <motion.div
                key={`books-${currentDept}-${currentStage}`}
                initial={{ opacity: 0, scale: 0.98, y: 20, filter: 'blur(4px)' }}
                animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, scale: 0.98, y: -20, filter: 'blur(4px)' }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              >
                {currentDept === 'الأمن السيبراني' ? (
                  <CyberBooksVault
                    currentStage={currentStage}
                    books={books}
                    isAdmin={isAdmin}
                    onBackToStages={() => {
                      setCurrentStage(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onReadBook={handleReadBook}
                    onDeleteBook={handleDeleteBook}
                    onOpenAdmin={() => {
                      if (!isAdmin) toggleAdmin();
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : currentDept === 'الكهرباء' ? (
                  <ElectricBooksVault
                    currentStage={currentStage}
                    books={books}
                    isAdmin={isAdmin}
                    onBackToStages={() => {
                      setCurrentStage(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onReadBook={handleReadBook}
                    onDeleteBook={handleDeleteBook}
                    onOpenAdmin={() => {
                      if (!isAdmin) toggleAdmin();
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : currentDept === 'الحاسبات' ? (
                  <ComputerBooksVault
                    currentStage={currentStage}
                    books={books}
                    isAdmin={isAdmin}
                    onBackToStages={() => {
                      setCurrentStage(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onReadBook={handleReadBook}
                    onDeleteBook={handleDeleteBook}
                    onOpenAdmin={() => {
                      if (!isAdmin) toggleAdmin();
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : currentDept === 'إلكترونيك السيطرة والخزن' ? (
                  <ElectronicsBooksVault
                    currentStage={currentStage}
                    books={books}
                    isAdmin={isAdmin}
                    onBackToStages={() => {
                      setCurrentStage(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onReadBook={handleReadBook}
                    onDeleteBook={handleDeleteBook}
                    onOpenAdmin={() => {
                      if (!isAdmin) toggleAdmin();
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ) : (
                  <BooksView
                    currentDept={currentDept}
                    currentStage={currentStage}
                    books={books}
                    isAdmin={isAdmin}
                    onBackToStages={() => {
                      setCurrentStage(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    onReadBook={handleReadBook}
                    onDeleteBook={handleDeleteBook}
                    onOpenAdmin={() => {
                      if (!isAdmin) toggleAdmin();
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    favoriteIds={favoriteIds}
                    onToggleFavorite={handleToggleFavorite}
                  />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </main>

      {/* Persistent Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === 'admin') {
            if (isAdmin) {
              setActiveTab('admin');
            } else {
              setActiveTab('account');
            }
          } else {
            setActiveTab(tab);
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        favoritesCount={favoriteIds.length}
        recentCount={recentRecords.length}
        userEmail={currentUser?.email || null}
        isDeveloperAdmin={isAdmin}
      />

      {/* Footer - Only shown in sub-views; Home has its own compact integrated footer with discreet admin link */}
      {(currentDept || activeTab !== 'home') && (
        <footer className="bg-[#0a1426] border-t border-slate-800/80 py-4 mt-8 transition-colors duration-300">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-right text-xs text-slate-400">
            <div className="space-y-0.5">
              <p className="font-extrabold text-slate-200">
                مكتبة مدرسة سومر المهنية الإلكترونية
              </p>
              <p className="text-[11px] text-slate-400">
                موسوعة الكتب والمناهج الوزارية التخصصية - هذا العمل من قبل الطالب{' '}
                <span className="font-bold text-amber-400">سجاد محمد</span> وهو إهداء لمدرسة سومر المهنية (قسم الأمن السيبراني)
              </p>
            </div>

            <div className="flex items-center gap-3 text-[11px] font-bold">
              <button
                onClick={() => setIsAboutOpen(true)}
                className="text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
              >
                حول التطبيق
              </button>
              <button
                onClick={() => fetchBooks(true)}
                disabled={isRefreshing}
                className="text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>تحديث البيانات</span>
              </button>
            </div>
          </div>
        </footer>
      )}

      {/* PDF Reader Modal */}
      <PdfReaderModal
        book={readingBook}
        onClose={() => setReadingBook(null)}
      />

      {/* About Application Modal */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        currentUserEmail={currentUser?.email || null}
        onOpenGoogleAuth={() => {
          setIsAboutOpen(false);
          setActiveTab('account');
          setCurrentDept(null);
          setCurrentStage(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    </div>
  );
}
