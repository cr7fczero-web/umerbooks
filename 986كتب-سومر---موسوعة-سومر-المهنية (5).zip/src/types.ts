export interface Book {
  id: string;
  title: string;
  dept: string;
  stage: string;
  url: string;
  fileName?: string;
  fileSize?: number;
  uploadedAt?: string;
}

export type DepartmentId = string;
export type StageId = 'المرحلة الأولى' | 'المرحلة الثانية' | 'المرحلة الثالثة';

export interface DepartmentItem {
  id: string;
  name: string;
  title: string;
  dept: string;
  description?: string;
  iconName: string;
  colorTheme?: string;
  isCustom?: boolean;
  createdAt?: string;
}

export interface DepartmentInfo {
  id: DepartmentId;
  name: string;
  description: string;
  iconName: string;
  accentColor: string;
}

export interface StageInfo {
  id: StageId;
  name: string;
  description: string;
  numberText: string;
}
