import { Book } from '../types';

// Default books array is strictly empty so that only real books published by the admin (e.g. Google Drive links) appear.
export const DEFAULT_BOOKS: Book[] = [];
