import { Book } from '../types';

const DB_NAME = 'SumerVocationalDB';
const DB_VERSION = 1;
const STORE_NAME = 'pdf_files';
const LOCAL_BOOKS_KEY = 'sumer_local_books_backup';
const CUSTOM_BACKEND_KEY = 'sumer_custom_backend_url';

// Open or initialize IndexedDB for client-side PDF blobs
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this browser'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Save a PDF blob to local IndexedDB
export async function savePdfToIndexedDB(id: string, file: Blob, fileName: string): Promise<string> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const record = {
        id,
        blob: file,
        fileName,
        type: file.type || 'application/pdf',
        updatedAt: Date.now()
      };
      const req = store.put(record);
      req.onsuccess = () => {
        // Create an active blob URL
        const blobUrl = URL.createObjectURL(file);
        resolve(blobUrl);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('Could not save to IndexedDB, fallback to objectURL:', err);
    return URL.createObjectURL(file);
  }
}

// Retrieve a PDF blob from IndexedDB and return an object URL
export async function getPdfFromIndexedDB(id: string): Promise<string | null> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => {
        if (req.result && req.result.blob) {
          const blobUrl = URL.createObjectURL(req.result.blob);
          resolve(blobUrl);
        } else {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

// Detect if running on a static hosting environment (like Netlify, GitHub Pages, or Vercel static)
export function isStaticHost(): boolean {
  if (typeof window === 'undefined') return false;
  const hostname = window.location.hostname.toLowerCase();
  return (
    hostname.includes('netlify.app') ||
    hostname.includes('github.io') ||
    hostname.includes('surge.sh') ||
    hostname.includes('vercel.app')
  );
}

// Get backend API base URL
export function getBackendBaseUrl(): string {
  if (typeof window === 'undefined') return '';
  const custom = localStorage.getItem(CUSTOM_BACKEND_KEY);
  if (custom && custom.trim()) {
    return custom.trim().replace(/\/+$/, '');
  }
  return '';
}

// Set custom backend API URL
export function setBackendBaseUrl(url: string) {
  if (typeof window === 'undefined') return;
  if (!url || !url.trim()) {
    localStorage.removeItem(CUSTOM_BACKEND_KEY);
  } else {
    localStorage.setItem(CUSTOM_BACKEND_KEY, url.trim().replace(/\/+$/, ''));
  }
}

// Format API endpoint
export function apiUrl(endpoint: string): string {
  const clean = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const base = getBackendBaseUrl();
  return base ? `${base}${clean}` : clean;
}

// Local storage helpers for books
const DELETED_BOOKS_KEY = 'sumer_deleted_book_ids';

export function getDeletedBookIds(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(DELETED_BOOKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addDeletedBookId(id: string) {
  if (typeof window === 'undefined') return;
  try {
    const current = getDeletedBookIds();
    if (!current.includes(id)) {
      current.push(id);
      localStorage.setItem(DELETED_BOOKS_KEY, JSON.stringify(current));
    }
  } catch (e) {
    console.warn('Failed to record deleted book ID:', e);
  }
}

export function getLocalBooks(): Book[] {
  if (typeof window === 'undefined') return [];
  try {
    const deletedIds = getDeletedBookIds();
    let raw = localStorage.getItem(LOCAL_BOOKS_KEY);
    if (!raw) {
      raw = localStorage.getItem('sumer_books_library');
    }
    if (!raw) return [];
    const parsed: Book[] = JSON.parse(raw);
    const cleaned = parsed.filter(
      (b) =>
        b &&
        b.id !== 'book-islamic-1' &&
        !b.id.startsWith('book-cyber-') &&
        !b.id.startsWith('book-electric-') &&
        !b.id.startsWith('book-digital-') &&
        !b.id.startsWith('book-computer-') &&
        !b.id.startsWith('book-control-') &&
        !b.url?.includes('supabase.co') &&
        !b.url?.includes('sample/preview') &&
        !b.url?.includes('dummy.pdf') &&
        !deletedIds.includes(b.id)
    );
    if (cleaned.length !== parsed.length) {
      saveLocalBooks(cleaned);
    }
    return cleaned;
  } catch {
    return [];
  }
}

export function saveLocalBooks(books: Book[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(LOCAL_BOOKS_KEY, JSON.stringify(books));
  } catch (e) {
    console.warn('Failed to save books to local storage:', e);
  }
}

// Student Favorites storage helpers (Per-User or Guest)
const FAVORITES_KEY = 'sumer_student_favorites';

function getFavoritesStorageKey(userEmail?: string | null): string {
  if (userEmail && userEmail.trim()) {
    return `sumer_favorites_${userEmail.trim().toLowerCase()}`;
  }
  return FAVORITES_KEY;
}

export function getFavoriteBookIds(userEmail?: string | null): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const key = getFavoritesStorageKey(userEmail);
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
    
    // Fallback: If logged-in user has no favorites yet, check guest favorites to avoid data loss
    if (userEmail) {
      const guestRaw = localStorage.getItem(FAVORITES_KEY);
      if (guestRaw) {
        const guestParsed = JSON.parse(guestRaw);
        if (Array.isArray(guestParsed) && guestParsed.length > 0) {
          localStorage.setItem(key, JSON.stringify(guestParsed));
          return guestParsed;
        }
      }
    }
    return [];
  } catch {
    return [];
  }
}

export function toggleFavoriteBookId(bookId: string, userEmail?: string | null): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const key = getFavoritesStorageKey(userEmail);
    const current = getFavoriteBookIds(userEmail);
    const exists = current.includes(bookId);
    let updated: string[];
    if (exists) {
      updated = current.filter((id) => id !== bookId);
    } else {
      updated = [bookId, ...current];
    }
    localStorage.setItem(key, JSON.stringify(updated));
    // Also sync to general key for consistent guest experience
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    return !exists;
  } catch {
    return false;
  }
}

export function isBookFavorite(bookId: string, userEmail?: string | null): boolean {
  return getFavoriteBookIds(userEmail).includes(bookId);
}

// Student Recently Viewed storage helpers (Per-User or Guest)
const RECENT_VIEWED_KEY = 'sumer_recently_viewed_books';

function getRecentStorageKey(userEmail?: string | null): string {
  if (userEmail && userEmail.trim()) {
    return `sumer_recent_${userEmail.trim().toLowerCase()}`;
  }
  return RECENT_VIEWED_KEY;
}

export interface RecentViewRecord {
  bookId: string;
  viewedAt: number;
}

export function getRecentlyViewedRecords(userEmail?: string | null): RecentViewRecord[] {
  if (typeof window === 'undefined') return [];
  try {
    const key = getRecentStorageKey(userEmail);
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);

    // Fallback to guest history if user has none yet
    if (userEmail) {
      const guestRaw = localStorage.getItem(RECENT_VIEWED_KEY);
      if (guestRaw) {
        const guestParsed = JSON.parse(guestRaw);
        if (Array.isArray(guestParsed) && guestParsed.length > 0) {
          localStorage.setItem(key, JSON.stringify(guestParsed));
          return guestParsed;
        }
      }
    }
    return [];
  } catch {
    return [];
  }
}

export function recordRecentlyViewed(bookId: string, userEmail?: string | null): void {
  if (typeof window === 'undefined') return;
  try {
    const key = getRecentStorageKey(userEmail);
    const current = getRecentlyViewedRecords(userEmail).filter((r) => r.bookId !== bookId);
    const updated: RecentViewRecord[] = [
      { bookId, viewedAt: Date.now() },
      ...current.slice(0, 49) // Keep last 50
    ];
    localStorage.setItem(key, JSON.stringify(updated));
    localStorage.setItem(RECENT_VIEWED_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn('Failed to record recently viewed:', e);
  }
}

export function clearRecentlyViewed(userEmail?: string | null): void {
  if (typeof window === 'undefined') return;
  try {
    const key = getRecentStorageKey(userEmail);
    localStorage.removeItem(key);
    localStorage.removeItem(RECENT_VIEWED_KEY);
  } catch (e) {
    console.warn('Failed to clear recently viewed:', e);
  }
}
