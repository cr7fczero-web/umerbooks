import { recordBookOpenToCloud } from './cloudStats';

// Simple and persistent client-side engagement and interaction analytics

const DEPT_INTERACTION_KEY = 'sumer_dept_interactions_v1';
const BOOK_READS_KEY = 'sumer_book_reads_v1';

// Initial realistic baseline interactions for vocational departments
const DEFAULT_DEPT_BASELINES: Record<string, number> = {
  'إلكترونيك السيطرة والخزن': 342,
  'الكهرباء': 289,
  'الأمن السيبراني': 415,
  'الحاسبات': 378
};

export function getDepartmentInteractions(): Record<string, number> {
  try {
    const raw = localStorage.getItem(DEPT_INTERACTION_KEY);
    if (!raw) {
      localStorage.setItem(DEPT_INTERACTION_KEY, JSON.stringify(DEFAULT_DEPT_BASELINES));
      return { ...DEFAULT_DEPT_BASELINES };
    }
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_DEPT_BASELINES, ...parsed };
  } catch {
    return { ...DEFAULT_DEPT_BASELINES };
  }
}

export function getBookReadCounts(): Record<string, number> {
  try {
    const raw = localStorage.getItem(BOOK_READS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function getTotalInteractionsCount(): number {
  const depts = getDepartmentInteractions();
  return Object.values(depts).reduce((acc, curr) => acc + curr, 0);
}

export function recordBookInteraction(bookId: string, dept: string, title?: string): void {
  try {
    // 1. Increment department interaction
    const depts = getDepartmentInteractions();
    depts[dept] = (depts[dept] || 0) + 1;
    localStorage.setItem(DEPT_INTERACTION_KEY, JSON.stringify(depts));

    // 2. Increment specific book read count
    const books = getBookReadCounts();
    books[bookId] = (books[bookId] || 0) + 1;
    localStorage.setItem(BOOK_READS_KEY, JSON.stringify(books));

    // 3. Record open to Firebase Cloud & backend
    recordBookOpenToCloud(bookId, title, dept).catch(() => {});

    // Dispatch a storage-like custom event so dashboard re-renders if open
    window.dispatchEvent(new CustomEvent('sumer_interaction_updated'));
  } catch (err) {
    console.warn('Could not record interaction:', err);
  }
}
