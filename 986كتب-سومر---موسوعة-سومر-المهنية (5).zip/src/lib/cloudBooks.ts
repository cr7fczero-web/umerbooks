import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy 
} from 'firebase/firestore';
import { db } from './firebase';
import { Book } from '../types';

const COLLECTION_NAME = 'books';

// Helper to sanitize doc ID
export function sanitizeDocId(rawId: string): string {
  const sanitized = rawId.replace(/[^a-zA-Z0-9_\-]/g, '_');
  return sanitized.length > 0 ? sanitized : `book_${Date.now()}`;
}

// Strict validator to ensure no dead Supabase links or dummy placeholder books are parsed
export function isValidBookRecord(id: string, data: Partial<Book>): boolean {
  if (!id || id === 'book-islamic-1' || data.id === 'book-islamic-1') return false;
  if (
    id.startsWith('book-cyber-') ||
    id.startsWith('book-electric-') ||
    id.startsWith('book-digital-') ||
    id.startsWith('book-computer-') ||
    id.startsWith('book-control-')
  ) {
    return false;
  }
  const url = (data.url || '').trim().toLowerCase();
  if (!url) return false;
  // Block any dead Supabase storage URLs or dummy test PDFs
  if (url.includes('supabase.co') || url.includes('dummy.pdf') || url.includes('sample/preview')) {
    return false;
  }
  return true;
}

// Subscribe to real-time updates from Firebase Cloud Firestore
export function subscribeToCloudBooks(
  onUpdate: (books: Book[]) => void,
  onError?: (error: unknown) => void
): () => void {
  try {
    const booksCol = collection(db, COLLECTION_NAME);
    const q = query(booksCol, orderBy('uploadedAt', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const books: Book[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as Partial<Book>;
          if (!isValidBookRecord(docSnap.id, data)) {
            return;
          }
          books.push({
            id: docSnap.id,
            title: data.title || '',
            dept: data.dept || '',
            stage: data.stage || '',
            url: (data.url || '').trim(),
            fileName: data.fileName,
            fileSize: data.fileSize,
            uploadedAt: data.uploadedAt || new Date().toISOString()
          });
        });
        onUpdate(books);
      },
      (err) => {
        console.warn('Firestore real-time subscription error:', err);
        if (onError) onError(err);
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('Failed to setup Firestore subscription:', err);
    if (onError) onError(err);
    return () => {};
  }
}

// One-time fetch from Firebase Cloud
export async function fetchCloudBooks(): Promise<Book[]> {
  try {
    const booksCol = collection(db, COLLECTION_NAME);
    const snapshot = await getDocs(booksCol);
    const books: Book[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data() as Partial<Book>;
      if (!isValidBookRecord(docSnap.id, data)) {
        return;
      }
      books.push({
        id: docSnap.id,
        title: data.title || '',
        dept: data.dept || '',
        stage: data.stage || '',
        url: (data.url || '').trim(),
        fileName: data.fileName,
        fileSize: data.fileSize,
        uploadedAt: data.uploadedAt || new Date().toISOString()
      });
    });
    // Sort descending by uploadedAt
    books.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
    return books;
  } catch (err) {
    console.warn('Failed to fetch from Firebase Cloud:', err);
    throw err;
  }
}

// Add or update a book in the Cloud
export async function saveBookToCloud(book: Book): Promise<boolean> {
  if (!isValidBookRecord(book.id, book)) {
    console.warn('Blocked attempt to save invalid/dead book to cloud:', book.id);
    return false;
  }
  try {
    const cleanId = sanitizeDocId(book.id);
    const bookDocRef = doc(db, COLLECTION_NAME, cleanId);
    
    // Clean data object without undefined values
    const dataToSave: Record<string, any> = {
      title: book.title,
      dept: book.dept,
      stage: book.stage,
      url: book.url.trim(),
      uploadedAt: book.uploadedAt || new Date().toISOString()
    };

    if (book.fileName) dataToSave.fileName = book.fileName;
    if (typeof book.fileSize === 'number') dataToSave.fileSize = book.fileSize;

    await setDoc(bookDocRef, dataToSave, { merge: true });
    return true;
  } catch (err) {
    console.error('Error saving book to Firebase Cloud:', err);
    return false;
  }
}

// Delete a book from the Cloud
export async function deleteBookFromCloud(bookId: string): Promise<boolean> {
  try {
    const cleanId = sanitizeDocId(bookId);
    const bookDocRef = doc(db, COLLECTION_NAME, cleanId);
    await deleteDoc(bookDocRef);
    return true;
  } catch (err) {
    console.error('Error deleting book from Firebase Cloud:', err);
    return false;
  }
}
