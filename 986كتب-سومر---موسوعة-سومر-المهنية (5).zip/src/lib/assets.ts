// Sumerian Visual Assets
import zigguratHero from '../assets/images/ziggurat_hero_1790325597047.jpg';
import sumerRelief from '../assets/images/sumer_relief_1790325610570.jpg';
import sumerLogo from '../assets/images/sumer_logo_1790325623578.jpg';
import bookCyber from '../assets/images/book_cyber_1790325637595.jpg';
import bookElectric from '../assets/images/book_electric_1790325650258.jpg';
import bookElectronics from '../assets/images/book_electronics_1790325662931.jpg';

export const ASSETS = {
  zigguratHero,
  sumerRelief,
  sumerLogo,
  bookCyber,
  bookElectric,
  bookElectronics
};

export function getBookCoverImage(title: string, dept: string): string {
  const t = title.toLowerCase();
  const d = dept.toLowerCase();

  if (d.includes('سيبراني') || t.includes('سيبران') || t.includes('أمن')) {
    return bookCyber;
  }
  if (d.includes('كهرباء') || t.includes('كهربا') || t.includes('شبكات')) {
    return bookElectric;
  }
  if (d.includes('إلكترونيك') || d.includes('الكترونيك') || t.includes('إلكترون') || t.includes('رقمي') || t.includes('سيطرة')) {
    return bookElectronics;
  }
  if (d.includes('حاسبات') || t.includes('حاسوب') || t.includes('برمج')) {
    return bookCyber;
  }
  return bookCyber;
}
