import React from 'react';
import { 
  Laptop, 
  Zap, 
  Cpu, 
  ShieldCheck, 
  Stethoscope, 
  Activity, 
  Sparkles, 
  Wrench, 
  Flame, 
  Radio, 
  Car, 
  Plane, 
  FlaskConical, 
  HeartPulse, 
  Snowflake, 
  Compass, 
  Hammer, 
  Printer, 
  Sprout, 
  Layers, 
  Atom, 
  Cog,
  Microscope,
  Eye,
  Crosshair,
  Lightbulb,
  BookOpen
} from 'lucide-react';
import { collection, doc, getDocs, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';
import { DepartmentItem } from '../types';

export const DEPARTMENTS_COLLECTION = 'departments';
export const LOCAL_DEPTS_KEY = 'sumer_custom_departments';

export const DEFAULT_DEPARTMENTS: DepartmentItem[] = [
  {
    id: 'حاسبات',
    name: 'الحاسبات',
    title: 'الحاسبات',
    dept: 'الحاسبات',
    description: 'علوم وهندسة الحاسوب والبرمجيات وشبكات المعلومات',
    iconName: 'Laptop',
    colorTheme: 'amber',
    isCustom: false
  },
  {
    id: 'كهرباء',
    name: 'الكهرباء',
    title: 'الكهرباء',
    dept: 'الكهرباء',
    description: 'توليد ونقل الطاقة الكهربائية والآلات والتمديدات الصناعية',
    iconName: 'Zap',
    colorTheme: 'emerald',
    isCustom: false
  },
  {
    id: 'إلكترونيك',
    name: 'إلكترونيك السيطرة والخزن',
    title: 'الإلكترونيك',
    dept: 'إلكترونيك السيطرة والخزن',
    description: 'أنظمة السيطرة الرقمية والمعالجات والدوائر المتكاملة',
    iconName: 'Cpu',
    colorTheme: 'indigo',
    isCustom: false
  },
  {
    id: 'أمن سيبراني',
    name: 'الأمن السيبراني',
    title: 'أمن سيبراني',
    dept: 'الأمن السيبراني',
    description: 'حماية الشبكات والبيانات الرقمية وأنظمة التشفير الدفاعي',
    iconName: 'ShieldCheck',
    colorTheme: 'blue',
    isCustom: false
  }
];

// Rich set of selectable department icons for vocational specializations
export interface IconOption {
  id: string;
  name: string;
  category: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const DEPARTMENT_ICON_OPTIONS: IconOption[] = [
  { id: 'Stethoscope', name: 'أجهزة طبية ومختبرية', category: 'العلوم الطبية', icon: Stethoscope },
  { id: 'Activity', name: 'أجهزة حيوية وفسلجة', category: 'العلوم الطبية', icon: Activity },
  { id: 'HeartPulse', name: 'تمريض وتقنيات صحية', category: 'العلوم الطبية', icon: HeartPulse },
  { id: 'Sparkles', name: 'ليزر وكهروبصريات', category: 'التقنيات الحديثة', icon: Sparkles },
  { id: 'Atom', name: 'فيزياء ذرية وتطبيقية', category: 'التقنيات الحديثة', icon: Atom },
  { id: 'Laptop', name: 'حاسبات وبرمجيات', category: 'تكنولوجيا المعلومات', icon: Laptop },
  { id: 'Cpu', name: 'إلكترونيك وسيطرة ونظم', category: 'الهندسة الكهربائية', icon: Cpu },
  { id: 'ShieldCheck', name: 'أمن سيبراني وشبكات', category: 'تكنولوجيا المعلومات', icon: ShieldCheck },
  { id: 'Zap', name: 'كهرباء وقوى وطاقة', category: 'الهندسة الكهربائية', icon: Zap },
  { id: 'Radio', name: 'اتصالات وأجهزة لاسلكية', category: 'الهندسة الكهربائية', icon: Radio },
  { id: 'Wrench', name: 'ميكانيك عام وتصنيع', category: 'الهندسة الميكانيكية', icon: Wrench },
  { id: 'Cog', name: 'إنتاج ومكائن صناعية', category: 'الهندسة الميكانيكية', icon: Cog },
  { id: 'Flame', name: 'نفط وتكرير وبتروكيماويات', category: 'الصناعات النفطية', icon: Flame },
  { id: 'Car', name: 'ميكانيك وكهرباء سيارات', category: 'النقل والمركبات', icon: Car },
  { id: 'Plane', name: 'تقنيات وصيانة طيران', category: 'النقل والمركبات', icon: Plane },
  { id: 'Snowflake', name: 'تبريد وتكييف هواء', category: 'الهندسة الميكانيكية', icon: Snowflake },
  { id: 'FlaskConical', name: 'كيمياء وصناعات كيميائية', category: 'العلوم التطبيقية', icon: FlaskConical },
  { id: 'Microscope', name: 'تحليلات مرضية ومختبرات', category: 'العلوم التطبيقية', icon: Microscope },
  { id: 'Compass', name: 'مساحة وبناء ورسم هندسي', category: 'الهندسة المدنية', icon: Compass },
  { id: 'Hammer', name: 'إنشاءات ومعادن ونجارة', category: 'الهندسة المدنية', icon: Hammer },
  { id: 'Printer', name: 'طباعة وفنون تطبيقية', category: 'الفنون والتصميم', icon: Printer },
  { id: 'Sprout', name: 'زراعة وإنتاج نباتي وحيواني', category: 'الزراعة والبيئة', icon: Sprout },
  { id: 'Lightbulb', name: 'ابتكارات وريادة أعمال', category: 'عام', icon: Lightbulb },
  { id: 'Layers', name: 'مهن وتقنيات عامة', category: 'عام', icon: Layers }
];

export const COLOR_THEMES = [
  { id: 'amber', name: 'كهرماني / ذهبي', bg: 'bg-amber-500/15', text: 'text-amber-400', border: 'border-amber-500/30', ring: 'ring-amber-400', badge: 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300' },
  { id: 'emerald', name: 'زمردي / أخضر', bg: 'bg-emerald-500/15', text: 'text-emerald-400', border: 'border-emerald-500/30', ring: 'ring-emerald-400', badge: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' },
  { id: 'indigo', name: 'نيلي / بنفسجي داكن', bg: 'bg-indigo-500/15', text: 'text-indigo-400', border: 'border-indigo-500/30', ring: 'ring-indigo-400', badge: 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' },
  { id: 'blue', name: 'أزرق سماوي', bg: 'bg-blue-500/15', text: 'text-blue-400', border: 'border-blue-500/30', ring: 'ring-blue-400', badge: 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300' },
  { id: 'rose', name: 'وردي / ياقوتي', bg: 'bg-rose-500/15', text: 'text-rose-400', border: 'border-rose-500/30', ring: 'ring-rose-400', badge: 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300' },
  { id: 'purple', name: 'بنفسجي ملكي', bg: 'bg-purple-500/15', text: 'text-purple-400', border: 'border-purple-500/30', ring: 'ring-purple-400', badge: 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300' },
  { id: 'cyan', name: 'فيروزي / سيان', bg: 'bg-cyan-500/15', text: 'text-cyan-400', border: 'border-cyan-500/30', ring: 'ring-cyan-400', badge: 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300' },
  { id: 'teal', name: 'تيل / زيتي نضر', bg: 'bg-teal-500/15', text: 'text-teal-400', border: 'border-teal-500/30', ring: 'ring-teal-400', badge: 'bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300' }
];

export function getDepartmentIcon(iconName: string): React.ComponentType<{ className?: string }> {
  const match = DEPARTMENT_ICON_OPTIONS.find((item) => item.id.toLowerCase() === iconName.toLowerCase());
  if (match) return match.icon;

  switch (iconName.toLowerCase()) {
    case 'laptop': return Laptop;
    case 'zap': return Zap;
    case 'cpu': return Cpu;
    case 'shieldcheck': return ShieldCheck;
    case 'stethoscope': return Stethoscope;
    case 'activity': return Activity;
    case 'sparkles': return Sparkles;
    case 'wrench': return Wrench;
    case 'flame': return Flame;
    case 'radio': return Radio;
    case 'car': return Car;
    case 'plane': return Plane;
    case 'flaskconical': return FlaskConical;
    case 'heartpulse': return HeartPulse;
    case 'snowflake': return Snowflake;
    case 'compass': return Compass;
    case 'hammer': return Hammer;
    case 'printer': return Printer;
    case 'sprout': return Sprout;
    case 'atom': return Atom;
    default: return Layers;
  }
}

export function getColorThemeClasses(colorTheme?: string) {
  const theme = COLOR_THEMES.find((t) => t.id === colorTheme) || COLOR_THEMES[0];
  return {
    iconBg: `${theme.bg} ${theme.text} border ${theme.border}`,
    activeRing: theme.ring,
    badge: theme.badge
  };
}

export function getLocalDepartments(): DepartmentItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_DEPTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Error reading local departments:', err);
  }
  return DEFAULT_DEPARTMENTS;
}

export function saveLocalDepartments(depts: DepartmentItem[]) {
  try {
    localStorage.setItem(LOCAL_DEPTS_KEY, JSON.stringify(depts));
  } catch (err) {
    console.warn('Error saving local departments:', err);
  }
}

// Fetch departments from Firestore and merge with defaults
export async function fetchCloudDepartments(): Promise<DepartmentItem[]> {
  try {
    const colRef = collection(db, DEPARTMENTS_COLLECTION);
    const snap = await getDocs(colRef);
    const customDepts: DepartmentItem[] = [];

    snap.forEach((docSnap) => {
      const data = docSnap.data() as Partial<DepartmentItem>;
      if (data && data.name) {
        customDepts.push({
          id: docSnap.id,
          name: data.name,
          title: data.title || data.name,
          dept: data.dept || data.name,
          description: data.description || '',
          iconName: data.iconName || 'Layers',
          colorTheme: data.colorTheme || 'teal',
          isCustom: true,
          createdAt: data.createdAt
        });
      }
    });

    // Merge: DEFAULT_DEPARTMENTS + any new custom departments (avoiding duplicates)
    const existingNames = new Set(DEFAULT_DEPARTMENTS.map((d) => d.name));
    const merged = [...DEFAULT_DEPARTMENTS];

    for (const c of customDepts) {
      if (!existingNames.has(c.name)) {
        merged.push(c);
        existingNames.add(c.name);
      }
    }

    saveLocalDepartments(merged);
    return merged;
  } catch (err) {
    console.warn('Failed to fetch departments from Firestore, using local cache:', err);
    return getLocalDepartments();
  }
}

// Real-time subscription to departments
export function subscribeToCloudDepartments(
  onUpdate: (depts: DepartmentItem[]) => void
): () => void {
  try {
    const colRef = collection(db, DEPARTMENTS_COLLECTION);
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot) => {
        const customDepts: DepartmentItem[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as Partial<DepartmentItem>;
          if (data && data.name) {
            customDepts.push({
              id: docSnap.id,
              name: data.name,
              title: data.title || data.name,
              dept: data.dept || data.name,
              description: data.description || '',
              iconName: data.iconName || 'Layers',
              colorTheme: data.colorTheme || 'teal',
              isCustom: true,
              createdAt: data.createdAt
            });
          }
        });

        const existingNames = new Set(DEFAULT_DEPARTMENTS.map((d) => d.name));
        const merged = [...DEFAULT_DEPARTMENTS];

        for (const c of customDepts) {
          if (!existingNames.has(c.name)) {
            merged.push(c);
            existingNames.add(c.name);
          }
        }

        saveLocalDepartments(merged);
        onUpdate(merged);
      },
      (err) => {
        console.warn('Departments snapshot error:', err);
      }
    );
    return unsubscribe;
  } catch (err) {
    console.warn('Failed to subscribe to departments:', err);
    return () => {};
  }
}

// Save a department to Cloud
export async function saveDepartmentToCloud(dept: Omit<DepartmentItem, 'id'> & { id?: string }): Promise<DepartmentItem> {
  const sanitizedId = (dept.id || dept.name)
    .replace(/[^a-zA-Z0-9_\-\u0600-\u06FF]/g, '_')
    .slice(0, 100);

  const finalItem: DepartmentItem = {
    id: sanitizedId,
    name: dept.name.trim(),
    title: dept.title?.trim() || dept.name.trim(),
    dept: dept.dept?.trim() || dept.name.trim(),
    description: dept.description?.trim() || `المناهج والكتب التخصصية لـ ${dept.name.trim()}`,
    iconName: dept.iconName || 'Layers',
    colorTheme: dept.colorTheme || 'teal',
    isCustom: true,
    createdAt: new Date().toISOString()
  };

  try {
    const docRef = doc(db, DEPARTMENTS_COLLECTION, sanitizedId);
    await setDoc(docRef, finalItem);
  } catch (err) {
    console.warn('Failed to save department to Firestore, caching locally:', err);
  }

  // Update local cache
  const local = getLocalDepartments();
  const updated = [...local.filter((d) => d.id !== sanitizedId && d.name !== finalItem.name), finalItem];
  saveLocalDepartments(updated);

  return finalItem;
}

// Delete a custom department from Cloud
export async function deleteDepartmentFromCloud(deptId: string): Promise<boolean> {
  try {
    const docRef = doc(db, DEPARTMENTS_COLLECTION, deptId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn('Failed to delete department from Firestore:', err);
  }

  const local = getLocalDepartments();
  const updated = local.filter((d) => d.id !== deptId);
  saveLocalDepartments(updated);
  return true;
}
