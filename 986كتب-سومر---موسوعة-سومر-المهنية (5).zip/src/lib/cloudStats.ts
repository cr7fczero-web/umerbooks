import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  increment, 
  onSnapshot,
  collection
} from 'firebase/firestore';
import { db } from './firebase';
import { apiUrl } from './storage';

export interface ReaderStats {
  totalOpens: number;
  activeStudents: number;
  activePercentage: number;
  lastUpdated: string;
}

const STATS_DOC_ID = 'overview';
const ACTIVE_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutes window for live presence

// Generate or retrieve persistent per-tab session ID
export function getSessionId(): string {
  if (typeof window === 'undefined') return 'server_session';
  let id = sessionStorage.getItem('sumer_student_session_id');
  if (!id) {
    id = `stud_${Math.random().toString(36).substring(2, 9)}_${Date.now().toString(36)}`;
    sessionStorage.setItem('sumer_student_session_id', id);
  }
  return id;
}

let hasOpenedBookInThisSession = false;
let lastOpenedBookTitle = '';
let lastOpenedBookDept = '';

// Send a live heartbeat for this real student session to Firestore and local backend
export async function sendStudentHeartbeat(): Promise<void> {
  const sessionId = getSessionId();
  const now = Date.now();

  // 1. Send to Firebase Firestore
  try {
    const sessionRef = doc(db, 'active_sessions', sessionId);
    await setDoc(sessionRef, {
      sessionId,
      lastActive: now,
      hasOpenedBook: hasOpenedBookInThisSession,
      bookTitle: lastOpenedBookTitle,
      dept: lastOpenedBookDept
    }, { merge: true });
  } catch (err) {
    console.warn('Firestore heartbeat notice:', err);
  }

  // 2. Send to local backend server
  try {
    await fetch(apiUrl('/api/sessions/heartbeat'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId,
        hasOpenedBook: hasOpenedBookInThisSession,
        bookTitle: lastOpenedBookTitle,
        dept: lastOpenedBookDept
      })
    });
  } catch {
    // ignore on static host
  }
}

// Remove session when student leaves / closes browser
export async function leaveStudentSession(): Promise<void> {
  const sessionId = getSessionId();
  try {
    const sessionRef = doc(db, 'active_sessions', sessionId);
    await deleteDoc(sessionRef);
  } catch {
    // ignore
  }

  try {
    fetch(apiUrl('/api/sessions/leave'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
      keepalive: true
    }).catch(() => {});
  } catch {
    // ignore
  }
}

// Record an actual, real book open interaction
export async function recordBookOpenToCloud(bookId: string, bookTitle?: string, dept?: string): Promise<void> {
  hasOpenedBookInThisSession = true;
  lastOpenedBookTitle = bookTitle || '';
  lastOpenedBookDept = dept || '';

  const now = new Date().toISOString();

  // 1. Send heartbeat immediately with hasOpenedBook = true
  await sendStudentHeartbeat();

  // 2. Increment real total opens in Firestore
  try {
    const statRef = doc(db, 'stats', STATS_DOC_ID);
    const snap = await getDoc(statRef);

    if (snap.exists()) {
      await updateDoc(statRef, {
        totalOpens: increment(1),
        lastUpdated: now,
        recentBookId: bookId,
        recentBookTitle: bookTitle || '',
        recentDept: dept || ''
      });
    } else {
      await setDoc(statRef, {
        totalOpens: 1,
        lastUpdated: now,
        recentBookId: bookId,
        recentBookTitle: bookTitle || '',
        recentDept: dept || ''
      });
    }
  } catch (err) {
    console.warn('Firestore stats increment skipped or offline:', err);
  }

  // 3. Increment on local backend server if active
  try {
    await fetch(apiUrl('/api/stats/record-open'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId: getSessionId(),
        bookId,
        bookTitle,
        dept
      })
    });
  } catch {
    // ignore
  }
}

// Subscribe to real-time genuine stats:
// Calculates exact real active students currently reading / browsing
export function subscribeToReaderStats(
  onUpdate: (stats: ReaderStats) => void
): () => void {
  let realTotalOpens = 0;
  let activeSessionsMap = new Map<string, { lastActive: number; hasOpenedBook: boolean }>();

  // Ensure current user is immediately registered in sessions map
  activeSessionsMap.set(getSessionId(), {
    lastActive: Date.now(),
    hasOpenedBook: hasOpenedBookInThisSession
  });

  const computeAndBroadcast = () => {
    const now = Date.now();
    let totalOnline = 0;
    let totalReading = 0;

    for (const [id, s] of activeSessionsMap.entries()) {
      if (now - s.lastActive > ACTIVE_TIMEOUT_MS) {
        activeSessionsMap.delete(id);
      } else {
        totalOnline++;
        if (s.hasOpenedBook) {
          totalReading++;
        }
      }
    }

    // Always include at least 1 since this student is currently active on the page
    const actualActiveCount = totalReading > 0 
      ? totalReading 
      : Math.max(totalOnline, 1);

    // Activity percentage based on real reading ratio
    const percentage = totalOnline > 0 
      ? Math.round((Math.max(totalReading, 1) / Math.max(totalOnline, 1)) * 100) 
      : 100;

    onUpdate({
      totalOpens: realTotalOpens,
      activeStudents: actualActiveCount,
      activePercentage: Math.min(100, Math.max(10, percentage)),
      lastUpdated: new Date().toISOString()
    });
  };

  // 1. Initial Heartbeat & Broadcast
  sendStudentHeartbeat().catch(() => {});
  computeAndBroadcast();

  // 2. Listen to Firestore real-time stats (totalOpens)
  let unsubscribeStats = () => {};
  try {
    const statRef = doc(db, 'stats', STATS_DOC_ID);
    unsubscribeStats = onSnapshot(statRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (typeof data.totalOpens === 'number') {
          realTotalOpens = data.totalOpens;
          computeAndBroadcast();
        }
      }
    }, (err) => {
      console.warn('Firestore stats subscription notice:', err);
    });
  } catch (err) {
    console.warn('Error setting up stats listener:', err);
  }

  // 3. Listen to Firestore active_sessions collection (Real active students presence!)
  let unsubscribeSessions = () => {};
  try {
    const sessionsCol = collection(db, 'active_sessions');
    unsubscribeSessions = onSnapshot(sessionsCol, (snapshot) => {
      const now = Date.now();
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const lastActive = typeof data.lastActive === 'number' ? data.lastActive : now;
        if (now - lastActive <= ACTIVE_TIMEOUT_MS) {
          activeSessionsMap.set(docSnap.id, {
            lastActive,
            hasOpenedBook: Boolean(data.hasOpenedBook)
          });
        } else {
          activeSessionsMap.delete(docSnap.id);
        }
      });

      // Always keep current tab's active session
      activeSessionsMap.set(getSessionId(), {
        lastActive: Date.now(),
        hasOpenedBook: hasOpenedBookInThisSession
      });

      computeAndBroadcast();
    }, (err) => {
      console.warn('Firestore active_sessions listener notice:', err);
    });
  } catch (err) {
    console.warn('Error setting up active_sessions listener:', err);
  }

  // 4. Fetch initial stats from local backend if available
  fetch(apiUrl('/api/stats'))
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      if (data) {
        if (typeof data.totalOpens === 'number' && data.totalOpens > realTotalOpens) {
          realTotalOpens = data.totalOpens;
        }
        computeAndBroadcast();
      }
    })
    .catch(() => {});

  // 5. Heartbeat loop (every 30 seconds to keep this student alive in Firestore & backend)
  const heartbeatInterval = setInterval(() => {
    sendStudentHeartbeat().catch(() => {});
  }, 30 * 1000);

  // 6. Minute timer as specifically requested by user ("وتتحدث النسبه كل دقيقه")
  const minuteInterval = setInterval(() => {
    computeAndBroadcast();
  }, 60 * 1000);

  // 7. Cleanup listeners on window leave/unload
  const handleUnload = () => {
    leaveStudentSession().catch(() => {});
  };
  window.addEventListener('beforeunload', handleUnload);
  window.addEventListener('pagehide', handleUnload);

  return () => {
    clearInterval(heartbeatInterval);
    clearInterval(minuteInterval);
    window.removeEventListener('beforeunload', handleUnload);
    window.removeEventListener('pagehide', handleUnload);
    unsubscribeStats();
    unsubscribeSessions();
  };
}
