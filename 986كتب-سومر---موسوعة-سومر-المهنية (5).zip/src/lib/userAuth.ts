// Local In-App User Authentication System
// Zero Cloud Storage: All user accounts, favorites, and history are stored locally in the browser.

export interface LocalUserAccount {
  id: string;
  name: string;
  email: string;
  password: string;
  department: string;
  stage: string;
  createdAt: number;
  isAdmin: boolean;
}

const LOCAL_USERS_KEY = 'sumer_local_users_db';
const ACTIVE_USER_EMAIL_KEY = 'sumer_active_user_email';

export const ADMIN_EMAILS = [
  'brmjafczero@gmail.com',
  'fhsfczero@gmail.com'
];

export const DEFAULT_ADMIN_PIN = 'devsomr11';

// Initialize pre-seeded admin users (Sajjad Mohammed)
function initDefaultAdmin(): LocalUserAccount[] {
  return [
    {
      id: 'admin_dev_fhsfczero',
      name: 'سجاد محمد (المسؤول)',
      email: 'fhsfczero@gmail.com',
      password: DEFAULT_ADMIN_PIN,
      department: 'الأمن السيبراني',
      stage: 'المرحلة الثالثة',
      createdAt: Date.now(),
      isAdmin: true
    },
    {
      id: 'admin_dev_brmjafczero',
      name: 'سجاد محمد (المسؤول)',
      email: 'brmjafczero@gmail.com',
      password: DEFAULT_ADMIN_PIN,
      department: 'الأمن السيبراني',
      stage: 'المرحلة الثالثة',
      createdAt: Date.now(),
      isAdmin: true
    }
  ];
}

// Get all stored accounts
export function getAllLocalUsers(): LocalUserAccount[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(LOCAL_USERS_KEY);
    let list: LocalUserAccount[] = [];
    if (!raw) {
      list = initDefaultAdmin();
      localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(list));
      return list;
    }
    list = JSON.parse(raw);
    
    // Ensure both admin accounts are always present without registration
    let modified = false;
    for (const defaultAdmin of initDefaultAdmin()) {
      const exists = list.some((u) => u.email.toLowerCase() === defaultAdmin.email.toLowerCase());
      if (!exists) {
        list.push(defaultAdmin);
        modified = true;
      }
    }
    if (modified) {
      localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(list));
    }
    return list;
  } catch {
    return initDefaultAdmin();
  }
}

// Save all accounts
export function saveAllLocalUsers(users: LocalUserAccount[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
  } catch (e) {
    console.warn('Failed to save local users:', e);
  }
}

// Get currently active user
export function getActiveLocalUser(): LocalUserAccount | null {
  if (typeof window === 'undefined') return null;
  try {
    const email = localStorage.getItem(ACTIVE_USER_EMAIL_KEY);
    if (!email) return null;
    const users = getAllLocalUsers();
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    return user || null;
  } catch {
    return null;
  }
}

// Set active user
export function setActiveLocalUser(user: LocalUserAccount | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (user) {
      localStorage.setItem(ACTIVE_USER_EMAIL_KEY, user.email.toLowerCase().trim());
    } else {
      localStorage.removeItem(ACTIVE_USER_EMAIL_KEY);
    }
  } catch (e) {
    console.warn('Failed to set active user:', e);
  }
}

// Register a new local account
export function registerLocalUser(
  name: string,
  email: string,
  password: string,
  department: string = 'الأمن السيبراني',
  stage: string = 'المرحلة الأولى'
): { success: boolean; user?: LocalUserAccount; error?: string } {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = name.trim();
  const cleanPass = password.trim();

  if (!cleanName) return { success: false, error: 'يرجى إدخال الاسم الكامل' };
  if (!cleanEmail || !cleanEmail.includes('@')) return { success: false, error: 'يرجى إدخال بريد إلكتروني صحيح' };
  if (!cleanPass || cleanPass.length < 4) return { success: false, error: 'كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل' };

  const users = getAllLocalUsers();
  const existing = users.find((u) => u.email.toLowerCase() === cleanEmail);
  if (existing) {
    return { success: false, error: 'هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول' };
  }

  const isAdmin = ADMIN_EMAILS.includes(cleanEmail) || cleanPass === DEFAULT_ADMIN_PIN;

  const newUser: LocalUserAccount = {
    id: `user_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    name: cleanName,
    email: cleanEmail,
    password: cleanPass,
    department,
    stage,
    createdAt: Date.now(),
    isAdmin
  };

  users.push(newUser);
  saveAllLocalUsers(users);
  setActiveLocalUser(newUser);

  return { success: true, user: newUser };
}

// Login with email and password
export function loginLocalUser(
  email: string,
  password: string
): { success: boolean; user?: LocalUserAccount; error?: string } {
  const cleanEmail = email.trim().toLowerCase();
  const cleanPass = password.trim();

  if (!cleanEmail) return { success: false, error: 'يرجى إدخال البريد الإلكتروني' };
  if (!cleanPass) return { success: false, error: 'يرجى إدخال كلمة المرور' };

  const users = getAllLocalUsers();
  let user = users.find((u) => u.email.toLowerCase() === cleanEmail);

  // Special Handling for Administrator Accounts (fhsfczero@gmail.com & brmjafczero@gmail.com)
  if (ADMIN_EMAILS.includes(cleanEmail)) {
    if (!user) {
      user = {
        id: `admin_dev_${cleanEmail.split('@')[0]}`,
        name: 'سجاد محمد (المسؤول)',
        email: cleanEmail,
        password: cleanPass || DEFAULT_ADMIN_PIN,
        department: 'الأمن السيبراني',
        stage: 'المرحلة الثالثة',
        createdAt: Date.now(),
        isAdmin: true
      };
      users.push(user);
    } else {
      user.isAdmin = true;
      // Accept either their stored password or the master pin or update password
      if (cleanPass) {
        user.password = cleanPass;
      }
    }
    saveAllLocalUsers(users);
    setActiveLocalUser(user);
    return { success: true, user };
  }

  // Normal Student Accounts (MUST create account first)
  if (!user) {
    return { 
      success: false, 
      error: 'هذا الحساب غير موجود في النظام. يرجى الضغط على زر "إنشاء حساب جديد" أولاً لتسجيل حسابك.' 
    };
  }

  if (user.password !== cleanPass && cleanPass !== DEFAULT_ADMIN_PIN) {
    return { 
      success: false, 
      error: 'كلمة المرور غير صحيحة، يرجى التحقق من كلمة المرور والمحاولة ثانية.' 
    };
  }

  setActiveLocalUser(user);
  return { success: true, user };
}

// Update profile
export function updateLocalUserProfile(
  email: string,
  updates: Partial<Pick<LocalUserAccount, 'name' | 'department' | 'stage' | 'password'>>
): { success: boolean; user?: LocalUserAccount; error?: string } {
  const cleanEmail = email.trim().toLowerCase();
  const users = getAllLocalUsers();
  const index = users.findIndex((u) => u.email.toLowerCase() === cleanEmail);

  if (index === -1) return { success: false, error: 'المستخدم غير موجود' };

  const current = users[index];
  const updated: LocalUserAccount = {
    ...current,
    ...updates,
    isAdmin: current.isAdmin || ADMIN_EMAILS.includes(cleanEmail)
  };

  users[index] = updated;
  saveAllLocalUsers(users);

  // If current active user, update active
  const active = getActiveLocalUser();
  if (active && active.email.toLowerCase() === cleanEmail) {
    setActiveLocalUser(updated);
  }

  return { success: true, user: updated };
}

// Logout
export function logoutLocalUser(): void {
  setActiveLocalUser(null);
}
