import React from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  ArrowRight, 
  BookOpen, 
  ChevronLeft, 
  Award, 
  Power,
  Disc,
  Fuel,
  Volume2,
  CheckCircle2
} from 'lucide-react';
import { StageId, Book } from '../types';

interface ElectricStageSelectorProps {
  books: Book[];
  onBackToDepts: () => void;
  onSelectStage: (stage: StageId) => void;
}

interface GeneratorStageDetail {
  id: StageId;
  gear: string;
  rpm: string;
  titleName: string;
  machineUnit: string;
  description: string;
  topics: string[];
  voltageOutput: string;
  currentAmps: string;
  badge?: string;
  accentColor: string;
  borderGlow: string;
  bgGlow: string;
}

const GENERATOR_STAGES: GeneratorStageDetail[] = [
  {
    id: 'المرحلة الأولى',
    gear: 'GEAR 1 // تشغيل البداية (Starter)',
    rpm: '750 RPM - IDLE SPEED',
    titleName: 'أساسيات المولدات والدارات الكهربائية',
    machineUnit: 'وحدة التأسيس والمولد الصغير أحادي الطور (1-Phase)',
    description: 'نظرية التحريض الكهرومغناطيسي لفاراداي، تكوين العضو الدوار والساكن (Stator & Rotor)، والتمديدات التأسيسية.',
    topics: ['مبدأ توليد القوة الدافعة الكهربائية (EMF)', 'الأقطاب المغناطيسية ولفائف النحاس', 'دوائر التيار المستمر والمتناوب AC/DC'],
    voltageOutput: '220 V / 50 Hz',
    currentAmps: '16 A',
    accentColor: 'text-amber-700 dark:text-amber-400',
    borderGlow: 'hover:border-amber-400 hover:shadow-amber-500/20',
    bgGlow: 'bg-amber-100 dark:bg-amber-950/40'
  },
  {
    id: 'المرحلة الثانية',
    gear: 'GEAR 2 // المحركات والمولد التزامني',
    rpm: '1500 RPM - SYNCHRONOUS SPEED',
    titleName: 'مولدات الديزل ثلاثية الأطوار والآلات الكهربائية',
    machineUnit: 'مولد الديزل الصناعي ثلاثي الأطوار (3-Phase Alternator)',
    description: 'منظومة الإثارة (Excitation System)، المولدات التزامنية، محركات الحث، ومنظم الجهد التلقائي (AVR).',
    topics: ['مبدأ عمل المولد التزامني ثلاثي الأطوار', 'منظم الفولتية الأوتوماتيكي AVR ولفائف الإثارة', 'لوحات التحويل الأوتوماتيكية ATS'],
    voltageOutput: '380 V - 400 V / 50 Hz',
    currentAmps: '63 A',
    accentColor: 'text-yellow-700 dark:text-yellow-400',
    borderGlow: 'hover:border-yellow-400 hover:shadow-yellow-500/20',
    bgGlow: 'bg-yellow-100 dark:bg-yellow-950/40'
  },
  {
    id: 'المرحلة الثالثة',
    gear: 'GEAR 3 // أقصى طاقة (FULL LOAD APEX)',
    rpm: '3000 RPM - RATED MAXIMUM',
    titleName: 'محطات التوليد الكبرى والمناهج الوزارية',
    machineUnit: 'محطة التوليد الضخمة، التزامن، والامتحان النهائي',
    description: 'تزامن المولدات على الشبكة الوطنية (Synchronization)، حماية المولدات من العكس والتأريض، والامتحانات الوزارية.',
    topics: ['ربط وتزامن المولدات مع الشبكة الوطنية', 'منظومات الوقاية، القواطع والمرحلات (Relays)', 'المناهج الوزارية المعتمدة للامتحان النهائي'],
    voltageOutput: '11,000 V (11kV) GENERATION',
    currentAmps: '250 A',
    badge: 'الامتحان الوزاري النهائي',
    accentColor: 'text-orange-700 dark:text-orange-400',
    borderGlow: 'hover:border-orange-400 hover:shadow-orange-500/20',
    bgGlow: 'bg-orange-100 dark:bg-orange-950/40'
  }
];

export const ElectricStageSelector: React.FC<ElectricStageSelectorProps> = ({
  books,
  onBackToDepts,
  onSelectStage
}) => {
  return (
    <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-zinc-950 border-2 border-amber-300 dark:border-amber-600/70 shadow-xl dark:shadow-2xl dark:shadow-black text-slate-900 dark:text-zinc-100 font-sans transition-all duration-500">
      {/* Industrial Machine Diamond Tread Texture */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-15 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:16px_16px]" 
      />

      {/* Industrial Hazard Warning Strip on top */}
      <div className="absolute top-0 inset-x-0 h-2 bg-[repeating-linear-gradient(45deg,#f59e0b,#f59e0b_12px,#fbbf24_12px,#fbbf24_24px)] dark:bg-[repeating-linear-gradient(45deg,#000,#000_12px,#f59e0b_12px,#f59e0b_24px)] opacity-70 dark:opacity-90" />

      {/* Vibration & Engine Heat Glow */}
      <div className="absolute -top-20 -left-20 w-52 h-52 bg-amber-500/10 dark:bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 w-52 h-52 bg-orange-600/10 dark:bg-orange-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar */}
      <div className="relative z-10 border-b border-slate-200 dark:border-zinc-800 bg-slate-50/95 dark:bg-zinc-900/95 backdrop-blur-md px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 pt-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDepts}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-zinc-300 hover:text-amber-700 dark:hover:text-amber-400 bg-white dark:bg-zinc-800 hover:bg-amber-50 dark:hover:bg-zinc-750 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-zinc-700 transition-all cursor-pointer group shadow-xs"
          >
            <ArrowRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform text-amber-500 dark:text-amber-400" />
            <span>خروج إلى كافة الأقسام</span>
          </button>
        </div>

        {/* Center Station Identification Tag */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          <span className="text-amber-700 dark:text-amber-400 font-black tracking-wider">مناهج قسم الكهرباء</span>
          <span className="text-slate-400 dark:text-zinc-600">|</span>
          <span className="text-slate-600 dark:text-zinc-400 hidden sm:inline">مدرسة سومر المهنية</span>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <span className="hidden sm:inline">مزامنة سحابية نشطة</span>
        </div>
      </div>

      {/* Main Body */}
      <div className="relative z-10 p-5 sm:p-8 space-y-6">
        {/* Section Header Card */}
        <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-amber-50 via-white to-amber-50/70 dark:from-zinc-900 dark:via-amber-950/40 dark:to-zinc-900 border border-amber-200 dark:border-amber-500/40 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm dark:shadow-xl">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-500/20 border border-amber-300 dark:border-amber-500/50 text-amber-800 dark:text-amber-300 font-mono text-[11px] font-bold flex items-center gap-1.5">
                <Power className="w-3 h-3 text-emerald-500 dark:text-emerald-400" />
                <span>ELECTRICAL ENGINEERING // هندسة الكهرباء والمكائن</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
              <span>قسم الكهرباء</span>
              <span className="text-amber-500 dark:text-yellow-400 text-2xl">⚙️</span>
            </h2>
            <p className="text-slate-600 dark:text-zinc-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              اختر المرحلة الدراسية المحددة لتشغيل توربينات المناهج واستخراج كتب المولدات، المحركات، ولوحات السيطرة المعتمدة من وزارة التربية.
            </p>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end justify-between border-t sm:border-t-0 sm:border-r border-slate-200 dark:border-zinc-800 pt-3 sm:pt-0 sm:pr-6 gap-2">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 dark:text-zinc-400 font-mono block">الكتب المتوفرة للقسم</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-amber-700 dark:text-amber-400">
                {books.filter((b) => b.dept === 'الكهرباء').length} كتب ومناهج
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>متاح للقراءة والتحميل</span>
            </div>
          </div>
        </div>

        {/* 3 Generator Stages (Gear 1, Gear 2, Gear 3) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-mono font-bold text-slate-700 dark:text-zinc-400 tracking-wider flex items-center gap-2">
              <Disc className="w-4 h-4 text-amber-600 dark:text-amber-400 animate-spin [animation-duration:5s]" />
              <span>SELECT GENERATOR GEAR // حدد سرعة ومستوى المرحلة:</span>
            </h3>
            <span className="text-[11px] font-mono text-amber-700 dark:text-amber-400/90">3 GEARS READY</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {GENERATOR_STAGES.map((st, sIdx) => {
              const stageBooks = books.filter(
                (b) => b.dept === 'الكهرباء' && b.stage === st.id
              );

              return (
                <motion.div
                  key={st.id}
                  id={`generator-stage-card-${st.id}`}
                  onClick={() => onSelectStage(st.id)}
                  whileHover={{
                    scale: 1.025,
                    y: -4,
                    boxShadow: '0 0 32px rgba(245, 158, 11, 0.25)'
                  }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                  className={`group relative rounded-2xl bg-white dark:bg-zinc-900/95 border-2 border-slate-200 dark:border-zinc-800 ${st.borderGlow} p-6 flex flex-col justify-between shadow-md dark:shadow-xl cursor-pointer overflow-hidden transition-colors duration-300`}
                >
                  {/* High-Voltage Electrical Energy Pulse Beam */}
                  <motion.div
                    className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-amber-500 dark:via-amber-400 to-transparent pointer-events-none"
                    animate={{
                      x: ['-100%', '100%'],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2.2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.35
                    }}
                  />

                  {/* Electrical Arc Voltage Flash Pulse */}
                  <motion.div
                    className="absolute -top-12 -right-12 w-36 h-36 bg-amber-500/10 dark:bg-amber-500/20 rounded-full blur-2xl pointer-events-none"
                    animate={{
                      scale: [1, 1.3, 1],
                      opacity: [0.3, 0.65, 0.3]
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.5
                    }}
                  />

                  <div>
                    {/* Top Row: Gear Label & Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-mono text-[10px] text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-zinc-700 px-2 py-0.5 rounded bg-amber-50/60 dark:bg-zinc-950 flex items-center gap-1.5 shadow-xs">
                        <motion.span
                          className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400"
                          animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
                          transition={{ duration: 1.5, repeat: Infinity, delay: sIdx * 0.25 }}
                        />
                        <Fuel className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                        <span>{st.gear}</span>
                      </span>
                      {st.badge && (
                        <span className="inline-flex items-center gap-1 bg-amber-100 dark:bg-amber-500/20 border border-amber-200 dark:border-amber-500/50 text-amber-800 dark:text-amber-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono">
                          <Award className="w-3 h-3" />
                          <span>{st.badge}</span>
                        </span>
                      )}
                    </div>

                    {/* Machine Rotor & Stage Title with Electrical Glow */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative">
                        <motion.div
                          className="absolute -inset-1 rounded-xl bg-amber-500/15 dark:bg-amber-500/25 blur-xs pointer-events-none"
                          animate={{
                            scale: [1, 1.15, 1],
                            opacity: [0.4, 0.85, 0.4]
                          }}
                          transition={{
                            duration: 2.2,
                            repeat: Infinity,
                            ease: 'easeInOut',
                            delay: sIdx * 0.3
                          }}
                        />
                        <div className={`relative w-12 h-12 rounded-xl bg-amber-50/80 dark:bg-zinc-950 border-2 border-amber-200 dark:border-zinc-700 flex items-center justify-center font-mono font-black text-lg ${st.accentColor} group-hover:border-amber-500 dark:group-hover:border-amber-400 group-hover:shadow-md transition-all`}>
                          <Disc className="w-6 h-6 animate-spin [animation-duration:8s] text-amber-600 dark:text-amber-400" />
                        </div>
                      </div>
                      <div>
                        <h4 className="text-base font-black text-slate-900 dark:text-white group-hover:text-amber-700 dark:group-hover:text-yellow-300 transition-colors">
                          {st.id}
                        </h4>
                        <span className="font-mono text-[10px] text-amber-700 dark:text-amber-400/90 block tracking-tight">
                          {st.rpm}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-50 dark:bg-zinc-950/70 border border-slate-200 dark:border-zinc-800 rounded-lg p-2 mb-3 text-[11px] font-mono text-slate-700 dark:text-zinc-300">
                      <span className="text-amber-700 dark:text-amber-400 font-bold block mb-0.5">{st.titleName}</span>
                      <span className="text-slate-500 dark:text-zinc-400 text-[10px]">{st.machineUnit}</span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed mb-4">
                      {st.description}
                    </p>

                    {/* Generator Specs Pill Box with Active Voltage Indicator */}
                    <div className="grid grid-cols-2 gap-2 mb-4 p-2 rounded-lg bg-slate-50 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 font-mono text-[10px]">
                      <div>
                        <span className="text-slate-500 dark:text-zinc-500 block">فولتية الخرج:</span>
                        <span className="text-amber-700 dark:text-yellow-400 font-bold flex items-center gap-1">
                          <Zap className="w-3 h-3 text-amber-500 dark:text-amber-400 fill-amber-500 dark:fill-amber-400" />
                          <span>{st.voltageOutput}</span>
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-zinc-500 block">سعة التيار:</span>
                        <span className="text-amber-700 dark:text-amber-400 font-bold">{st.currentAmps}</span>
                      </div>
                    </div>

                    {/* Key Topics List */}
                    <div className="space-y-1.5 mb-5 border-t border-slate-200 dark:border-zinc-800 pt-3">
                      <span className="text-[10px] font-mono text-slate-500 dark:text-zinc-400 uppercase tracking-wider block">
                        مفردات المنهج المقرر:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {st.topics.map((top, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[10px] bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 px-2 py-0.5 rounded-md border border-slate-200 dark:border-zinc-700 flex items-center gap-1 font-mono"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400" />
                            <span>{top}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="pt-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-mono text-slate-600 dark:text-zinc-300">
                      <BookOpen className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                      <span className="font-bold text-slate-900 dark:text-white">{stageBooks.length}</span>
                      <span className="text-slate-500 dark:text-zinc-400">كتب متوفرة</span>
                    </div>

                    <div className={`flex items-center gap-1.5 text-xs font-mono font-bold ${st.accentColor} group-hover:translate-x-[-4px] transition-transform`}>
                      <span>تشغيل وتصفح الكتب</span>
                      <ChevronLeft className="w-4 h-4" />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Footer Generator Warning & Safety Note */}
        <div className="bg-slate-50 dark:bg-zinc-900/80 border border-slate-200 dark:border-zinc-800 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-600 dark:text-zinc-400">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-500 dark:text-amber-400" />
            <span>نظام مكائن المولدات مفحوص ومطابق لمعايير السلامة المهنية ومربوط سحابياً.</span>
          </div>
          <span className="text-[11px] text-amber-700 dark:text-amber-400 font-bold">
            GENERATOR_ENGINEERING // SUMER
          </span>
        </div>
      </div>
    </div>
  );
};
