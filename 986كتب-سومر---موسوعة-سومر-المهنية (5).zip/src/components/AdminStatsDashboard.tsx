import React, { useState, useEffect, useMemo } from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import { 
  BarChart3, 
  PieChart as PieChartIcon, 
  TrendingUp, 
  BookOpen, 
  Flame, 
  Layers, 
  Eye, 
  Sparkles, 
  CheckCircle2, 
  Award,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Book } from '../types';
import { getDepartmentInteractions, getTotalInteractionsCount } from '../lib/analytics';

interface AdminStatsDashboardProps {
  books: Book[];
}

const DEPT_COLORS: Record<string, { bg: string; border: string; hex: string }> = {
  'الأمن السيبراني': { bg: 'bg-emerald-500', border: 'border-emerald-500', hex: '#10b981' },
  'الحاسبات': { bg: 'bg-indigo-500', border: 'border-indigo-500', hex: '#6366f1' },
  'إلكترونيك السيطرة والخزن': { bg: 'bg-teal-500', border: 'border-teal-500', hex: '#14b8a6' },
  'الكهرباء': { bg: 'bg-amber-500', border: 'border-amber-500', hex: '#f59e0b' }
};

const STAGE_COLORS = ['#14b8a6', '#6366f1', '#f59e0b', '#ec4899'];

// Custom Tooltip component for Recharts in RTL
const CustomBarTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900/95 text-white p-3 rounded-xl border border-slate-700 shadow-xl text-right text-xs space-y-1 font-sans">
        <p className="font-black text-teal-300 border-b border-slate-800 pb-1">{label}</p>
        <div className="space-y-1 pt-1">
          {payload.map((item: any, idx: number) => (
            <p key={idx} className="flex items-center justify-between gap-3 text-slate-200">
              <span className="font-bold text-white font-mono">{item.value.toLocaleString('ar-IQ')}</span>
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: item.color }} />
                <span>{item.name}:</span>
              </span>
            </p>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

const CustomPieTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0];
    return (
      <div className="bg-slate-900/95 text-white p-2.5 rounded-xl border border-slate-700 shadow-xl text-right text-xs font-sans">
        <p className="font-black text-white">{data.name}</p>
        <p className="text-teal-300 font-mono font-bold mt-1">
          {data.value} كتاب ({data.payload?.percent || '0'}%)
        </p>
      </div>
    );
  }
  return null;
};

export const AdminStatsDashboard: React.FC<AdminStatsDashboardProps> = ({ books }) => {
  const [interactions, setInteractions] = useState<Record<string, number>>({});
  const [totalInteractions, setTotalInteractions] = useState<number>(0);
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [chartView, setChartView] = useState<'both' | 'departments' | 'stages'>('both');

  // Load and subscribe to interactions
  useEffect(() => {
    const updateStats = () => {
      setInteractions(getDepartmentInteractions());
      setTotalInteractions(getTotalInteractionsCount());
    };

    updateStats();
    window.addEventListener('sumer_interaction_updated', updateStats);
    return () => window.removeEventListener('sumer_interaction_updated', updateStats);
  }, []);

  // 1. Department statistics & activity
  const departmentStats = useMemo(() => {
    const counts: Record<string, number> = {
      'الأمن السيبراني': 0,
      'الحاسبات': 0,
      'إلكترونيك السيطرة والخزن': 0,
      'الكهرباء': 0
    };

    books.forEach((b) => {
      if (b.dept && counts[b.dept] !== undefined) {
        counts[b.dept] = (counts[b.dept] || 0) + 1;
      }
    });

    const list = Object.entries(counts).map(([name, count]) => {
      const reads = interactions[name] || 0;
      // Activity score: weighted books + read interactions
      const activityScore = count * 15 + reads;
      const percentage = books.length > 0 ? Math.round((count / books.length) * 100) : 0;
      return {
        name,
        shortName: name.replace('قسم ', '').replace('إلكترونيك السيطرة والخزن', 'إلكترونيك'),
        booksCount: count,
        reads,
        activityScore,
        percentage,
        color: DEPT_COLORS[name]?.hex || '#14b8a6'
      };
    });

    // Sort by activity score
    list.sort((a, b) => b.activityScore - a.activityScore);
    return list;
  }, [books, interactions]);

  // Top active department
  const topDepartment = departmentStats[0] || { name: 'الأمن السيبراني', booksCount: 0, reads: 0 };

  // 2. Stages distribution
  const stageStats = useMemo(() => {
    const stages: Record<string, number> = {
      'المرحلة الأولى': 0,
      'المرحلة الثانية': 0,
      'المرحلة الثالثة': 0
    };

    books.forEach((b) => {
      if (b.stage && stages[b.stage] !== undefined) {
        stages[b.stage] = (stages[b.stage] || 0) + 1;
      }
    });

    return Object.entries(stages).map(([name, value], idx) => ({
      name,
      value,
      percent: books.length > 0 ? Math.round((value / books.length) * 100) : 0,
      color: STAGE_COLORS[idx % STAGE_COLORS.length]
    }));
  }, [books]);

  // 3. Cloud vs Drive distribution
  const cloudSourcesCount = useMemo(() => {
    return books.filter((b) => b.url && (b.url.includes('drive.google.com') || b.url.startsWith('http'))).length;
  }, [books]);

  return (
    <div className="mb-6 rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 text-white p-5 sm:p-6 shadow-xl relative overflow-hidden">
      {/* Decorative ambient background glows */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header with toggle and badges */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-400 shadow-inner">
            <BarChart3 className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                لوحة بيانات وإحصائيات المنصة
              </h3>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-teal-950/80 text-teal-300 border border-teal-800">
                <Sparkles className="w-2.5 h-2.5 text-teal-400" />
                <span>Recharts Live</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium">
              مؤشرات رقمية مباشرة لإجمالي الكتب المرفوعة، وتفاعل الأقسام، وتوزيع المراحل الدراسية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {/* Chart View selector buttons */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs font-mono">
            <button
              type="button"
              onClick={() => setChartView('both')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                chartView === 'both' ? 'bg-teal-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل
            </button>
            <button
              type="button"
              onClick={() => setChartView('departments')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                chartView === 'departments' ? 'bg-teal-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              الأقسام
            </button>
            <button
              type="button"
              onClick={() => setChartView('stages')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                chartView === 'stages' ? 'bg-teal-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              المراحل
            </button>
          </div>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-mono transition-colors cursor-pointer border border-slate-700"
            title={isExpanded ? 'طي لوحة البيانات' : 'توسيع لوحة البيانات'}
          >
            <span>{isExpanded ? 'طي' : 'عرض'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="relative z-10 pt-4 space-y-5 animate-in fade-in duration-200">
          {/* 4 Summary KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {/* KPI 1: Total Books */}
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/90 shadow-inner flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>إجمالي الكتب المرفوعة</span>
                <BookOpen className="w-4 h-4 text-teal-400" />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-black font-mono text-white">
                  {books.length}
                </span>
                <span className="text-[11px] text-teal-400 font-bold">كتاب متاح</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                <span>جاهزة للقراءة والتنزيل</span>
              </div>
            </div>

            {/* KPI 2: Top Active Department */}
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/90 shadow-inner flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>أكثر الأقسام تفاعلاً</span>
                <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
              </div>
              <div className="space-y-0.5">
                <span className="text-sm sm:text-base font-black text-amber-300 truncate block">
                  {topDepartment.shortName}
                </span>
                <span className="text-xs font-mono text-slate-300">
                  {topDepartment.booksCount} كتب • {topDepartment.reads} تفاعل
                </span>
              </div>
              <div className="text-[10px] text-amber-400/90 mt-1 flex items-center gap-1 font-mono">
                <Award className="w-3 h-3 text-amber-400" />
                <span>الأعلى زيارة من الطلاب</span>
              </div>
            </div>

            {/* KPI 3: Total Reads & Interactions */}
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/90 shadow-inner flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>إجمالي التفاعلات والقراءات</span>
                <Eye className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-black font-mono text-indigo-300">
                  {totalInteractions.toLocaleString('ar-IQ')}
                </span>
                <span className="text-[11px] text-indigo-400 font-bold">تصفح وقراءة</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 font-mono">
                <TrendingUp className="w-3 h-3 text-indigo-400" />
                <span>إقبال متزايد ومستمر</span>
              </div>
            </div>

            {/* KPI 4: Cloud / Drive Coverage */}
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/90 shadow-inner flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>الربط السحابي (Google Drive)</span>
                <Layers className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-black font-mono text-emerald-300">
                  {cloudSourcesCount}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">/ {books.length}</span>
              </div>
              <div className="text-[10px] text-emerald-400/90 mt-1 flex items-center gap-1 font-mono">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>مزامنة مباشرة مع تليكرام</span>
              </div>
            </div>
          </div>

          {/* Recharts Visualizations Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* BarChart: Department Distribution & Interactions */}
            {(chartView === 'both' || chartView === 'departments') && (
              <div className={`p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between ${
                chartView === 'departments' ? 'lg:col-span-12' : chartView === 'both' ? 'lg:col-span-7' : ''
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                    <BarChart3 className="w-4 h-4 text-teal-400" />
                    <span>توزيع الكتب والتفاعل حسب القسم</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    مقارنة: الكتب مقابل مرات التصفح
                  </span>
                </div>

                <div className="w-full h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={departmentStats}
                      margin={{ top: 10, right: 10, left: -10, bottom: 20 }}
                    >
                      <XAxis 
                        dataKey="shortName" 
                        stroke="#94a3b8" 
                        fontSize={11} 
                        tickLine={false}
                        axisLine={{ stroke: '#334155' }}
                        interval={0}
                      />
                      <YAxis 
                        stroke="#94a3b8" 
                        fontSize={10} 
                        tickLine={false}
                        axisLine={{ stroke: '#334155' }}
                      />
                      <Tooltip content={<CustomBarTooltip />} />
                      <Legend 
                        verticalAlign="top" 
                        height={32}
                        formatter={(val) => <span className="text-[11px] text-slate-300">{val}</span>} 
                      />
                      <Bar 
                        dataKey="booksCount" 
                        name="عدد الكتب" 
                        fill="#14b8a6" 
                        radius={[4, 4, 0, 0]} 
                      />
                      <Bar 
                        dataKey="reads" 
                        name="مرات التصفح" 
                        fill="#6366f1" 
                        radius={[4, 4, 0, 0]} 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* PieChart: Stages Distribution */}
            {(chartView === 'both' || chartView === 'stages') && (
              <div className={`p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between ${
                chartView === 'stages' ? 'lg:col-span-12' : chartView === 'both' ? 'lg:col-span-5' : ''
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                    <PieChartIcon className="w-4 h-4 text-indigo-400" />
                    <span>توزيع الكتب حسب المراحل الدراسية</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    المراحل 1 - 2 - 3
                  </span>
                </div>

                <div className="w-full h-56 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stageStats}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={48}
                        outerRadius={72}
                        paddingAngle={4}
                      >
                        {stageStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomPieTooltip />} />
                      <Legend 
                        layout="horizontal"
                        verticalAlign="bottom"
                        align="center"
                        formatter={(value) => <span className="text-[11px] text-slate-300">{value}</span>}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>

          {/* Department Rankings and Progress Breakdown */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" />
                <span>ترتيب الأقسام ونسبة اكتمال المناهج:</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                إجمالي 4 أقسام تخصصية
              </span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {departmentStats.map((dept, index) => (
                <div
                  key={dept.name}
                  className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black font-mono ${
                        index === 0 
                          ? 'bg-amber-400 text-slate-950' 
                          : index === 1 
                          ? 'bg-slate-300 text-slate-950' 
                          : 'bg-slate-700 text-slate-300'
                      }`}>
                        {index + 1}
                      </span>
                      <span className="text-xs font-bold text-white truncate max-w-[130px]">
                        {dept.shortName}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-teal-300">
                      {dept.percentage}%
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${Math.max(dept.percentage, 5)}%`,
                        backgroundColor: dept.color 
                      }} 
                    />
                  </div>

                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-0.5">
                    <span>{dept.booksCount} كتب</span>
                    <span>{dept.reads} تصفح</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
