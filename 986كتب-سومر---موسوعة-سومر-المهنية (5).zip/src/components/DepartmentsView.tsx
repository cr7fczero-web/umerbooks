import React from 'react';
import { Cpu, Zap, ShieldCheck, Laptop, BookOpen, ArrowLeft, Sparkles, Layers, Cloud } from 'lucide-react';
import { DepartmentId, Book } from '../types';
import { RecentlyAddedSection } from './RecentlyAddedSection';

interface DepartmentsViewProps {
  onSelectDept: (dept: DepartmentId) => void;
  books: Book[];
  onReadBook: (book: Book) => void;
  favoriteIds: string[];
  onToggleFavorite: (bookId: string) => void;
}

interface DepartmentMeta {
  id: DepartmentId;
  name: string;
  subTitle: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  gradient: string;
  darkGradient: string;
  borderColor: string;
  badgeBg: string;
  iconBg: string;
}

const DEPARTMENTS: DepartmentMeta[] = [
  {
    id: 'الأمن السيبراني',
    name: 'الأمن السيبراني',
    subTitle: 'حماية الأنظمة والتشفير',
    description: 'مناهج أمن المعلومات، الدفاع الرقمي واختبار الاختراق',
    icon: ShieldCheck,
    color: 'text-emerald-700 dark:text-emerald-300',
    gradient: 'from-emerald-500/15 via-teal-500/5 to-transparent',
    darkGradient: 'dark:from-emerald-950/60 dark:via-slate-900 dark:to-slate-900',
    borderColor: 'border-emerald-200/90 dark:border-emerald-800/80 hover:border-emerald-400',
    badgeBg: 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300',
    iconBg: 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400'
  },
  {
    id: 'الكهرباء',
    name: 'قسم الكهرباء',
    subTitle: 'القوى والآلات والشبكات',
    description: 'المحركات، المحولات والتحكم الآلي الصناعي',
    icon: Zap,
    color: 'text-amber-700 dark:text-amber-300',
    gradient: 'from-amber-500/15 via-yellow-500/5 to-transparent',
    darkGradient: 'dark:from-amber-950/60 dark:via-slate-900 dark:to-slate-900',
    borderColor: 'border-amber-200/90 dark:border-amber-800/80 hover:border-amber-400',
    badgeBg: 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300',
    iconBg: 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-400'
  },
  {
    id: 'الحاسبات',
    name: 'قسم الحاسبات',
    subTitle: 'البرمجة وصيانة الحواسيب',
    description: 'نظم التشغيل، هندسة الشبكات والبرمجيات',
    icon: Laptop,
    color: 'text-indigo-700 dark:text-indigo-300',
    gradient: 'from-indigo-500/15 via-purple-500/5 to-transparent',
    darkGradient: 'dark:from-indigo-950/60 dark:via-slate-900 dark:to-slate-900',
    borderColor: 'border-indigo-200/90 dark:border-indigo-800/80 hover:border-indigo-400',
    badgeBg: 'bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300',
    iconBg: 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-400'
  },
  {
    id: 'إلكترونيك السيطرة والخزن',
    name: 'إلكترونيك السيطرة',
    subTitle: 'الأنظمة والدوائر الإلكترونية',
    description: 'العلوم الصناعية وسيطرة القوى الحديثة',
    icon: Cpu,
    color: 'text-sky-700 dark:text-sky-300',
    gradient: 'from-sky-500/15 via-blue-500/5 to-transparent',
    darkGradient: 'dark:from-sky-950/60 dark:via-slate-900 dark:to-slate-900',
    borderColor: 'border-sky-200/90 dark:border-sky-800/80 hover:border-sky-400',
    badgeBg: 'bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300',
    iconBg: 'bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-400'
  }
];

export const DepartmentsView: React.FC<DepartmentsViewProps> = ({
  onSelectDept,
  books,
  onReadBook,
  favoriteIds,
  onToggleFavorite
}) => {
  const totalBooksCount = books.length;

  return (
    <section className="space-y-4 sm:space-y-5">
      {/* Compact Mobile-First Hero Greeting Card (Takes minimal screen height) */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#fff9ea] via-[#fef3d6] to-[#fae8b8] dark:from-teal-700 dark:via-teal-800 dark:to-emerald-800 text-slate-950 dark:text-white p-3.5 sm:p-5 border-2 border-black dark:border-transparent shadow-[0_6px_25px_rgba(0,0,0,0.06),0_2px_8px_rgba(217,119,6,0.15)] dark:shadow-md dark:shadow-teal-900/15">
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-950 dark:text-teal-100/90">
              <span className="w-2 h-2 rounded-full bg-emerald-500 dark:bg-emerald-300 animate-ping inline-block" />
              <span>إعدادية سومر المهنية للبنين</span>
              <span className="text-amber-700/60 dark:text-teal-200/60">•</span>
              <span className="text-[10px] bg-amber-200/90 dark:bg-teal-900/60 text-amber-950 dark:text-teal-100 px-2 py-0.5 rounded-full border border-black/20 dark:border-teal-500/40 font-black">
                المناهج الوزارية
              </span>
            </div>
            <h2 className="text-base sm:text-xl font-black tracking-tight leading-snug">
              موسوعة الكتب والمناهج المهنية المتكاملة
            </h2>
            <p className="text-[11px] sm:text-xs text-slate-700 dark:text-teal-100/80 leading-tight hidden xs:block font-bold">
              تصفح فوري ومباشر لجميع المناهج الدراسية لكافة الأقسام والمراحل
            </p>
          </div>

          {/* Quick Metrics Capsule */}
          <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
            <div className="bg-amber-100/90 dark:bg-white/15 backdrop-blur-md border-2 border-black/30 dark:border-white/20 px-2.5 py-1 rounded-xl text-center">
              <span className="block text-[9px] text-amber-950 dark:text-teal-200 font-extrabold">الكتب</span>
              <span className="text-xs sm:text-sm font-black text-black dark:text-white">{totalBooksCount}</span>
            </div>
            <div className="bg-amber-100/90 dark:bg-white/15 backdrop-blur-md border-2 border-black/30 dark:border-white/20 px-2.5 py-1 rounded-xl text-center">
              <span className="block text-[9px] text-amber-950 dark:text-teal-200 font-extrabold">الأقسام</span>
              <span className="text-xs sm:text-sm font-black text-black dark:text-white">4</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of 4 Departments Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-1.5">
          <Layers className="w-4 h-4 text-teal-700 dark:text-teal-400" />
          <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-slate-100 tracking-tight">
            الأقسام المهنية التخصصية
          </h3>
        </div>
        <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-lg">
          اختر القسم للدخول
        </span>
      </div>

      {/* 2x2 Grid on Mobile / 4 Columns on Desktop */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
        {DEPARTMENTS.map((dept) => {
          const count = books.filter((b) => b.dept === dept.id).length;
          const IconComponent = dept.icon;

          return (
            <div
              id={`dept-card-${dept.id}`}
              key={dept.id}
              onClick={() => onSelectDept(dept.id)}
              className={`group relative bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-3 sm:p-4 flex flex-col justify-between shadow-[0_4px_16px_rgba(0,0,0,0.06),0_1px_4px_rgba(217,119,6,0.12)] hover:shadow-[0_8px_24px_rgba(217,119,6,0.22)] hover:border-black transition-all duration-200 cursor-pointer overflow-hidden hover:-translate-y-0.5 active:scale-[0.98] select-none`}
            >
              {/* Subtle gradient wash in background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${dept.gradient} ${dept.darkGradient} pointer-events-none opacity-80`} />

              <div className="relative z-10">
                {/* Top Row: Icon + Count */}
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-9 h-9 sm:w-11 sm:h-11 rounded-xl ${dept.iconBg} flex items-center justify-center transition-transform group-hover:scale-105 shadow-2xs`}>
                    <IconComponent className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                  <span className={`text-[10px] sm:text-xs font-black px-2 py-0.5 rounded-lg ${dept.badgeBg} flex items-center gap-1 shadow-2xs`}>
                    <BookOpen className="w-3 h-3" />
                    <span>{count}</span>
                  </span>
                </div>

                {/* Name */}
                <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-300 transition-colors leading-tight mb-0.5">
                  {dept.name}
                </h4>
                <p className="text-[10px] sm:text-xs font-medium text-slate-500 dark:text-slate-400 line-clamp-1 mb-1">
                  {dept.subTitle}
                </p>
              </div>

              {/* Enter cue */}
              <div className="relative z-10 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] font-bold text-teal-700 dark:text-teal-400 group-hover:translate-x-[-2px] transition-transform">
                <span className="text-[10px] font-bold">تصفح المراحل</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* "وجوه تظهر آخر الكتب أضافه للتطبيق" (Recently Added Books Section Directly Under Departments) */}
      <div className="pt-1">
        <RecentlyAddedSection
          books={books}
          onReadBook={onReadBook}
          favoriteIds={favoriteIds}
          onToggleFavorite={onToggleFavorite}
          title="آخر الكتب المضافة للتطبيق"
          subTitle="أحدث المناهج والكتب التي تمت إضافتها مؤخراً لجميع الأقسام"
          limit={8}
        />
      </div>
    </section>
  );
};
