import React from 'react';
import { motion } from 'framer-motion';
import { 
  Cpu, 
  ArrowRight, 
  BookOpen, 
  ChevronLeft, 
  Award, 
  HardDrive, 
  Layers, 
  CheckCircle2,
  CircuitBoard,
  Sparkles,
  Zap
} from 'lucide-react';
import { StageId, Book } from '../types';

interface ComputerStageSelectorProps {
  books: Book[];
  onBackToDepts: () => void;
  onSelectStage: (stage: StageId) => void;
}

interface ComputerComponentStage {
  id: StageId;
  hardwareTier: string;
  componentName: string;
  architecture: string;
  clockSpeed: string;
  description: string;
  topics: string[];
  specs: { label: string; value: string }[];
  badge?: string;
  accentColor: string;
  borderGlow: string;
  bgGlow: string;
}

const COMPUTER_STAGES: ComputerComponentStage[] = [
  {
    id: 'المرحلة الأولى',
    hardwareTier: 'HARDWARE TIER 1 // العتاد الأساسي واللوحة الأم',
    componentName: 'اللوحة الأم والعتاد الصلب (Motherboard & Hardware Core)',
    architecture: 'CHIPSET B760 // I/O CONTROLLER',
    clockSpeed: 'BUS: 4800 MT/s',
    description: 'تفكيك وتشريح مكونات الحاسوب المادية: المعالج، ذاكرة RAM، وسائط التخزين SSD/NVMe، ومنافذ الإدخال والإخراج.',
    topics: ['مكونات صندوق الحاسوب واللوحة الأم', 'أنواع الذاكرة العشوائية RAM وتوقيتاتها', 'وسائط التخزين وقنوات نقل البيانات SATA/PCIe'],
    specs: [
      { label: 'SOCKET', value: 'LGA-1700' },
      { label: 'MEMORY', value: 'DDR4/DDR5' },
      { label: 'BUS WIDTH', value: '64-Bit' }
    ],
    accentColor: 'text-indigo-700 dark:text-indigo-400',
    borderGlow: 'hover:border-indigo-400 hover:shadow-indigo-500/20',
    bgGlow: 'bg-indigo-100 dark:bg-indigo-950/40'
  },
  {
    id: 'المرحلة الثانية',
    hardwareTier: 'HARDWARE TIER 2 // نواة المعالجة والبرمجيات',
    componentName: 'وحدة المعالجة المركزية وأنظمة التشغيل (CPU & OS Kernel)',
    architecture: 'OCTA-CORE x86-64 // ARCHITECTURE',
    clockSpeed: 'BOOST: 4.6 GHz',
    description: 'معمارية وحدة المعالجة المركزية (ALU, CU, Registers)، أنظمة التشغيل وإدارة الذاكرة، ولغات البرمجة التخصصية.',
    topics: ['معمارية المعالج وسجلات المعطيات Registers', 'إدارة العمليات والجدولة في أنظمة التشغيل', 'أساسيات البرمجة وقواعد البيانات'],
    specs: [
      { label: 'CORES', value: '8P + 8E' },
      { label: 'L3 CACHE', value: '30 MB' },
      { label: 'OS SUPPORT', value: 'Linux / Win' }
    ],
    accentColor: 'text-cyan-700 dark:text-cyan-400',
    borderGlow: 'hover:border-cyan-400 hover:shadow-cyan-500/20',
    bgGlow: 'bg-cyan-100 dark:bg-cyan-950/40'
  },
  {
    id: 'المرحلة الثالثة',
    hardwareTier: 'HARDWARE TIER 3 // الحوسبة الفائقة والامتحان الوزاري',
    componentName: 'كارت الشاشة والشبكات المتقدمة (GPU & Network Apex)',
    architecture: 'PARALLEL CUDA/TENSOR // HIGH-END',
    clockSpeed: 'CLOCK: 2500 MHz',
    description: 'المناهج الوزارية المنتهية، هندسة الشبكات المتقدمة (LAN/WAN/VLAN)، والصيانة الشاملة للحواسيب.',
    topics: ['صيانة الأعطال المتقدمة للعتاد والبرمجيات', 'هندسة الشبكات والبروتوكولات TCP/IP', 'المناهج الوزارية المعتمدة للامتحان النهائي'],
    specs: [
      { label: 'PCIe BUS', value: 'Gen 5.0 x16' },
      { label: 'VRAM', value: '16 GB GDDR6X' },
      { label: 'EXAM TIER', value: 'الوزاري المعتمد' }
    ],
    badge: 'الامتحان الوزاري النهائي',
    accentColor: 'text-purple-700 dark:text-purple-400',
    borderGlow: 'hover:border-purple-400 hover:shadow-purple-500/20',
    bgGlow: 'bg-purple-100 dark:bg-purple-950/40'
  }
];

export const ComputerStageSelector: React.FC<ComputerStageSelectorProps> = ({
  books,
  onBackToDepts,
  onSelectStage
}) => {
  return (
    <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-slate-950 border-2 border-indigo-200 dark:border-indigo-500/60 shadow-xl dark:shadow-2xl dark:shadow-indigo-950/50 text-slate-900 dark:text-slate-100 font-sans transition-all duration-500">
      {/* Printed Circuit Board Motherboard Texture Background */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-20 bg-[linear-gradient(to_right,#6366f1_1px,transparent_1px),linear-gradient(to_bottom,#6366f1_1px,transparent_1px)] bg-[size:24px_24px]" 
      />
      <div 
        className="absolute inset-0 pointer-events-none bg-radial from-transparent via-slate-100/50 dark:via-slate-950/70 to-slate-100 dark:to-slate-950 opacity-90" 
      />

      {/* Top Header Bar */}
      <div className="relative z-10 border-b border-slate-200 dark:border-indigo-900/60 bg-slate-50/95 dark:bg-slate-900/90 backdrop-blur-md px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDepts}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-300 bg-white dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-slate-750 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 transition-all cursor-pointer group shadow-xs"
          >
            <ArrowRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform text-indigo-500 dark:text-indigo-400" />
            <span>خروج إلى كافة الأقسام</span>
          </button>
        </div>

        {/* Center Identity */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <CircuitBoard className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <span className="text-indigo-700 dark:text-indigo-300 font-black tracking-wider">مناهج قسم الحاسبات</span>
          <span className="text-slate-400 dark:text-slate-600">|</span>
          <span className="text-slate-600 dark:text-slate-400 hidden sm:inline">مدرسة سومر المهنية</span>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <span className="hidden sm:inline">مزامنة سحابية نشطة</span>
        </div>
      </div>

      {/* Main Body */}
      <div className="relative z-10 p-5 sm:p-8 space-y-6">
        {/* Section Header Card */}
        <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-indigo-50 via-white to-indigo-50/70 dark:from-slate-900 dark:via-indigo-950/40 dark:to-slate-900 border border-indigo-200 dark:border-indigo-500/40 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm dark:shadow-xl">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-500/20 border border-indigo-200 dark:border-indigo-500/50 text-indigo-700 dark:text-indigo-300 font-mono text-[11px] font-bold flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>PC ARCHITECTURE // معمارية الحاسوب والبرمجيات</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
              <span>قسم الحاسبات</span>
              <span className="text-indigo-500 dark:text-indigo-400 text-2xl">💻</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              اختر المرحلة الدراسية لاستعراض المناهج التخصصية للعتاد الصلب، الصيانة، الشبكات، والبرمجيات المعتمدة من وزارة التربية.
            </p>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end justify-between border-t sm:border-t-0 sm:border-r border-slate-200 dark:border-slate-800 pt-3 sm:pt-0 sm:pr-6 gap-2">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">الكتب المتوفرة للقسم</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                {books.filter((b) => b.dept === 'الحاسبات').length} كتب ومناهج
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>متاح للقراءة والتحميل</span>
            </div>
          </div>
        </div>

        {/* 3 Computer Stages */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-mono font-bold text-slate-700 dark:text-slate-400 tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>SELECT HARDWARE TIER // حدد مستوى العتاد والمرحلة الدراسية:</span>
            </h3>
            <span className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400/90">3 TIERS LOADED</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {COMPUTER_STAGES.map((st, sIdx) => {
              const stageBooks = books.filter(
                (b) => b.dept === 'الحاسبات' && b.stage === st.id
              );

              return (
                <motion.div
                  key={st.id}
                  id={`computer-stage-card-${st.id}`}
                  onClick={() => onSelectStage(st.id)}
                  whileHover={{
                    scale: 1.025,
                    y: -4,
                    boxShadow: '0 0 32px rgba(99, 102, 241, 0.25)'
                  }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                  className={`group relative rounded-2xl bg-white dark:bg-slate-900/95 border-2 border-slate-200 dark:border-slate-800 ${st.borderGlow} p-6 flex flex-col justify-between shadow-md dark:shadow-xl cursor-pointer overflow-hidden transition-colors duration-300`}
                >
                  {/* High-speed Bus Clock Signal Pulse Beam */}
                  <motion.div
                    className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-indigo-500 dark:via-indigo-400 to-transparent pointer-events-none"
                    animate={{
                      x: ['-100%', '100%'],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2.3,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.4
                    }}
                  />

                  {/* Micro-architecture Silicon Heat Core Ambient Pulse */}
                  <motion.div
                    className="absolute -top-12 -right-12 w-36 h-36 bg-indigo-500/10 dark:bg-indigo-500/20 rounded-full blur-2xl pointer-events-none"
                    animate={{
                      scale: [1, 1.25, 1],
                      opacity: [0.3, 0.65, 0.3]
                    }}
                    transition={{
                      duration: 3.2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.45
                    }}
                  />

                  <div>
                    {/* Top Row: Tier Label & Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-mono text-[10px] text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-slate-700 px-2 py-0.5 rounded bg-indigo-50/60 dark:bg-slate-950 flex items-center gap-1.5 shadow-xs">
                        <motion.span
                          className="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400"
                          animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
                          transition={{ duration: 1.4, repeat: Infinity, delay: sIdx * 0.2 }}
                        />
                        <CircuitBoard className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                        <span>{st.hardwareTier}</span>
                      </span>
                      {st.badge && (
                        <span className="inline-flex items-center gap-1 bg-purple-100 dark:bg-purple-500/20 border border-purple-200 dark:border-purple-500/50 text-purple-700 dark:text-purple-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono">
                          <Award className="w-3 h-3" />
                          <span>{st.badge}</span>
                        </span>
                      )}
                    </div>

                    {/* Component Icon & Stage Title with Clock Pulse */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative">
                        <motion.div
                          className="absolute -inset-1 rounded-xl bg-indigo-500/15 dark:bg-indigo-500/25 blur-xs pointer-events-none"
                          animate={{
                            scale: [1, 1.15, 1],
                            opacity: [0.4, 0.85, 0.4]
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: 'easeInOut',
                            delay: sIdx * 0.3
                          }}
                        />
                        <div className={`relative w-12 h-12 rounded-xl bg-indigo-50/80 dark:bg-slate-950 border-2 border-indigo-200 dark:border-slate-700 flex items-center justify-center font-mono font-black text-lg ${st.accentColor} group-hover:border-indigo-400 group-hover:shadow-md transition-all`}>
                          <Cpu className="w-6 h-6 animate-pulse text-indigo-600 dark:text-indigo-400" />
                        </div>
                      </div>
                      <div>
                        <h4 className="text-base font-black text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-200 transition-colors">
                          {st.id}
                        </h4>
                        <span className="font-mono text-[10px] text-indigo-600 dark:text-indigo-400 block tracking-tight">
                          {st.architecture}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 mb-3 text-[11px] font-mono text-slate-700 dark:text-slate-300">
                      <span className="text-indigo-700 dark:text-indigo-300 font-bold block mb-0.5">{st.componentName}</span>
                      <span className="text-slate-500 dark:text-slate-400 text-[10px]">{st.clockSpeed}</span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                      {st.description}
                    </p>

                    {/* Hardware Specs Grid */}
                    <div className="grid grid-cols-3 gap-2 mb-4 p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-[10px]">
                      {st.specs.map((spec, spIdx) => (
                        <div key={spIdx} className="text-center">
                          <span className="text-slate-500 dark:text-slate-500 block text-[9px]">{spec.label}</span>
                          <span className="text-indigo-700 dark:text-indigo-300 font-bold">{spec.value}</span>
                        </div>
                      ))}
                    </div>

                    {/* Key Topics List */}
                    <div className="space-y-1.5 mb-5 border-t border-slate-200 dark:border-slate-800 pt-3">
                      <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                        مفردات المنهج التخصصي:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {st.topics.map((top, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 flex items-center gap-1 font-mono"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400" />
                            <span>{top}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-mono text-slate-600 dark:text-slate-300">
                      <BookOpen className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                      <span className="font-bold text-slate-900 dark:text-white">{stageBooks.length}</span>
                      <span className="text-slate-500 dark:text-slate-400">كتب متوفرة</span>
                    </div>

                    <div className={`flex items-center gap-1.5 text-xs font-mono font-bold ${st.accentColor} group-hover:translate-x-[-4px] transition-transform`}>
                      <span>تحميل وقراءة الكتب</span>
                      <ChevronLeft className="w-4 h-4" />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Footer Note */}
        <div className="bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
            <span>نظام معمارية الحواسيب متوافق بالكامل مع مناهج التعليم المهني العراقي ومحفوظ سحابياً.</span>
          </div>
          <span className="text-[11px] text-indigo-600 dark:text-indigo-400 font-bold">
            COMPUTER_ENGINEERING // SUMER
          </span>
        </div>
      </div>
    </div>
  );
};
