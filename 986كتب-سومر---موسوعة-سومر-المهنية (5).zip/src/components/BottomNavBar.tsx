import React from 'react';
import { Home, Heart, History, User, ShieldCheck } from 'lucide-react';

export type TabType = 'home' | 'favorites' | 'recent' | 'account' | 'admin';

interface BottomNavBarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  favoritesCount: number;
  recentCount: number;
  userEmail?: string | null;
  isDeveloperAdmin?: boolean;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  favoritesCount,
  recentCount,
  userEmail,
  isDeveloperAdmin = false
}) => {
  return (
    <nav 
      aria-label="شريط التنقل السفلي"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#fffdf9]/95 dark:bg-[#081226]/95 backdrop-blur-xl border-t-2 border-black dark:border-slate-800/90 shadow-[0_-4px_25px_rgba(0,0,0,0.1)] dark:shadow-[0_-4px_25px_rgba(0,0,0,0.6)] px-2 sm:px-4 py-2 transition-all duration-300"
    >
      <div className="max-w-md mx-auto flex items-center justify-around relative">
        {/* Tab 1: Home (الرئيسية) */}
        <button
          id="nav-tab-home"
          onClick={() => onTabChange('home')}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all cursor-pointer select-none group relative ${
            activeTab === 'home'
              ? 'text-black dark:text-amber-400 font-black'
              : 'text-slate-700 dark:text-slate-400 hover:text-black dark:hover:text-slate-200 font-bold'
          }`}
        >
          {activeTab === 'home' && (
            <span className="absolute -top-2 w-8 h-1 rounded-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.9)]" />
          )}
          <div className={`p-1.5 rounded-xl transition-transform ${activeTab === 'home' ? 'scale-110 bg-amber-400/30 border border-black/30 dark:border-transparent' : 'group-hover:scale-105'}`}>
            <Home className="w-5 h-5 text-black dark:text-amber-400" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">الرئيسية</span>
        </button>

        {/* Tab 2: Favorites (الكتب المفضلة) */}
        <button
          id="nav-tab-favorites"
          onClick={() => onTabChange('favorites')}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all cursor-pointer select-none group relative ${
            activeTab === 'favorites'
              ? 'text-rose-500 dark:text-rose-400 font-black'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
          }`}
        >
          {activeTab === 'favorites' && (
            <span className="absolute -top-2 w-8 h-1 rounded-full bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.8)]" />
          )}
          <div className="relative">
            <div className={`p-1.5 rounded-xl transition-transform ${activeTab === 'favorites' ? 'scale-110 bg-rose-500/15' : 'group-hover:scale-105'}`}>
              <Heart className={`w-5 h-5 ${activeTab === 'favorites' ? 'fill-rose-500 text-rose-500' : ''}`} />
            </div>
            {favoritesCount > 0 && (
              <span className="absolute -top-0.5 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center shadow-xs">
                {favoritesCount > 99 ? '99+' : favoritesCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">المفضلة</span>
        </button>

        {/* Tab 3: Recently Viewed (آخر المشاهدة) */}
        <button
          id="nav-tab-recent"
          onClick={() => onTabChange('recent')}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all cursor-pointer select-none group relative ${
            activeTab === 'recent'
              ? 'text-cyan-600 dark:text-cyan-400 font-black'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
          }`}
        >
          {activeTab === 'recent' && (
            <span className="absolute -top-2 w-8 h-1 rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
          )}
          <div className="relative">
            <div className={`p-1.5 rounded-xl transition-transform ${activeTab === 'recent' ? 'scale-110 bg-cyan-500/15' : 'group-hover:scale-105'}`}>
              <History className="w-5 h-5" />
            </div>
            {recentCount > 0 && (
              <span className="absolute -top-0.5 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-cyan-500 text-white text-[9px] font-black flex items-center justify-center shadow-xs">
                {recentCount > 99 ? '99+' : recentCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">المشاهدة</span>
        </button>

        {/* Tab 4: Account (الحساب) */}
        <button
          id="nav-tab-account"
          onClick={() => onTabChange('account')}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all cursor-pointer select-none group relative ${
            activeTab === 'account'
              ? 'text-amber-600 dark:text-amber-400 font-black'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
          }`}
        >
          {activeTab === 'account' && (
            <span className="absolute -top-2 w-8 h-1 rounded-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.8)]" />
          )}
          <div className="relative">
            <div className={`p-1.5 rounded-xl transition-transform ${activeTab === 'account' ? 'scale-110 bg-amber-500/15' : 'group-hover:scale-105'}`}>
              <User className="w-5 h-5" />
            </div>
            {userEmail && (
              <span className="absolute top-1 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">الحساب</span>
        </button>

        {/* Tab 5: Developer Only Admin Tab (يظهر فقط لحساب المطور عند تسجيل الدخول) */}
        {isDeveloperAdmin && (
          <button
            id="nav-tab-admin"
            onClick={() => onTabChange('admin')}
            className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all cursor-pointer select-none group relative animate-in fade-in zoom-in-95 duration-300 ${
              activeTab === 'admin'
                ? 'text-emerald-700 dark:text-emerald-400 font-black'
                : 'text-emerald-600/80 dark:text-emerald-500/80 hover:text-emerald-800 dark:hover:text-emerald-300 font-bold'
            }`}
          >
            {activeTab === 'admin' && (
              <span className="absolute -top-2 w-8 h-1 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.9)]" />
            )}
            <div className="relative">
              <div className={`p-1.5 rounded-xl transition-transform ${activeTab === 'admin' ? 'scale-110 bg-emerald-500/20 border border-emerald-500/40' : 'group-hover:scale-105'}`}>
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping opacity-75" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500" />
            </div>
            <span className="text-[11px] mt-0.5 tracking-tight font-black">الإدارة</span>
          </button>
        )}
      </div>
    </nav>
  );
};
