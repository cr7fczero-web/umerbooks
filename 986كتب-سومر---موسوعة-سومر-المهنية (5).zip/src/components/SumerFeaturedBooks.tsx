import React from 'react';
import { Bookmark, ChevronLeft, Eye } from 'lucide-react';
import { Book } from '../types';

interface SumerFeaturedBooksProps {
  books: Book[];
  onReadBook: (book: Book) => void;
  favoriteIds: string[];
  onToggleFavorite: (bookId: string) => void;
  onViewAll?: () => void;
  limit?: number;
}

export const SumerFeaturedBooks: React.FC<SumerFeaturedBooksProps> = ({
  books,
  onReadBook,
  favoriteIds,
  onToggleFavorite,
  onViewAll,
  limit = 3
}) => {
  // Sort books by uploadedAt descending to get real newest additions
  const sortedBooks = [...books].sort((a, b) => {
    const timeA = a.uploadedAt ? new Date(a.uploadedAt).getTime() : 0;
    const timeB = b.uploadedAt ? new Date(b.uploadedAt).getTime() : 0;
    return timeB - timeA;
  }).slice(0, limit);

  if (sortedBooks.length === 0) {
    return null;
  }

  const getDeptBadge = (dept: string) => {
    if (dept.includes('سيبراني')) {
      return {
        label: 'أمن سيبراني',
        className: 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
      };
    }
    if (dept.includes('كهرباء')) {
      return {
        label: 'كهرباء',
        className: 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
      };
    }
    if (dept.includes('إلكترونيك') || dept.includes('الكترونيك') || dept.includes('سيطرة')) {
      return {
        label: 'إلكترونيك',
        className: 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
      };
    }
    return {
      label: 'حاسبات',
      className: 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
    };
  };

  return (
    <div className="space-y-1.5 sm:space-y-2">
      {/* Header matching the reference */}
      <div className="flex items-center justify-between px-1">
        {/* Right side: Gold vertical accent bar + "أحدث الإضافات" */}
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-3.5 sm:h-4 rounded-full bg-amber-500 inline-block shadow-xs shadow-amber-500/50" />
          <h2 className="text-xs sm:text-sm font-black text-slate-950 dark:text-white tracking-tight flex items-center gap-1.5">
            <span>أحدث الإضافات</span>
            <span className="text-[9px] sm:text-[10px] font-black text-amber-950 dark:text-amber-400/90 bg-amber-100 dark:bg-amber-400/10 px-1.5 py-0.5 rounded-md border border-black/20 dark:border-amber-400/20">
              أحدث الكتب المضافة
            </span>
          </h2>
        </div>

        {/* Left side: "عرض الكل ›" */}
        {onViewAll && (
          <button
            onClick={onViewAll}
            className="flex items-center gap-0.5 text-[11px] sm:text-xs font-black text-amber-800 dark:text-amber-400 hover:text-amber-600 dark:hover:text-amber-300 transition-colors cursor-pointer select-none"
          >
            <span>عرض التخصصات</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* List of Newly Added Books - ONLY Book Name and Details (No Cover Image/Shape) */}
      <div className="space-y-1.5">
        {sortedBooks.map((book) => {
          const isFav = favoriteIds.includes(book.id);
          const badge = getDeptBadge(book.dept);

          return (
            <div
              key={book.id}
              onClick={() => onReadBook(book)}
              className="bg-[#fffdf9] dark:bg-[#0d1b34]/90 hover:bg-amber-50/70 dark:hover:bg-[#112344] border-2 border-black dark:border-slate-800 hover:border-black rounded-xl px-2.5 sm:px-3 py-2 flex items-center justify-between gap-2 shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:shadow-[0_4px_16px_rgba(217,119,6,0.18)] group cursor-pointer transition-all duration-150 active:scale-[0.99]"
            >
              {/* Right: Dept badge + Book title + stage */}
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`text-[9px] sm:text-[10px] font-black px-1.5 py-0.5 rounded-md shrink-0 border-2 border-black/30 dark:border-transparent ${badge.className}`}>
                  {badge.label}
                </span>

                <div className="min-w-0 flex-1">
                  <h3 className="text-xs sm:text-sm font-black text-slate-950 dark:text-white group-hover:text-amber-800 dark:group-hover:text-amber-400 transition-colors truncate leading-tight">
                    {book.title}
                  </h3>
                  <p className="text-[10px] text-slate-700 dark:text-slate-400 font-semibold truncate leading-tight">
                    {book.stage}
                  </p>
                </div>
              </div>

              {/* Left: Actions (Favorite Bookmark + Read Button) */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(book.id);
                  }}
                  className={`p-1 sm:p-1.5 rounded-md transition-colors cursor-pointer border border-black/20 dark:border-transparent ${
                    isFav
                      ? 'text-amber-900 bg-amber-400 border-black dark:border-transparent'
                      : 'text-slate-500 hover:text-black dark:hover:text-white hover:bg-amber-100 dark:hover:bg-slate-800'
                  }`}
                  title={isFav ? 'في المفضلة' : 'إضافة للمفضلة'}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isFav ? 'fill-black dark:fill-amber-400' : ''}`} />
                </button>

                <div className="hidden xs:flex items-center gap-1 text-[11px] font-black text-amber-800 dark:text-amber-400 group-hover:text-black dark:group-hover:text-amber-300 pl-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">قراءة</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
