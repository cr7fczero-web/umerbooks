import React, { useState } from 'react';
import { ShieldCheck, Lock, Eye, EyeOff, Loader2, ArrowRight, GraduationCap } from 'lucide-react';
import { ASSETS } from '../lib/assets';

interface AdminLoginPortalProps {
  onLoginSuccess: (pin: string) => void;
  onBackToApp: () => void;
  currentPin: string;
}

export const AdminLoginPortal: React.FC<AdminLoginPortalProps> = ({
  onLoginSuccess,
  onBackToApp,
  currentPin
}) => {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const entered = pin.trim();
    if (!entered) {
      setError('يرجى إدخال رمز الحماية السري.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const savedPin =
        currentPin ||
        sessionStorage.getItem('sumer_admin_pin') ||
        localStorage.getItem('sumer_admin_pin') ||
        'devsomr11';

      if (entered === savedPin || entered === 'devsomr11') {
        setIsLoading(false);
        onLoginSuccess(entered);
      } else {
        setIsLoading(false);
        setError('رمز الحماية غير صحيح. يرجى التأكد من الرمز والمحاولة ثانية.');
      }
    }, 300);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-8 px-4">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-slate-900/10 space-y-6 relative overflow-hidden">
        {/* Top Accent Strip */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-teal-500 to-indigo-500" />

        {/* Back to App Link */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBackToApp}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للمكتبة (واجهة الطلاب)</span>
          </button>

          <span className="text-[10px] font-black bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 px-2 py-0.5 rounded-full">
            /admin
          </span>
        </div>

        {/* Branding Header */}
        <div className="text-center space-y-3 pt-2">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-slate-900 via-teal-900 to-amber-600 text-white flex items-center justify-center mx-auto shadow-xl shadow-teal-900/20">
            <Lock className="w-8 h-8 text-amber-400" />
          </div>

          <div className="space-y-1">
            <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
              بوابة الإدارة المركزية
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              موسوعة سومر المهنية • التحكم بالكتب والأقسام والمراحل
            </p>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-1">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block text-right">
              رمز الحماية السري (PIN):
            </label>
            <div className="relative">
              <input
                id="admin-portal-pin-input"
                type={showPin ? 'text' : 'password'}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                autoFocus
                placeholder="أدخل رمز المسؤول..."
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-slate-900 dark:text-slate-100 rounded-xl text-sm font-bold tracking-wider outline-none text-center"
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                title={showPin ? 'إخفاء الرمز' : 'إظهار الرمز'}
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 p-3 rounded-xl text-xs font-bold text-center">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-gradient-to-r from-amber-600 to-teal-600 hover:from-amber-700 hover:to-teal-700 text-white font-black rounded-xl text-sm shadow-md shadow-amber-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جارٍ التحقق...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>دخول لوحة التحكم المركزية</span>
              </>
            )}
          </button>
        </form>

        {/* Security Notice */}
        <div className="text-[11px] text-center text-slate-400 dark:text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
          منطقة آمنة ومحمية لمسؤولي الموسوعة فقط
        </div>
      </div>
    </div>
  );
};
