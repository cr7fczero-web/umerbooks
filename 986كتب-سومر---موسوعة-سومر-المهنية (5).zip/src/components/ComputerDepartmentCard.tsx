import React from 'react';
import { motion } from 'framer-motion';
import { 
  Cpu, 
  ChevronLeft, 
  BookOpen, 
  Binary, 
  HardDrive, 
  Layers,
  Sparkles
} from 'lucide-react';

interface ComputerDepartmentCardProps {
  onSelect: () => void;
  booksCount: number;
}

export const ComputerDepartmentCard: React.FC<ComputerDepartmentCardProps> = ({
  onSelect,
  booksCount
}) => {
  return (
    <motion.div
      id="dept-card-الحاسبات"
      onClick={onSelect}
      whileHover={{
        scale: 1.025,
        y: -4,
        boxShadow: '0 0 35px rgba(99, 102, 241, 0.38)'
      }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
      className="group relative bg-gradient-to-b from-white via-indigo-50/50 to-indigo-100/40 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950/80 border-2 border-indigo-200 dark:border-indigo-500/70 hover:border-indigo-400 dark:hover:border-indigo-400 rounded-3xl p-6 flex flex-col justify-between shadow-lg shadow-indigo-100/50 dark:shadow-xl dark:shadow-indigo-950/40 cursor-pointer overflow-hidden transition-colors duration-300"
    >
      {/* Printed Circuit Board (PCB) Motherboard Traces Pattern */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-20 bg-[linear-gradient(to_right,#6366f1_1px,transparent_1px),linear-gradient(to_bottom,#6366f1_1px,transparent_1px)] bg-[size:18px_18px]" 
      />

      {/* High-speed Bus Clock Signal Pulse Beam */}
      <motion.div
        className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-indigo-500 dark:via-indigo-400 to-transparent pointer-events-none"
        animate={{
          x: ['-100%', '100%'],
          opacity: [0, 1, 0]
        }}
        transition={{
          duration: 2.3,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />

      {/* Futuristic Silicon Die / Heatspreader Glow */}
      <motion.div
        className="absolute -top-10 -right-10 w-36 h-36 bg-indigo-500/15 dark:bg-indigo-500/25 rounded-full blur-2xl pointer-events-none"
        animate={{
          scale: [1, 1.25, 1],
          opacity: [0.3, 0.65, 0.3]
        }}
        transition={{
          duration: 3.2,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
      <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-violet-600/10 dark:bg-violet-600/20 rounded-full blur-xl pointer-events-none" />

      {/* Card Body */}
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          {/* Microprocessor / Silicon Chip Socket with Clock Pulse */}
          <div className="relative">
            <motion.div
              className="absolute -inset-1 rounded-2xl bg-indigo-500/20 dark:bg-indigo-500/30 blur-xs pointer-events-none"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.4, 0.9, 0.4]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            />
            <div className="relative w-14 h-14 rounded-2xl bg-white dark:bg-slate-950 border-2 border-indigo-200 dark:border-indigo-500/80 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shadow-md shadow-indigo-100 dark:shadow-indigo-950 group-hover:scale-110 group-hover:border-indigo-400 dark:group-hover:border-indigo-300 group-hover:text-indigo-700 dark:group-hover:text-indigo-200 transition-all">
              <Cpu className="w-8 h-8 animate-pulse text-indigo-600 dark:text-indigo-400" />
              <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-indigo-600 dark:bg-indigo-500 border border-white dark:border-slate-900 flex items-center justify-center text-[7px] font-mono text-white font-bold">
                i9
              </span>
            </div>
          </div>

          <div className="flex flex-col items-end gap-1">
            <span className="font-mono text-[10px] text-indigo-700 dark:text-indigo-200 bg-indigo-50 dark:bg-indigo-950/90 border border-indigo-200 dark:border-indigo-600/70 px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400 animate-ping" />
              <span>MOTHERBOARD // BIOS OK</span>
            </span>
            <span className="text-[11px] font-mono font-bold text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>{booksCount} كتب ومناهج</span>
            </span>
          </div>
        </div>

        {/* Title Tag */}
        <div className="mb-2.5 bg-white/80 dark:bg-black/60 border border-indigo-100 dark:border-indigo-950/80 rounded-xl p-2.5 shadow-xs dark:shadow-inner">
          <div className="flex items-center justify-between text-[11px] font-mono text-indigo-700 dark:text-indigo-400 mb-1">
            <span className="flex items-center gap-1">
              <Binary className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>معمارية الحاسوب والبرمجة</span>
            </span>
            <span className="text-slate-400 dark:text-slate-500 text-[10px]">x86-64 / ARM</span>
          </div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-200 transition-colors flex items-center gap-1.5">
            <span>قسم الحاسبات</span>
          </h3>
        </div>

        <h4 className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-300/90 mb-2">
          المعالجات الدقيقة، صيانة اللوحة الأم، والبرمجيات
        </h4>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
          مناهج تجميع وصيانة الحاسوب، أنظمة التشغيل، لغات البرمجة، والشبكات لكافة المراحل الدراسية.
        </p>

        {/* Live Hardware Telemetry Tag */}
        <div className="mt-3.5 py-1.5 px-3 rounded-xl bg-white/90 dark:bg-slate-950/90 border border-indigo-100 dark:border-indigo-900/60 text-[11px] font-mono text-slate-700 dark:text-slate-300 flex items-center justify-between shadow-xs dark:shadow-none">
          <div className="flex items-center gap-2">
            <span className="text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1">
              <HardDrive className="w-3 h-3 text-indigo-500 dark:text-indigo-400" />
              <span>RAM: 32GB</span>
            </span>
            <span className="text-slate-300 dark:text-slate-700">|</span>
            <span className="text-cyan-600 dark:text-cyan-400 font-bold">PCIe Gen5</span>
            <span className="text-slate-300 dark:text-slate-700">|</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">5.2 GHz</span>
          </div>
          <span className="text-indigo-600 dark:text-indigo-300 font-bold group-hover:text-indigo-700 dark:group-hover:text-indigo-200">
            دخول ⚡
          </span>
        </div>
      </div>

      {/* Card Footer Button */}
      <div className="relative z-10 mt-5 pt-3.5 border-t border-indigo-100 dark:border-indigo-950/80 flex items-center justify-between text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400 group-hover:text-indigo-700 dark:group-hover:text-indigo-200">
        <span className="flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
          <span>استكشاف مكونات الحاسوب والمناهج</span>
        </span>
        <div className="flex items-center gap-1 group-hover:translate-x-[-4px] transition-transform">
          <span>BOOT</span>
          <ChevronLeft className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
        </div>
      </div>
    </motion.div>
  );
};
