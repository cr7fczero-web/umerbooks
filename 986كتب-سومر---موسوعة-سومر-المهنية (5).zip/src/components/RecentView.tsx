import React from 'react';
import { Book } from '../types';
import { History, Eye, Download, BookOpen, Clock, Heart, Trash2 } from 'lucide-react';
import { RecentViewRecord } from '../lib/storage';

interface RecentViewProps {
  books: Book[];
  recentRecords: RecentViewRecord[];
  onReadBook: (book: Book) => void;
  favoriteIds: string[];
  onToggleFavorite: (bookId: string) => void;
  onGoToHome: () => void;
  onClearRecent: () => void;
}

export const RecentView: React.FC<RecentViewProps> = ({
  books,
  recentRecords,
  onReadBook,
  favoriteIds,
  onToggleFavorite,
  onGoToHome,
  onClearRecent
}) => {
  // Map records to book objects in exact recent order
  const recentBooksWithMeta = recentRecords
    .map((record) => {
      const book = books.find((b) => b.id === record.bookId);
      return book ? { book, viewedAt: record.viewedAt } : null;
    })
    .filter((item): item is { book: Book; viewedAt: number } => item !== null);

  const formatTimeAgo = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'الآن';
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    return `منذ ${days} يوم`;
  };

  const handleDownload = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = book.url;
    link.download = `${book.title}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className="space-y-4">
      {/* Header Card */}
      <div className="bg-gradient-to-r from-amber-50 via-sky-50/50 to-[#fffdf9] dark:from-indigo-500/10 dark:via-sky-500/5 dark:to-transparent border-2 border-black dark:border-indigo-900/40 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-3 shadow-[0_4px_16px_rgba(0,0,0,0.06)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white border-2 border-black dark:border-transparent flex items-center justify-center shadow-md shadow-indigo-600/20">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-950 dark:text-white leading-tight">
              آخر المشاهدة
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">
              سجل قراءتك للكتب والمناهج التي فتحتها مؤخراً لمتابعة دراستك فوراً
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {recentBooksWithMeta.length > 0 && (
            <button
              onClick={onClearRecent}
              className="text-[11px] font-black text-slate-700 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-500 transition-colors px-2 py-1 rounded-lg hover:bg-amber-100 dark:hover:bg-slate-800 border border-black/20 dark:border-transparent cursor-pointer"
              title="مسح السجل"
            >
              مسح السجل
            </button>
          )}
          <span className="text-xs font-black bg-amber-100 dark:bg-indigo-950/80 text-black dark:text-indigo-300 border-2 border-black dark:border-transparent px-2.5 py-1 rounded-xl shadow-2xs">
            {recentBooksWithMeta.length} كتب
          </span>
        </div>
      </div>

      {/* Empty State */}
      {recentBooksWithMeta.length === 0 ? (
        <div className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-8 sm:p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500 mx-auto flex items-center justify-center">
            <Clock className="w-8 h-8" />
          </div>
          <div className="max-w-sm mx-auto space-y-1.5">
            <h3 className="text-base font-black text-slate-800 dark:text-slate-100">
              لم تقم بفتح أي كتاب بعد
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              عند فتح أو مطالعة أي كتاب من أقسام المدرسة، سيتم حفظه تلقائياً هنا لتتمكن من استئناف قراءته بكل سرعة وسهولة.
            </p>
          </div>
          <button
            onClick={onGoToHome}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span>ابدأ تصفح الكتب الآن</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {recentBooksWithMeta.map(({ book, viewedAt }) => {
            const isFav = favoriteIds.includes(book.id);

            return (
              <div
                key={book.id}
                onClick={() => onReadBook(book)}
                className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-4 shadow-[0_4px_16px_rgba(0,0,0,0.06),0_1px_4px_rgba(217,119,6,0.12)] hover:shadow-[0_8px_24px_rgba(217,119,6,0.22)] hover:border-black transition-all group cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {book.dept} • {book.stage}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-bold text-slate-400 flex items-center gap-0.5">
                        <Clock className="w-2.5 h-2.5" />
                        <span>{formatTimeAgo(viewedAt)}</span>
                      </span>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(book.id);
                        }}
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          isFav 
                            ? 'text-rose-500 bg-rose-50 dark:bg-rose-950/70' 
                            : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                        title={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500' : ''}`} />
                      </button>
                    </div>
                  </div>

                  <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-2 mb-1.5">
                    {book.title}
                  </h4>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 font-bold text-xs group-hover:translate-x-[-2px] transition-transform"
                  >
                    <Eye className="w-4 h-4" />
                    <span>متابعة القراءة</span>
                  </button>

                  <button
                    type="button"
                    onClick={(e) => handleDownload(e, book)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                    title="تحميل الكتاب"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
