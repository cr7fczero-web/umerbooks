import React, { useState, useRef, useEffect } from 'react';
import { Search, X, Sun, Moon, EllipsisVertical, Info, RefreshCw, GraduationCap, LogIn, UserCheck } from 'lucide-react';
import { ASSETS } from '../lib/assets';
import { ActiveReadersBadge } from './ActiveReadersBadge';
import { IraqiFlag } from './IraqiFlag';

interface SumerHeroSectionProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onLogoClick?: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenAbout?: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  isAdmin?: boolean;
  onOpenAdmin?: () => void;
  currentUserEmail?: string | null;
  onOpenGoogleAuth?: () => void;
}

export const SumerHeroSection: React.FC<SumerHeroSectionProps> = ({
  searchQuery,
  onSearchChange,
  onLogoClick,
  isDarkMode,
  onToggleDarkMode,
  onOpenAbout,
  onRefreshData,
  isRefreshing = false,
  isAdmin = false,
  onOpenAdmin,
  currentUserEmail,
  onOpenGoogleAuth
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const clickCountRef = useRef<number>(0);
  const clickTimerRef = useRef<any>(null);

  const handleSecretLogoClick = () => {
    clickCountRef.current += 1;
    if (clickTimerRef.current) {
      clearTimeout(clickTimerRef.current);
    }

    if (clickCountRef.current >= 5) {
      clickCountRef.current = 0;
      if (onOpenAdmin) {
        onOpenAdmin();
      }
      return;
    }

    clickTimerRef.current = setTimeout(() => {
      clickCountRef.current = 0;
    }, 1800);

    if (onLogoClick) {
      onLogoClick();
    }
  };

  // Close dropdown menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  return (
    <div className="space-y-2.5 sm:space-y-3">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-1">
        {/* Left: Active Readers Live Badge */}
        <div className="flex items-center gap-2">
          <ActiveReadersBadge />
        </div>

        {/* Right: Controls & Badges (Theme Toggle, 3-Dots Menu & Iraq Badge) */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Day / Night Theme Toggle Button */}
          <button
            id="home-theme-toggle-btn"
            type="button"
            onClick={onToggleDarkMode}
            className="p-1.5 rounded-full bg-amber-50/90 dark:bg-[#0d1b34] hover:bg-amber-100 dark:hover:bg-[#152a4f] border-2 border-black dark:border-slate-800 hover:border-black dark:hover:border-amber-400/50 text-slate-950 dark:text-amber-300 flex items-center justify-center transition-all cursor-pointer shadow-xs active:scale-95"
            title={isDarkMode ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي'}
            aria-label="تبديل الوضع الليلي والنهاري"
          >
            {isDarkMode ? (
              <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 animate-spin [animation-duration:15s]" />
            ) : (
              <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-950" />
            )}
          </button>

          {/* Three Dots Menu for Home Page */}
          <div className="relative" ref={menuRef}>
            <button
              id="home-more-options-btn"
              type="button"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-1.5 rounded-full bg-amber-50/90 dark:bg-[#0d1b34] hover:bg-amber-100 dark:hover:bg-[#152a4f] border-2 border-black dark:border-slate-800 text-slate-950 dark:text-slate-200 flex items-center justify-center transition-all cursor-pointer shadow-xs active:scale-95"
              title="القائمة والخيارات"
              aria-label="القائمة والخيارات"
            >
              <EllipsisVertical className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-72 sm:w-80 bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3.5 py-1.5 border-b border-black/10 dark:border-slate-800 flex items-center justify-between text-xs font-black text-slate-700 dark:text-slate-500">
                  <span>خيارات التطبيق</span>
                  <button
                    onClick={() => setIsMenuOpen(false)}
                    className="p-1 text-slate-500 hover:text-black dark:text-slate-400 dark:hover:text-slate-200 rounded-md cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Dedication Banner - هذا العمل من قبل الطالب سجاد محمد وهو إهداء لمدرسة سومر المهنية */}
                <div className="m-2 p-3 bg-gradient-to-br from-amber-100/90 via-yellow-50 to-amber-50 dark:from-slate-800 dark:via-slate-800/90 dark:to-slate-800 border-2 border-black dark:border-teal-700/60 rounded-xl text-right shadow-xs">
                  <div className="flex items-center gap-1.5 text-amber-950 dark:text-teal-300 font-black text-xs mb-1">
                    <GraduationCap className="w-4 h-4 text-amber-700 dark:text-teal-400 shrink-0" />
                    <span>إهداء وتقدير</span>
                  </div>
                  <p className="text-[11.5px] leading-relaxed text-black dark:text-slate-200 font-semibold">
                    هذا العمل من قبل الطالب{' '}
                    <span className="font-extrabold text-amber-900 dark:text-teal-300 underline decoration-amber-500 decoration-1">
                      سجاد محمد
                    </span>{' '}
                    وهو إهداء لمدرسة سومر المهنية.
                  </p>
                </div>

                <div className="p-1 space-y-0.5">
                  {onOpenGoogleAuth && (
                    <button
                      id="hero-google-auth-btn"
                      onClick={() => {
                        setIsMenuOpen(false);
                        onOpenGoogleAuth();
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        {currentUserEmail ? (
                          <UserCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        ) : (
                          <LogIn className="w-3.5 h-3.5 text-amber-700 dark:text-teal-400" />
                        )}
                        <span>{currentUserEmail ? 'حسابي' : 'تسجيل الدخول'}</span>
                      </div>
                      {currentUserEmail && (
                        <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 px-1.5 py-0.5 rounded font-mono truncate max-w-[90px]">
                          {currentUserEmail.split('@')[0]}
                        </span>
                      )}
                    </button>
                  )}

                  {onOpenAbout && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        onOpenAbout();
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right"
                    >
                      <Info className="w-3.5 h-3.5 text-amber-700 dark:text-teal-400" />
                      <span>حول التطبيق والمطور</span>
                    </button>
                  )}

                  {onRefreshData && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        onRefreshData();
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 text-amber-700 dark:text-teal-400 ${isRefreshing ? 'animate-spin' : ''}`} />
                      <span>تحديث الكتب من السحابة</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setIsMenuOpen(false);
                      onToggleDarkMode();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right"
                  >
                    {isDarkMode ? (
                      <>
                        <Sun className="w-3.5 h-3.5 text-amber-500" />
                        <span>التحويل للوضع النهاري</span>
                      </>
                    ) : (
                      <>
                        <Moon className="w-3.5 h-3.5 text-slate-900" />
                        <span>التحويل للوضع الليلي</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Iraq Badge with Iraqi Flag containing Allahu Akbar */}
          <div className="flex items-center gap-1.5 sm:gap-2 px-2.5 py-1 rounded-full bg-amber-50/90 dark:bg-[#0d1b34] border-2 border-black dark:border-slate-800 text-slate-950 dark:text-white shadow-xs">
            <span className="text-[11px] sm:text-xs font-black tracking-wide">العراق</span>
            <IraqiFlag className="w-6.5 h-[16px] sm:w-8 sm:h-[19px]" />
          </div>
        </div>
      </div>

      {/* Hero Banner with Ziggurat of Ur & Sumerian Logo - Compact & Viewport-friendly */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#fff9e6] via-[#fef3cc] to-[#fdebb3] dark:from-[#0a1529] dark:via-[#0d1b34] dark:to-[#122240] border-2 border-black dark:border-amber-400/20 shadow-[0_8px_30px_rgba(0,0,0,0.08),0_2px_8px_rgba(217,119,6,0.18)] dark:shadow-lg dark:shadow-black/40 h-[76px] sm:h-[90px] flex items-center">
        {/* Right side: Ziggurat Image with soft edge mask fade */}
        <div className="absolute top-0 bottom-0 left-0 sm:left-auto right-0 w-[55%] sm:w-[48%] overflow-hidden pointer-events-none">
          <img
            src={ASSETS.zigguratHero}
            alt="زقورة أور السومرية"
            className="w-full h-full object-cover object-center opacity-65 sm:opacity-80"
          />
          {/* Smooth gradient blend mask towards left */}
          <div className="absolute inset-0 bg-gradient-to-l from-transparent via-[#fef3cc]/80 to-[#fff9e6] dark:via-[#0d1b34]/70 dark:to-[#0a1529]" />
        </div>

        {/* Left side content: Logo and Title */}
        <div className="relative z-10 px-3 sm:px-4 py-2 flex items-center gap-2.5 sm:gap-3.5 max-w-[78%] sm:max-w-[70%]">
          {/* Golden Book Ziggurat Emblem */}
          <button
            type="button"
            onClick={handleSecretLogoClick}
            className="w-11 h-11 sm:w-13 sm:h-13 rounded-xl bg-gradient-to-br from-amber-400/40 via-yellow-400/30 to-amber-500/20 border-2 border-black dark:border-amber-400/30 p-1 flex items-center justify-center shrink-0 shadow-md shadow-amber-500/20 backdrop-blur-xs cursor-pointer hover:scale-105 active:scale-95 transition-transform"
            title="موسوعة سومر المهنية"
          >
            <img
              src={ASSETS.sumerLogo}
              alt="شعار موسوعة سومر"
              className="w-full h-full object-contain rounded-lg"
            />
          </button>

          <div className="space-y-0.5 leading-none">
            <h1 className="text-sm sm:text-lg font-black tracking-tight leading-tight flex items-baseline gap-1.5">
              <span className="text-amber-800 dark:text-amber-400 drop-shadow-[0_1px_2px_rgba(245,158,11,0.2)]">
                موسوعة سومر
              </span>
              <span className="text-black dark:text-white">المهنية</span>
            </h1>
            <p className="text-[10px] sm:text-[11px] font-bold text-slate-800 dark:text-slate-300/80 leading-tight">
              معاً نحو مستقبل مهني أفضل
            </p>
          </div>
        </div>
      </div>

      {/* Search Input Bar - Sleek & Compact */}
      <div className="relative">
        <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
          <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-600 dark:text-amber-400/80" />
        </div>
        <input
          id="sumer-search-input"
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="ابحث عن كتاب أو تخصص أو مادة..."
          className="w-full pr-9 pl-9 py-2 sm:py-2.5 bg-white dark:bg-[#0d1b34]/90 border-2 border-black dark:border-slate-800 hover:border-black dark:hover:border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-400/30 text-slate-950 dark:text-white placeholder:text-slate-500 rounded-xl text-xs sm:text-sm font-bold outline-none shadow-xs dark:shadow-inner transition-all"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white rounded-md cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
