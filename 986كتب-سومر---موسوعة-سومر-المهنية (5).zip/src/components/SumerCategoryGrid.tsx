import React from 'react';
import { ChevronLeft } from 'lucide-react';
import { Book, DepartmentId, DepartmentItem } from '../types';
import { DEFAULT_DEPARTMENTS, getDepartmentIcon, getColorThemeClasses } from '../lib/departments';

interface SumerCategoryGridProps {
  books: Book[];
  departments?: DepartmentItem[];
  onSelectDept: (dept: DepartmentId) => void;
  selectedDept?: DepartmentId | null;
}

export const SumerCategoryGrid: React.FC<SumerCategoryGridProps> = ({
  books,
  departments = DEFAULT_DEPARTMENTS,
  onSelectDept,
  selectedDept
}) => {
  return (
    <div className="space-y-1.5">
      {/* Vocational Departments Grid (Dynamic responsive grid) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 sm:gap-2.5">
        {departments.map((item) => {
          const Icon = getDepartmentIcon(item.iconName);
          const theme = getColorThemeClasses(item.colorTheme);
          const bookCount = books.filter((b) => b.dept === item.name || b.dept === item.dept).length;
          const isSelected = selectedDept === item.name || selectedDept === item.dept;

          return (
            <button
              key={item.id}
              onClick={() => onSelectDept(item.name || item.dept)}
              className={`bg-[#fffdf9] dark:bg-[#0d1b34]/90 hover:bg-amber-50/70 dark:hover:bg-[#112344] border-2 border-black dark:border-slate-800 hover:border-black dark:hover:border-amber-400/40 rounded-xl sm:rounded-2xl p-2.5 sm:p-3 flex flex-col items-center text-center transition-all duration-200 cursor-pointer shadow-[0_4px_12px_rgba(0,0,0,0.06),0_1px_4px_rgba(217,119,6,0.1)] hover:shadow-[0_8px_24px_rgba(217,119,6,0.22)] dark:shadow-md dark:shadow-black/25 group active:scale-[0.97] ${
                isSelected ? `ring-2 ${theme.activeRing}` : ''
              }`}
            >
              <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl ${theme.iconBg} border-2 border-black/30 dark:border-transparent flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform shadow-xs`}>
                <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <h3 className="text-xs sm:text-sm font-black text-slate-950 dark:text-white group-hover:text-amber-800 dark:group-hover:text-amber-400 transition-colors leading-tight mb-0.5 line-clamp-1">
                {item.title || item.name}
              </h3>
              <div className="flex items-center gap-1 text-[10px] sm:text-[11px] font-bold text-slate-700 dark:text-slate-400 group-hover:text-black dark:group-hover:text-slate-300">
                <ChevronLeft className="w-3 h-3 text-amber-700 dark:text-amber-400/70 group-hover:translate-x-[-1px] transition-transform" />
                <span className="bg-amber-100/90 dark:bg-transparent px-1.5 py-0.2 rounded-md border border-black/20 dark:border-transparent text-amber-950 dark:text-slate-400 font-extrabold">{bookCount} {bookCount > 10 ? 'كتاب' : 'كتب'}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
