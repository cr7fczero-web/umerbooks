import React from 'react';
import { ArrowRight, BookOpen, Layers, Award, Sparkles, ChevronLeft } from 'lucide-react';
import { DepartmentId, StageId, Book } from '../types';
import { RecentlyAddedSection } from './RecentlyAddedSection';

interface StagesViewProps {
  currentDept: DepartmentId;
  onBackToDepts: () => void;
  onSelectStage: (stage: StageId) => void;
  books: Book[];
  onReadBook?: (book: Book) => void;
  favoriteIds?: string[];
  onToggleFavorite?: (bookId: string) => void;
}

interface StageItem {
  id: StageId;
  numberStr: string;
  name: string;
  sub: string;
  badge?: string;
  color: string;
  bg: string;
  border: string;
}

const STAGES: StageItem[] = [
  {
    id: 'المرحلة الأولى',
    numberStr: '١',
    name: 'المرحلة الأولى',
    sub: 'الكتب والمناهج التأسيسية للصف الأول المهني',
    color: 'text-teal-700 dark:text-teal-300',
    bg: 'bg-teal-50 dark:bg-teal-950/60',
    border: 'border-teal-200 dark:border-teal-800 hover:border-teal-400'
  },
  {
    id: 'المرحلة الثانية',
    numberStr: '٢',
    name: 'المرحلة الثانية',
    sub: 'المناهج التخصصية المتقدمة للصف الثاني المهني',
    color: 'text-sky-700 dark:text-sky-300',
    bg: 'bg-sky-50 dark:bg-sky-950/60',
    border: 'border-sky-200 dark:border-sky-800 hover:border-sky-400'
  },
  {
    id: 'المرحلة الثالثة',
    numberStr: '٣',
    name: 'المرحلة الثالثة',
    sub: 'المناهج الوزارية التخصصية للصف الثالث المهني',
    badge: 'الامتحان الوزاري',
    color: 'text-amber-700 dark:text-amber-300',
    bg: 'bg-amber-50 dark:bg-amber-950/60',
    border: 'border-amber-200 dark:border-amber-800 hover:border-amber-400'
  }
];

export const StagesView: React.FC<StagesViewProps> = ({
  currentDept,
  onBackToDepts,
  onSelectStage,
  books,
  onReadBook,
  favoriteIds = [],
  onToggleFavorite = () => {}
}) => {
  // Books of this department
  const deptBooks = books.filter((b) => b.dept === currentDept);

  return (
    <section className="space-y-4 sm:space-y-5">
      {/* Top Breadcrumb & Back Header */}
      <div className="flex items-center justify-between gap-2 bg-[#fffdf9] dark:bg-slate-900 p-3 sm:p-4 rounded-2xl border-2 border-black dark:border-slate-800 shadow-[0_2px_10px_rgba(0,0,0,0.05)]">
        <button
          id="back-to-depts-btn"
          onClick={onBackToDepts}
          className="inline-flex items-center gap-1.5 text-xs font-black text-slate-950 dark:text-slate-200 hover:text-amber-800 dark:hover:text-teal-400 transition-colors cursor-pointer select-none"
        >
          <ArrowRight className="w-4 h-4 text-amber-700 dark:text-teal-400" />
          <span>رجوع إلى كافة الأقسام</span>
        </button>

        <div className="flex items-center gap-1.5">
          <span className="text-[11px] text-slate-600 dark:text-slate-400 font-bold hidden xs:inline">القسم:</span>
          <span className="bg-amber-100 dark:bg-teal-950/60 border-2 border-black dark:border-teal-800 text-black dark:text-teal-300 text-xs font-black px-2.5 py-1 rounded-xl shadow-2xs">
            {currentDept}
          </span>
        </div>
      </div>

      {/* Compact Title */}
      <div className="px-1 space-y-0.5">
        <h2 className="text-base sm:text-lg font-black text-slate-950 dark:text-white">
          المراحل الدراسية لـ {currentDept}
        </h2>
        <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">
          اختر المرحلة الدراسية لتصفح المناهج والكتب التخصصية المقررة
        </p>
      </div>

      {/* 3 Stages Cards - Compact Mobile Layout */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {STAGES.map((st) => {
          const stageBooks = books.filter(
            (b) => b.dept === currentDept && b.stage === st.id
          );

          return (
            <div
              id={`stage-card-${st.id}`}
              key={st.id}
              onClick={() => onSelectStage(st.id)}
              className={`group bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between sm:flex-col sm:items-center sm:text-center shadow-[0_4px_16px_rgba(0,0,0,0.06),0_1px_4px_rgba(217,119,6,0.12)] hover:shadow-[0_8px_24px_rgba(217,119,6,0.22)] hover:border-black transition-all duration-200 cursor-pointer hover:-translate-y-0.5 active:scale-[0.98] select-none`}
            >
              <div className="flex items-center gap-3 sm:flex-col sm:gap-2">
                {/* Number Badge */}
                <div className={`w-12 h-12 rounded-2xl ${st.bg} ${st.color} border-2 border-black/30 dark:border-transparent flex items-center justify-center font-black text-xl shadow-2xs group-hover:scale-105 transition-transform`}>
                  {st.numberStr}
                </div>

                <div className="sm:text-center">
                  <div className="flex items-center gap-1.5 sm:justify-center">
                    <h3 className="text-sm sm:text-base font-black text-slate-950 dark:text-white group-hover:text-amber-800 dark:group-hover:text-teal-300 transition-colors">
                      {st.name}
                    </h3>
                    {st.badge && (
                      <span className="text-[9px] font-black bg-amber-200 dark:bg-amber-950 text-amber-950 dark:text-amber-300 border border-black/30 dark:border-transparent px-1.5 py-0.2 rounded-md">
                        {st.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 font-medium line-clamp-1 mt-0.5">
                    {st.sub}
                  </p>
                </div>
              </div>

              {/* Books count & Arrow */}
              <div className="flex items-center gap-2 sm:mt-3 sm:pt-2 sm:border-t-2 sm:border-black/10 sm:dark:border-slate-800 sm:w-full sm:justify-between">
                <span className="text-[11px] font-black text-black dark:text-slate-400 bg-amber-100 dark:bg-slate-800 border border-black/30 dark:border-transparent px-2 py-0.5 rounded-lg flex items-center gap-1">
                  <BookOpen className="w-3 h-3 text-amber-700 dark:text-teal-400" />
                  <span>{stageBooks.length} كتب</span>
                </span>
                <ChevronLeft className="w-4 h-4 text-amber-700 dark:text-teal-400 group-hover:translate-x-[-2px] transition-transform" />
              </div>
            </div>
          );
        })}
      </div>

      {/* "وجوه تظهر آخر الكتب أضافه للتطبيق" (Recently Added in this Department or Overall) */}
      {onReadBook && (
        <div className="pt-2">
          <RecentlyAddedSection
            books={deptBooks.length > 0 ? deptBooks : books}
            onReadBook={onReadBook}
            favoriteIds={favoriteIds}
            onToggleFavorite={onToggleFavorite}
            title={`آخر الكتب المضافة لـ ${currentDept}`}
            subTitle="أحدث المناهج والكتب المقررة لهذا التخصص"
            limit={6}
          />
        </div>
      )}
    </section>
  );
};
