import React, { useState } from 'react';
import { Book } from '../types';
import { Heart, Search, Eye, Download, BookOpen, Trash2, ArrowLeft, FolderHeart } from 'lucide-react';

interface FavoritesViewProps {
  books: Book[];
  favoriteIds: string[];
  onToggleFavorite: (bookId: string) => void;
  onReadBook: (book: Book) => void;
  onGoToHome: () => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  books,
  favoriteIds,
  onToggleFavorite,
  onReadBook,
  onGoToHome
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const favoriteBooks = books.filter((b) => favoriteIds.includes(b.id));

  const filteredBooks = favoriteBooks.filter(
    (b) =>
      b.title.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      b.dept.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      b.stage.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const handleDownload = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = book.url;
    link.download = `${book.title}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className="space-y-4">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-amber-50 via-rose-50/50 to-[#fffdf9] dark:from-rose-500/10 dark:via-pink-500/5 dark:to-transparent border-2 border-black dark:border-rose-900/40 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-3 shadow-[0_4px_16px_rgba(0,0,0,0.06)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white border-2 border-black dark:border-transparent flex items-center justify-center shadow-md shadow-rose-500/20">
            <Heart className="w-5 h-5 fill-white" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-950 dark:text-white leading-tight">
              الكتب المفضلة
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">
              قائمتك الخاصة بالكتب والمناهج التي قمت بحفظها لسهولة الرجوع إليها
            </p>
          </div>
        </div>

        <span className="text-xs font-black bg-amber-100 dark:bg-rose-950/80 text-black dark:text-rose-300 border-2 border-black dark:border-transparent px-2.5 py-1 rounded-xl shadow-2xs">
          {favoriteBooks.length} كتب
        </span>
      </div>

      {/* Search Bar if there are favorites */}
      {favoriteBooks.length > 0 && (
        <div className="relative">
          <Search className="w-4 h-4 text-amber-600 dark:text-slate-500 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في قائمة المفضلة..."
            className="w-full pr-10 pl-4 py-2.5 bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 focus:border-amber-500 focus:ring-2 focus:ring-amber-400/20 text-slate-950 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-bold outline-none shadow-xs"
          />
        </div>
      )}

      {/* Empty State */}
      {favoriteBooks.length === 0 ? (
        <div className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-8 sm:p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-500 mx-auto flex items-center justify-center">
            <FolderHeart className="w-8 h-8" />
          </div>
          <div className="max-w-sm mx-auto space-y-1.5">
            <h3 className="text-base font-black text-slate-800 dark:text-slate-100">
              لا توجد كتب في المفضلة بعد
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              يمكنك النقر على رمز القلب (<Heart className="w-3.5 h-3.5 inline text-rose-500" />) على أي كتاب في الأقسام لإضافته هنا ومطالعته لاحقاً في أي وقت.
            </p>
          </div>
          <button
            onClick={onGoToHome}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span>تصفح الأقسام والكتب الآن</span>
          </button>
        </div>
      ) : filteredBooks.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center space-y-2">
          <p className="text-xs font-bold text-slate-500">لا توجد نتائج مطابقة لبحثك في المفضلة</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredBooks.map((book) => (
            <div
              key={book.id}
              onClick={() => onReadBook(book)}
              className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-4 shadow-[0_4px_16px_rgba(0,0,0,0.06),0_1px_4px_rgba(217,119,6,0.12)] hover:shadow-[0_8px_24px_rgba(217,119,6,0.22)] hover:border-black transition-all group cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    {book.dept} • {book.stage}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(book.id);
                    }}
                    className="p-1.5 rounded-lg text-rose-500 bg-rose-50 dark:bg-rose-950/70 hover:bg-rose-100 dark:hover:bg-rose-900/80 transition-colors cursor-pointer"
                    title="إزالة من المفضلة"
                  >
                    <Heart className="w-4 h-4 fill-rose-500" />
                  </button>
                </div>

                <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors line-clamp-2 mb-1.5">
                  {book.title}
                </h4>

                {book.fileName && (
                  <p className="text-[11px] text-slate-400 truncate dir-ltr text-right mb-2">
                    {book.fileName}
                  </p>
                )}
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <button
                  type="button"
                  className="inline-flex items-center gap-1.5 text-rose-600 dark:text-rose-400 font-bold text-xs group-hover:translate-x-[-2px] transition-transform"
                >
                  <Eye className="w-4 h-4" />
                  <span>فتح وقراءة</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => handleDownload(e, book)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                  title="تحميل الكتاب"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
