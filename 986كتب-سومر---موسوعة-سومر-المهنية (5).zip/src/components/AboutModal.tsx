import React from 'react';
import { X, GraduationCap, UserCheck, Globe, LogIn } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserEmail?: string | null;
  onOpenGoogleAuth?: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ 
  isOpen, 
  onClose,
  currentUserEmail,
  onOpenGoogleAuth
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#fffdf9] dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border-2 border-black dark:border-slate-800 text-center relative overflow-hidden">
        {/* Close Icon */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 text-slate-500 dark:text-slate-500 hover:text-black dark:hover:text-slate-300 rounded-xl hover:bg-amber-100 dark:hover:bg-slate-800 border border-black/20 dark:border-transparent transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Avatar badge */}
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 via-yellow-500 to-amber-600 text-black border-2 border-black dark:border-transparent flex items-center justify-center mx-auto mb-4 shadow-xl shadow-amber-500/20">
          <GraduationCap className="w-10 h-10" />
        </div>

        <h3 className="text-xl font-black text-slate-950 dark:text-slate-100 mb-1">
          كتب سومر
        </h3>
        <p className="text-xs font-black text-amber-800 dark:text-teal-400 mb-4">
          موسوعة سومر المهنية للكتب والمناهج
        </p>

        {/* Dedication text */}
        <div className="bg-gradient-to-br from-amber-100/90 via-yellow-50 to-amber-50 dark:bg-slate-800/80 border-2 border-black dark:border-slate-700/80 rounded-2xl p-4 text-xs text-slate-800 dark:text-slate-300 leading-relaxed text-right space-y-2 mb-3 shadow-2xs">
          <div className="flex items-center gap-2 text-black dark:text-slate-200 font-black">
            <UserCheck className="w-4 h-4 text-amber-700 dark:text-teal-400 shrink-0" />
            <span>صُنع هذا التطبيق وبرمجته بواسطة الطالب:</span>
          </div>
          <p className="pr-6 font-black text-sm text-black dark:text-teal-300">
            سجاد محمد
            <span className="font-bold text-xs text-amber-800 dark:text-teal-400 mr-2">
              (قسم الأمن السيبراني)
            </span>
          </p>
          <div className="pt-2 border-t-2 border-black/10 dark:border-slate-700 text-slate-800 dark:text-slate-300 font-semibold">
            🎓 هذا التطبيق <strong>هدية متواضعة إلى مدرسة سومر المهنية</strong> وكوادرها الإدارية والتدريسية وطلابها الأعزاء لتسهيل الوصول إلى الكتب والمناهج الدراسية بكل يسر.
          </div>
        </div>

        {/* Cloud Sync Feature Details */}
        <div className="bg-amber-50/70 dark:bg-emerald-950/40 border-2 border-black dark:border-emerald-800/60 rounded-2xl p-3.5 text-xs text-slate-900 dark:text-emerald-200 text-right space-y-1.5 mb-4 shadow-2xs">
          <div className="flex items-center gap-2 font-black text-black dark:text-emerald-300">
            <Globe className="w-4 h-4 text-amber-700 dark:text-emerald-400" />
            <span>نظام التزامن السحابي الموحد:</span>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-800 dark:text-emerald-300/90 font-medium">
            يعتمد التطبيق على خادم مركزي دائم يضمن توفر كل كتاب يتم نشره لجميع الطلاب وفي كافة المتصفحات والهواتف تلقائياً.
          </p>
        </div>

        {/* Account Section */}
        {onOpenGoogleAuth && (
          <div className="mb-4">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenGoogleAuth();
              }}
              className="w-full py-2.5 px-3 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 border-2 border-black dark:border-slate-700 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
            >
              <LogIn className="w-4 h-4 text-amber-700 dark:text-teal-400" />
              <span>{currentUserEmail ? `حسابي (${currentUserEmail})` : 'حسابي (تسجيل الدخول / إنشاء حساب جديد)'}</span>
            </button>
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-500 hover:to-yellow-500 text-black border-2 border-black dark:border-transparent dark:bg-teal-700 dark:text-white rounded-xl text-xs sm:text-sm font-black shadow-xs transition-colors cursor-pointer"
        >
          إغلاق
        </button>
      </div>
    </div>
  );
};
