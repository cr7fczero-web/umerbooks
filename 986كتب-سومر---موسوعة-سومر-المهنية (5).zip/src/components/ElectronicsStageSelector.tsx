import React from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowRight, 
  BookOpen, 
  ChevronLeft, 
  Award, 
  Layers, 
  CheckCircle2,
  CircuitBoard,
  Sparkles,
  Zap,
  Activity
} from 'lucide-react';
import { StageId, Book } from '../types';

interface ElectronicsStageSelectorProps {
  books: Book[];
  onBackToDepts: () => void;
  onSelectStage: (stage: StageId) => void;
}

interface TransistorStageDetail {
  id: StageId;
  componentFamily: string;
  pinout: string;
  stageTitle: string;
  semiconductorType: string;
  description: string;
  topics: string[];
  specs: { label: string; value: string }[];
  badge?: string;
  accentColor: string;
  borderGlow: string;
  bgGlow: string;
}

const ELECTRONIC_STAGES: TransistorStageDetail[] = [
  {
    id: 'المرحلة الأولى',
    componentFamily: 'TRANSISTOR TIER 1 // الدايود والترانزستور الثنائي',
    pinout: 'EMITTER - BASE - COLLECTOR (E-B-C)',
    stageTitle: 'أشباه الموصلات وترانزستورات BJT ومكبرات الإشارة',
    semiconductorType: 'SILICON BJT // NPN & PNP',
    description: 'نظرية الوصلة الثنائية P-N، انحياز الترانزستور الأمامي والعكسي، منحنيات الخواص، واستخدام الترانزستور كمفتاح ومكبر.',
    topics: ['أشباه الموصلات النقية والشوائب (N-type / P-type)', 'ترانزستور ثنائي القطبية BJT ونقاط التشغيل Q-Point', 'دوائر التكبير والانحياز والتنعيم'],
    specs: [
      { label: 'JUNCTION', value: 'Si 0.7V' },
      { label: 'GAIN (β)', value: '100 - 300' },
      { label: 'Vce(sat)', value: '0.2 V' }
    ],
    accentColor: 'text-teal-700 dark:text-teal-400',
    borderGlow: 'hover:border-teal-400 hover:shadow-teal-500/20',
    bgGlow: 'bg-teal-100 dark:bg-teal-950/40'
  },
  {
    id: 'المرحلة الثانية',
    componentFamily: 'TRANSISTOR TIER 2 // ترانزستورات التأثير المجالي ومكبرات العمليات',
    pinout: 'GATE - DRAIN - SOURCE (G-D-S)',
    stageTitle: 'الموسفت (MOSFET) والدوائر المتكاملة والخزن',
    semiconductorType: 'FIELD EFFECT // MOSFET & OP-AMP',
    description: 'ترانزستور التأثير المجالي FET والموسفت فائق السرعة، مكبرات العمليات التشغيلية (Op-Amp)، ودوائر المؤقتات 555 وخلايا الذاكرة.',
    topics: ['ترانزستورات MOSFET ذات البوابة المعزولة', 'المكبر العملياتي Op-Amp (المقارن، الجامع، التكاملي)', 'خلايا الذاكرة وعناصر الخزن الرقمي (Flip-Flops)'],
    specs: [
      { label: 'CHANNEL', value: 'N-Channel' },
      { label: 'Vgs(th)', value: '2.5 V' },
      { label: 'Rds(on)', value: '18 mΩ' }
    ],
    accentColor: 'text-cyan-700 dark:text-cyan-400',
    borderGlow: 'hover:border-cyan-400 hover:shadow-cyan-500/20',
    bgGlow: 'bg-cyan-100 dark:bg-cyan-950/40'
  },
  {
    id: 'المرحلة الثالثة',
    componentFamily: 'CONTROL TIER 3 // منظومات السيطرة الصناعية والامتحان الوزاري',
    pinout: 'PLC INPUTS / OUTPUTS & THYRISTORS',
    stageTitle: 'متحكمات PLC، الثايرستورات، والمناهج الوزارية',
    semiconductorType: 'INDUSTRIAL AUTOMATION // PLC & TRIAC',
    description: 'السيطرة المنطقية المبرمجة PLC، عناصر القدرة الإلكترونية (SCR, Triac)، حساسات القياس الصناعية، والامتحانات الوزارية النهائية.',
    topics: ['برمجة وتطبيق منظومات السيطرة PLC ومخططات السلم', 'إلكترونيات القدرة الصناعية (الثايرستور والداياك والتراياك)', 'المناهج الوزارية المعتمدة للامتحان النهائي'],
    specs: [
      { label: 'LOGIC', value: 'Ladder Diagram' },
      { label: 'ISOLATION', value: 'Optocoupler' },
      { label: 'EXAM TIER', value: 'الوزاري النهائي' }
    ],
    badge: 'الامتحان الوزاري النهائي',
    accentColor: 'text-emerald-700 dark:text-emerald-400',
    borderGlow: 'hover:border-emerald-400 hover:shadow-emerald-500/20',
    bgGlow: 'bg-emerald-100 dark:bg-emerald-950/40'
  }
];

export const ElectronicsStageSelector: React.FC<ElectronicsStageSelectorProps> = ({
  books,
  onBackToDepts,
  onSelectStage
}) => {
  return (
    <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-slate-950 border-2 border-teal-200 dark:border-teal-500/60 shadow-xl dark:shadow-2xl dark:shadow-teal-950/50 text-slate-900 dark:text-slate-100 font-sans transition-all duration-500">
      {/* Transistor micro-matrix background pattern */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-20 bg-[radial-gradient(#14b8a6_1px,transparent_1px)] [background-size:20px_20px]" 
      />
      <div 
        className="absolute inset-0 pointer-events-none bg-radial from-transparent via-slate-100/50 dark:via-slate-950/70 to-slate-100 dark:to-slate-950 opacity-90" 
      />

      {/* Top Header Bar */}
      <div className="relative z-10 border-b border-slate-200 dark:border-teal-900/60 bg-slate-50/95 dark:bg-slate-900/90 backdrop-blur-md px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDepts}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-300 bg-white dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-slate-750 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 transition-all cursor-pointer group shadow-xs"
          >
            <ArrowRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform text-teal-600 dark:text-teal-400" />
            <span>خروج إلى كافة الأقسام</span>
          </button>
        </div>

        {/* Center Tag */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <CircuitBoard className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span className="text-teal-700 dark:text-teal-300 font-black tracking-wider">مناهج قسم إلكترونيك السيطرة والخزن</span>
          <span className="text-slate-400 dark:text-slate-600">|</span>
          <span className="text-slate-600 dark:text-slate-400 hidden sm:inline">مدرسة سومر المهنية</span>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <span className="hidden sm:inline">مزامنة سحابية نشطة</span>
        </div>
      </div>

      {/* Main Semiconductor & Transistor Body */}
      <div className="relative z-10 p-5 sm:p-8 space-y-6">
        {/* Section Header Card */}
        <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-teal-50 via-white to-teal-50/70 dark:from-slate-900 dark:via-teal-950/40 dark:to-slate-900 border border-teal-200 dark:border-teal-500/40 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm dark:shadow-xl">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-teal-100 dark:bg-teal-500/20 border border-teal-200 dark:border-teal-500/50 text-teal-800 dark:text-teal-300 font-mono text-[11px] font-bold flex items-center gap-1.5">
                <CircuitBoard className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>SEMICONDUCTOR & CONTROL // الترانزستورات ومنظومات السيطرة</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
              <span>قسم إلكترونيك السيطرة والخزن</span>
              <span className="text-teal-600 dark:text-teal-400 text-2xl">⚡</span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              حدد المرحلة الدراسية للدخول إلى دوائر الترانزستور، مكبرات الإشارة، خلايا الخزن الرقمية، ومتحكمات الـ PLC المعتمدة وزارياً.
            </p>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end justify-between border-t sm:border-t-0 sm:border-r border-slate-200 dark:border-slate-800 pt-3 sm:pt-0 sm:pr-6 gap-2">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">الكتب المتوفرة للقسم</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-teal-700 dark:text-teal-400">
                {books.filter((b) => b.dept === 'إلكترونيك السيطرة والخزن').length} كتب ومناهج
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>متاح للقراءة والتحميل</span>
            </div>
          </div>
        </div>

        {/* 3 Electronics Stages */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-mono font-bold text-slate-700 dark:text-slate-400 tracking-wider flex items-center gap-2">
              <CircuitBoard className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>SELECT SEMICONDUCTOR STAGE // حدد مرحلة دارات الترانزستور والسيطرة:</span>
            </h3>
            <span className="text-[11px] font-mono text-teal-700 dark:text-teal-400/90">3 TIERS ACTIVE</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {ELECTRONIC_STAGES.map((st, sIdx) => {
              const stageBooks = books.filter(
                (b) => b.dept === 'إلكترونيك السيطرة والخزن' && b.stage === st.id
              );

              return (
                <motion.div
                  key={st.id}
                  id={`electronic-stage-card-${st.id}`}
                  onClick={() => onSelectStage(st.id)}
                  whileHover={{
                    scale: 1.025,
                    y: -4,
                    boxShadow: '0 0 32px rgba(20, 184, 166, 0.25)'
                  }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                  className={`group relative rounded-2xl bg-white dark:bg-slate-900/95 border-2 border-slate-200 dark:border-slate-800 ${st.borderGlow} p-6 flex flex-col justify-between shadow-md dark:shadow-xl cursor-pointer overflow-hidden transition-colors duration-300`}
                >
                  {/* Gate Conduction & Oscilloscope Wave Signal Pulse */}
                  <motion.div
                    className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-teal-500 dark:via-cyan-400 to-transparent pointer-events-none"
                    animate={{
                      x: ['-100%', '100%'],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2.2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.35
                    }}
                  />

                  {/* Semiconductor Junction Field Ambient Pulse */}
                  <motion.div
                    className="absolute -top-12 -right-12 w-36 h-36 bg-teal-500/10 dark:bg-teal-500/20 rounded-full blur-2xl pointer-events-none"
                    animate={{
                      scale: [1, 1.25, 1],
                      opacity: [0.3, 0.65, 0.3]
                    }}
                    transition={{
                      duration: 3.2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.4
                    }}
                  />

                  <div>
                    {/* Top Row: Component Family & Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-mono text-[10px] text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-slate-700 px-2 py-0.5 rounded bg-teal-50/60 dark:bg-slate-950 flex items-center gap-1.5 shadow-xs">
                        <motion.span
                          className="w-1.5 h-1.5 rounded-full bg-teal-500 dark:bg-cyan-400"
                          animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
                          transition={{ duration: 1.3, repeat: Infinity, delay: sIdx * 0.2 }}
                        />
                        <Activity className="w-3 h-3 text-teal-600 dark:text-cyan-400" />
                        <span>{st.componentFamily}</span>
                      </span>
                      {st.badge && (
                        <span className="inline-flex items-center gap-1 bg-emerald-100 dark:bg-emerald-500/20 border border-emerald-200 dark:border-emerald-500/50 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono">
                          <Award className="w-3 h-3" />
                          <span>{st.badge}</span>
                        </span>
                      )}
                    </div>

                    {/* Transistor Pinout & Stage Title with Gate Pulse Ring */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative">
                        <motion.div
                          className="absolute -inset-1 rounded-xl bg-teal-500/15 dark:bg-teal-500/25 blur-xs pointer-events-none"
                          animate={{
                            scale: [1, 1.15, 1],
                            opacity: [0.4, 0.85, 0.4]
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: 'easeInOut',
                            delay: sIdx * 0.3
                          }}
                        />
                        <div className={`relative w-12 h-12 rounded-xl bg-teal-50/80 dark:bg-slate-950 border-2 border-teal-200 dark:border-slate-700 flex items-center justify-center font-mono font-black text-lg ${st.accentColor} group-hover:border-teal-400 group-hover:shadow-md transition-all`}>
                          <CircuitBoard className="w-6 h-6 animate-pulse text-teal-600 dark:text-teal-400" />
                        </div>
                      </div>
                      <div>
                        <h4 className="text-base font-black text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-cyan-200 transition-colors">
                          {st.id}
                        </h4>
                        <span className="font-mono text-[10px] text-teal-700 dark:text-teal-400 block tracking-tight">
                          {st.semiconductorType}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 mb-3 text-[11px] font-mono text-slate-700 dark:text-slate-300">
                      <span className="text-teal-700 dark:text-teal-300 font-bold block mb-0.5">{st.stageTitle}</span>
                      <span className="text-slate-500 dark:text-slate-400 text-[10px]">{st.pinout}</span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                      {st.description}
                    </p>

                    {/* Semiconductor Specs Grid */}
                    <div className="grid grid-cols-3 gap-2 mb-4 p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-[10px]">
                      {st.specs.map((spec, spIdx) => (
                        <div key={spIdx} className="text-center">
                          <span className="text-slate-500 dark:text-slate-500 block text-[9px]">{spec.label}</span>
                          <span className="text-teal-700 dark:text-teal-300 font-bold">{spec.value}</span>
                        </div>
                      ))}
                    </div>

                    {/* Key Topics List */}
                    <div className="space-y-1.5 mb-5 border-t border-slate-200 dark:border-slate-800 pt-3">
                      <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                        مفردات المنهج التخصصي:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {st.topics.map((top, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 flex items-center gap-1 font-mono"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-teal-500 dark:bg-teal-400" />
                            <span>{top}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-mono text-slate-600 dark:text-slate-300">
                      <BookOpen className="w-3.5 h-3.5 text-teal-500 dark:text-teal-400" />
                      <span className="font-bold text-slate-900 dark:text-white">{stageBooks.length}</span>
                      <span className="text-slate-500 dark:text-slate-400">كتب متوفرة</span>
                    </div>

                    <div className={`flex items-center gap-1.5 text-xs font-mono font-bold ${st.accentColor} group-hover:translate-x-[-4px] transition-transform`}>
                      <span>انحياز وتصفح الكتب</span>
                      <ChevronLeft className="w-4 h-4" />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Footer Note */}
        <div className="bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-teal-500 dark:text-teal-400" />
            <span>نظام إلكترونيك السيطرة والخزن مفحوص ومرتبط سحابياً مع مكتبة سومر الإلكترونية.</span>
          </div>
          <span className="text-[11px] text-teal-700 dark:text-teal-400 font-bold">
            SEMICONDUCTOR_LAB // BJT_MOSFET_PLC
          </span>
        </div>
      </div>
    </div>
  );
};
