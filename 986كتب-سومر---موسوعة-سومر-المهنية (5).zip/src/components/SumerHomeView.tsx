import React, { useState } from 'react';
import { Book, DepartmentId, DepartmentItem } from '../types';
import { SumerHeroSection } from './SumerHeroSection';
import { SumerCategoryGrid } from './SumerCategoryGrid';
import { SumerFeaturedBooks } from './SumerFeaturedBooks';
import { Eye, Bookmark, Search, FolderOpen } from 'lucide-react';

interface SumerHomeViewProps {
  books: Book[];
  departments: DepartmentItem[];
  onSelectDept: (dept: DepartmentId) => void;
  onReadBook: (book: Book) => void;
  favoriteIds: string[];
  onToggleFavorite: (bookId: string) => void;
  onViewAllBooks: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenAbout?: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  isAdmin?: boolean;
  onOpenAdmin?: () => void;
  currentUserEmail?: string | null;
  onOpenGoogleAuth?: () => void;
}

export const SumerHomeView: React.FC<SumerHomeViewProps> = ({
  books,
  departments,
  onSelectDept,
  onReadBook,
  favoriteIds,
  onToggleFavorite,
  onViewAllBooks,
  isDarkMode,
  onToggleDarkMode,
  onOpenAbout,
  onRefreshData,
  isRefreshing = false,
  isAdmin = false,
  onOpenAdmin,
  currentUserEmail,
  onOpenGoogleAuth
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Search filtered books
  const searchResults = searchQuery.trim()
    ? books.filter(
        (b) =>
          b.title.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
          b.dept.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
          b.stage.toLowerCase().includes(searchQuery.toLowerCase().trim())
      )
    : [];

  const handleLogoClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col justify-between space-y-2.5 sm:space-y-3.5">
      {/* 1. Hero with Ziggurat & Logo & Search Bar & Top Action Bar */}
      <SumerHeroSection
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onLogoClick={handleLogoClick}
        isDarkMode={isDarkMode}
        onToggleDarkMode={onToggleDarkMode}
        onOpenAbout={onOpenAbout}
        onRefreshData={onRefreshData}
        isRefreshing={isRefreshing}
        isAdmin={isAdmin}
        onOpenAdmin={onOpenAdmin}
        currentUserEmail={currentUserEmail}
        onOpenGoogleAuth={onOpenGoogleAuth}
      />

      {/* If Search is Active, show Instant Search Results (Clean without book cover shape) */}
      {searchQuery.trim() ? (
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
              <span>نتائج البحث عن: "{searchQuery}"</span>
            </h3>
            <span className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400 font-bold">
              {searchResults.length} {searchResults.length > 10 ? 'كتاب' : 'كتب'}
            </span>
          </div>

          {searchResults.length === 0 ? (
            <div className="bg-white/90 dark:bg-[#0d1b34]/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 text-center space-y-2 shadow-xs">
              <FolderOpen className="w-6 h-6 text-slate-400 dark:text-slate-500 mx-auto" />
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                لا توجد كتب مطابقة لبحثك. جرب اسم كتاب أو تخصص آخر.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5 max-h-[50vh] overflow-y-auto pr-1">
              {searchResults.map((book) => {
                const isFav = favoriteIds.includes(book.id);

                return (
                  <div
                    key={book.id}
                    onClick={() => onReadBook(book)}
                    className="bg-white/90 dark:bg-[#0d1b34]/90 hover:bg-slate-50 dark:hover:bg-[#112344] border border-slate-200 dark:border-slate-800 hover:border-amber-400/40 rounded-xl px-3 py-2 flex items-center justify-between gap-2 cursor-pointer group transition-all shadow-xs"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-[9px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-300/40 dark:border-amber-400/20">
                          {book.dept} • {book.stage}
                        </span>
                      </div>
                      <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors truncate">
                        {book.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(book.id);
                        }}
                        className={`p-1 rounded-md ${isFav ? 'text-amber-400' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isFav ? 'fill-amber-400' : ''}`} />
                      </button>

                      <div className="flex items-center gap-1 text-[11px] font-bold text-amber-500 dark:text-amber-400">
                        <Eye className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">فتح</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* 2. Category Grid: ONLY the Departments (Stages removed from home screen) */}
          <SumerCategoryGrid
            books={books}
            departments={departments}
            onSelectDept={onSelectDept}
          />

          {/* 3. "أحدث الإضافات" (Newest books added to app, ONLY book name and details, no book image/shape) */}
          <SumerFeaturedBooks
            books={books}
            onReadBook={onReadBook}
            favoriteIds={favoriteIds}
            onToggleFavorite={onToggleFavorite}
            onViewAll={onViewAllBooks}
            limit={3}
          />

          {/* 4. Subtle Bottom Footer with Dedication */}
          <div className="pt-3 pb-1 flex flex-col items-center justify-center text-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 px-2 border-t border-slate-200/60 dark:border-slate-800/40">
            <span className="font-extrabold text-slate-700 dark:text-slate-300">
              موسوعة سومر المهنية • المناهج والكتب التخصصية
            </span>
            <span className="text-[10.5px] text-slate-500 dark:text-slate-400">
              هذا العمل من قبل الطالب <strong className="text-teal-700 dark:text-teal-400 font-bold">سجاد محمد</strong> وهو إهداء لمدرسة سومر المهنية
            </span>
          </div>
        </>
      )}
    </div>
  );
};
