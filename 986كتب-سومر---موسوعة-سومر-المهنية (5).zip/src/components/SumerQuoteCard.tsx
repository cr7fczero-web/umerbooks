import React from 'react';
import { Lightbulb } from 'lucide-react';
import { ASSETS } from '../lib/assets';

export const SumerQuoteCard: React.FC = () => {
  return (
    <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#fff9eb] via-[#fef4d8] to-[#fceec4] dark:from-[#0d1b34] dark:via-[#0f1f3d] dark:to-[#122240] border-2 border-black dark:border-slate-800 shadow-[0_6px_25px_rgba(0,0,0,0.06),0_2px_8px_rgba(217,119,6,0.15)] dark:shadow-xl dark:shadow-black/30 p-4 sm:p-5 flex items-center justify-between min-h-[90px]">
      {/* Left side: Golden glowing lightbulb icon */}
      <div className="flex items-center gap-3.5 z-10">
        <div className="w-11 h-11 rounded-2xl bg-amber-400/30 dark:bg-amber-500/20 border-2 border-black dark:border-amber-400/30 flex items-center justify-center shrink-0 shadow-md shadow-amber-500/10">
          <Lightbulb className="w-6 h-6 text-amber-600 dark:text-amber-400 animate-pulse [animation-duration:4s]" />
        </div>

        {/* Center Quote text */}
        <div className="space-y-0.5 text-right">
          <p className="text-xs sm:text-sm font-black text-slate-950 dark:text-slate-100 tracking-tight leading-snug">
            "المعرفة هي السلاح الأقوى في عالم يتغير باستمرار"
          </p>
          <p className="text-[11px] font-extrabold text-amber-800 dark:text-amber-400/90">
            موسوعة سومر المهنية
          </p>
        </div>
      </div>

      {/* Right side: Sumerian relief statue illustration with fade mask */}
      <div className="absolute top-0 bottom-0 right-0 w-[30%] sm:w-[25%] overflow-hidden pointer-events-none opacity-40 sm:opacity-55">
        <img
          src={ASSETS.sumerRelief}
          alt="نقش تمثال سومري"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-transparent via-[#fef4d8]/70 dark:via-[#0f1f3d]/60 to-[#fff9eb] dark:to-[#0d1b34]" />
      </div>
    </div>
  );
};
