import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  ExternalLink, 
  Download, 
  Maximize2, 
  Minimize2, 
  AlertCircle, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Printer, 
  FileText 
} from 'lucide-react';
import { Book } from '../types';

interface PdfReaderModalProps {
  book: Book | null;
  onClose: () => void;
}

export const PdfReaderModal: React.FC<PdfReaderModalProps> = ({ book, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(100);
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Sync native browser fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Keyboard navigation: Escape to close/exit, + to zoom in, - to zoom out, 0 to reset zoom
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!book) return;

      if (e.key === 'Escape') {
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        } else {
          onClose();
        }
      } else if ((e.ctrlKey || e.metaKey) && (e.key === '=' || e.key === '+')) {
        e.preventDefault();
        setZoomLevel((prev) => Math.min(prev + 15, 200));
      } else if ((e.ctrlKey || e.metaKey) && e.key === '-') {
        e.preventDefault();
        setZoomLevel((prev) => Math.max(prev - 15, 60));
      } else if ((e.ctrlKey || e.metaKey) && e.key === '0') {
        e.preventDefault();
        setZoomLevel(100);
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        handlePrint();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [book, onClose]);

  // Reset zoom whenever a new book is opened
  useEffect(() => {
    setZoomLevel(100);
  }, [book]);

  if (!book) return null;

  // Toggle fullscreen using Native Fullscreen API with fallback
  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        if (containerRef.current?.requestFullscreen) {
          await containerRef.current.requestFullscreen();
          setIsFullscreen(true);
        } else {
          setIsFullscreen(!isFullscreen);
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
          setIsFullscreen(false);
        } else {
          setIsFullscreen(false);
        }
      }
    } catch {
      setIsFullscreen(!isFullscreen);
    }
  };

  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 15, 200));
  };

  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 15, 60));
  };

  const handleResetZoom = () => {
    setZoomLevel(100);
  };

  const handlePrint = () => {
    try {
      if (iframeRef.current?.contentWindow) {
        iframeRef.current.contentWindow.focus();
        iframeRef.current.contentWindow.print();
        return;
      }
    } catch {
      // Cross-origin restriction: open in clean popup to print
    }

    const printWindow = window.open(book.url, '_blank');
    if (printWindow) {
      printWindow.focus();
      printWindow.addEventListener('load', () => {
        try {
          printWindow.print();
        } catch {
          // If browser blocks auto-print, user can use browser's native print
        }
      });
    }
  };

  // Generate URL with PDF display flags (Google Drive works seamlessly in iframes with /preview)
  const getEmbedUrl = (rawUrl: string): string => {
    if (!rawUrl) return '';
    if (rawUrl.includes('drive.google.com')) {
      if (rawUrl.includes('/view')) {
        return rawUrl.replace(/\/view(\?.*)?$/, '/preview');
      }
      if (!rawUrl.includes('/preview')) {
        return `${rawUrl.replace(/\/+$/, '')}/preview`;
      }
      return rawUrl;
    }
    return `${rawUrl}#toolbar=1&navpanes=1&zoom=${zoomLevel}`;
  };

  const pdfEmbedUrl = getEmbedUrl(book.url);

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isFullscreen) {
          onClose();
        }
      }}
    >
      <div
        ref={containerRef}
        className={`bg-white dark:bg-slate-900 rounded-2xl flex flex-col overflow-hidden shadow-2xl transition-all duration-300 border border-slate-700/30 ${
          isFullscreen
            ? 'fixed inset-0 w-screen h-screen rounded-none z-[60]'
            : 'w-full max-w-6xl h-[92vh] sm:h-[88vh]'
        }`}
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-3 sm:px-5 py-3 flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-800 shadow-sm shrink-0">
          
          {/* Book Identity & Badges */}
          <div className="flex items-center gap-2.5 min-w-0 max-w-full sm:max-w-md">
            <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="truncate">
              <h3 className="text-xs sm:text-sm font-black truncate text-white leading-tight">
                {book.title}
              </h3>
              <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1.5 mt-0.5">
                <span className="text-teal-400 font-bold">{book.dept}</span>
                <span>•</span>
                <span>{book.stage}</span>
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center flex-wrap gap-1.5 shrink-0">
            {/* Zoom Controls */}
            <div className="flex items-center bg-slate-800/90 rounded-xl p-0.5 border border-slate-700/80 shadow-xs">
              <button
                type="button"
                onClick={handleZoomOut}
                disabled={zoomLevel <= 60}
                className="p-1.5 hover:bg-slate-700 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:bg-transparent rounded-lg transition-colors cursor-pointer"
                title="تصغير العرض (Ctrl + -)"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={handleResetZoom}
                className="px-2 py-1 text-[11px] font-mono font-bold text-slate-200 hover:text-teal-300 transition-colors cursor-pointer"
                title="إعادة التكبير للوضع الافتراضي 100% (Ctrl + 0)"
              >
                {zoomLevel}%
              </button>

              <button
                type="button"
                onClick={handleZoomIn}
                disabled={zoomLevel >= 200}
                className="p-1.5 hover:bg-slate-700 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:bg-transparent rounded-lg transition-colors cursor-pointer"
                title="تكبير العرض (Ctrl + +)"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>

              {zoomLevel !== 100 && (
                <button
                  type="button"
                  onClick={handleResetZoom}
                  className="p-1.5 hover:bg-slate-700 text-teal-400 rounded-lg transition-colors cursor-pointer border-r border-slate-700"
                  title="استعادة الحجم الأصلي"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* Direct Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="p-2 sm:px-3 sm:py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-slate-700/70 hover:border-slate-600 cursor-pointer shadow-xs"
              title="طباعة الملف مباشرة (Ctrl + P)"
            >
              <Printer className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">طباعة</span>
            </button>

            {/* Download button */}
            <a
              href={book.url}
              download={`${book.title}.pdf`}
              className="p-2 sm:px-3 sm:py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-slate-700/70 hover:border-slate-600 cursor-pointer shadow-xs"
              title="تحميل الكتاب إلى جهازك"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden md:inline">تحميل</span>
            </a>

            {/* Open in new tab */}
            <a
              href={book.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 sm:px-3 sm:py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-slate-700/70 hover:border-slate-600 cursor-pointer shadow-xs"
              title="فتح الملف في علامة تبويب مستقلة"
            >
              <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden lg:inline">نافذة جديدة</span>
            </a>

            {/* Fullscreen toggle */}
            <button
              type="button"
              onClick={toggleFullscreen}
              className="p-2 sm:px-2.5 sm:py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1 border border-slate-700/70 hover:border-slate-600 cursor-pointer shadow-xs"
              title={isFullscreen ? 'تصغير النافذة (Esc)' : 'عرض بملء الشاشة'}
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5 text-yellow-400" />
                  <span className="hidden sm:inline">إنهاء الملء</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-3.5 h-3.5 text-yellow-400" />
                  <span className="hidden sm:inline">ملء الشاشة</span>
                </>
              )}
            </button>

            {/* Close button */}
            <button
              id="close-pdf-modal-btn"
              type="button"
              onClick={onClose}
              className="p-2 sm:px-3 sm:py-1.5 bg-rose-600/90 hover:bg-rose-600 text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1 cursor-pointer shadow-xs ml-1"
              title="إغلاق القارئ (Esc)"
            >
              <X className="w-4 h-4" />
              <span className="hidden sm:inline">إغلاق</span>
            </button>
          </div>
        </div>

        {/* Fallback Banner for restricted browsers/embeds */}
        <div className="bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200/80 dark:border-amber-900/60 px-4 py-2 text-[11px] text-amber-900 dark:text-amber-300 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2 truncate">
            <AlertCircle className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400 shrink-0" />
            <span className="truncate">إذا لم يظهر المستند تلقائياً أو حظر المتصفح الإطار:</span>
          </div>
          <a
            href={book.url}
            target="_blank"
            rel="noopener noreferrer"
            className="font-bold underline text-amber-950 dark:text-amber-200 hover:text-teal-800 dark:hover:text-teal-400 shrink-0"
          >
            فتح الملف بالرابط المباشر ↗
          </a>
        </div>

        {/* Iframe View with Zoom & Scroll Wrapper */}
        <div className="flex-1 bg-slate-900 relative overflow-auto flex items-start justify-center p-0">
          <div
            className="w-full h-full transition-transform duration-200 origin-top flex items-center justify-center"
            style={{
              transform: zoomLevel !== 100 ? `scale(${zoomLevel / 100})` : undefined,
              transformOrigin: 'top center',
              width: zoomLevel > 100 ? `${zoomLevel}%` : '100%',
              height: zoomLevel > 100 ? `${zoomLevel}%` : '100%'
            }}
          >
            <iframe
              ref={iframeRef}
              src={pdfEmbedUrl}
              title={book.title}
              className="w-full h-full border-0 bg-white"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
