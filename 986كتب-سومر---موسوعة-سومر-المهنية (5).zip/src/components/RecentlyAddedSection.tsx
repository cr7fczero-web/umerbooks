import React from 'react';
import { Book } from '../types';
import { Sparkles, BookOpen, Heart, Eye, ArrowLeft, Download, ShieldCheck, Zap, Laptop, Cpu } from 'lucide-react';

interface RecentlyAddedSectionProps {
  books: Book[];
  onReadBook: (book: Book) => void;
  favoriteIds: string[];
  onToggleFavorite: (bookId: string) => void;
  title?: string;
  subTitle?: string;
  limit?: number;
  emptyMessage?: string;
}

export const RecentlyAddedSection: React.FC<RecentlyAddedSectionProps> = ({
  books,
  onReadBook,
  favoriteIds,
  onToggleFavorite,
  title = 'آخر الكتب المضافة',
  subTitle = 'أحدث المناهج والكتب المضافة حديثاً للمكتبة',
  limit = 6,
  emptyMessage = 'لم يتم إضافة كتب جديدة مؤخراً'
}) => {
  // Sort books by uploadedAt descending or by array position
  const sortedBooks = [...books].sort((a, b) => {
    const timeA = a.uploadedAt ? new Date(a.uploadedAt).getTime() : 0;
    const timeB = b.uploadedAt ? new Date(b.uploadedAt).getTime() : 0;
    return timeB - timeA;
  }).slice(0, limit);

  if (sortedBooks.length === 0) {
    return null;
  }

  const getDeptColor = (dept: string) => {
    switch (dept) {
      case 'الأمن السيبراني':
        return {
          bg: 'bg-teal-50 dark:bg-teal-950/60',
          border: 'border-teal-200 dark:border-teal-800',
          text: 'text-teal-700 dark:text-teal-300',
          icon: ShieldCheck
        };
      case 'الكهرباء':
        return {
          bg: 'bg-amber-50 dark:bg-amber-950/60',
          border: 'border-amber-200 dark:border-amber-800',
          text: 'text-amber-700 dark:text-amber-300',
          icon: Zap
        };
      case 'الحاسبات':
        return {
          bg: 'bg-indigo-50 dark:bg-indigo-950/60',
          border: 'border-indigo-200 dark:border-indigo-800',
          text: 'text-indigo-700 dark:text-indigo-300',
          icon: Laptop
        };
      default:
        return {
          bg: 'bg-sky-50 dark:bg-sky-950/60',
          border: 'border-sky-200 dark:border-sky-800',
          text: 'text-sky-700 dark:text-sky-300',
          icon: Cpu
        };
    }
  };

  const handleDownload = (e: React.MouseEvent, book: Book) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = book.url;
    link.download = `${book.title}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-2.5">
      {/* Section Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-400 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5 leading-tight">
              <span>{title}</span>
              <span className="text-[10px] font-bold bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 px-1.5 py-0.5 rounded-md">
                جديد
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
              {subTitle}
            </p>
          </div>
        </div>
        <span className="text-[11px] font-mono font-bold text-slate-400 dark:text-slate-500">
          {sortedBooks.length} كتب
        </span>
      </div>

      {/* Horizontal Scroll on Mobile / Compact Grid on Desktop */}
      <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-3 gap-3 overflow-x-auto pb-2 pt-0.5 sm:overflow-visible no-scrollbar snap-x snap-mandatory">
        {sortedBooks.map((book) => {
          const isFav = favoriteIds.includes(book.id);
          const deptMeta = getDeptColor(book.dept);
          const DeptIcon = deptMeta.icon;

          return (
            <div
              key={book.id}
              onClick={() => onReadBook(book)}
              className="min-w-[240px] sm:min-w-0 max-w-[260px] sm:max-w-none flex-shrink-0 snap-start bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-2xl p-3 shadow-xs hover:shadow-md transition-all hover:border-teal-400/80 group cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Top badges & heart */}
                <div className="flex items-center justify-between gap-1.5 mb-2">
                  <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-lg border ${deptMeta.bg} ${deptMeta.border} ${deptMeta.text}`}>
                    <DeptIcon className="w-2.5 h-2.5" />
                    <span className="truncate max-w-[90px]">{book.dept}</span>
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(book.id);
                    }}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      isFav 
                        ? 'text-rose-500 bg-rose-50 dark:bg-rose-950/70' 
                        : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                    title={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                  >
                    <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500' : ''}`} />
                  </button>
                </div>

                {/* Title */}
                <h4 className="text-xs sm:text-sm font-black text-slate-800 dark:text-slate-100 group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors line-clamp-2 leading-snug mb-1.5">
                  {book.title}
                </h4>

                <div className="flex items-center gap-1.5 text-[10px] font-medium text-slate-500 dark:text-slate-400">
                  <span className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                    {book.stage}
                  </span>
                  {book.fileSize && (
                    <span>{(book.fileSize / (1024 * 1024)).toFixed(1)} ميغابايت</span>
                  )}
                </div>
              </div>

              {/* Bottom Read / Download Button */}
              <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <button
                  type="button"
                  className="inline-flex items-center gap-1 text-teal-700 dark:text-teal-400 font-black text-[11px] group-hover:translate-x-[-2px] transition-transform"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>فتح ومطالعة</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => handleDownload(e, book)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                  title="تحميل الكتاب"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
