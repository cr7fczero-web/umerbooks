import React, { useState } from 'react';
import { 
  User, 
  LogIn, 
  LogOut, 
  Check, 
  Edit3, 
  Sparkles, 
  GraduationCap, 
  ShieldCheck, 
  Heart, 
  History,
  Calendar,
  Layers,
  ArrowRight,
  AlertCircle,
  KeyRound,
  Eye,
  EyeOff,
  UserPlus,
  Lock,
  Mail
} from 'lucide-react';
import { DepartmentItem } from '../types';
import { 
  LocalUserAccount, 
  loginLocalUser, 
  registerLocalUser, 
  updateLocalUserProfile, 
  logoutLocalUser,
  DEFAULT_ADMIN_PIN
} from '../lib/userAuth';

interface AccountViewProps {
  currentUser: LocalUserAccount | null;
  isAdmin: boolean;
  favoritesCount: number;
  recentCount: number;
  departments: DepartmentItem[];
  onGoToHome: () => void;
  onUserAuthChange: (user: LocalUserAccount | null) => void;
  onGoToAdminTab?: () => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  currentUser,
  isAdmin,
  favoritesCount,
  recentCount,
  departments,
  onGoToHome,
  onUserAuthChange,
  onGoToAdminTab
}) => {
  // Mode: 'login' | 'register'
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regDept, setRegDept] = useState(departments[0]?.name || 'الأمن السيبراني');
  const [regStage, setRegStage] = useState('المرحلة الأولى');
  const [regError, setRegError] = useState<string | null>(null);

  // Edit profile state (for logged-in user)
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editDept, setEditDept] = useState(currentUser?.department || departments[0]?.name || 'الأمن السيبراني');
  const [editStage, setEditStage] = useState(currentUser?.stage || 'المرحلة الأولى');
  const [editPassword, setEditPassword] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Handle Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const res = loginLocalUser(loginEmail, loginPassword);
    if (!res.success || !res.user) {
      setLoginError(res.error || 'فشل تسجيل الدخول، يرجى التأكد من البيانات');
      return;
    }

    onUserAuthChange(res.user);
    setEditName(res.user.name);
    setEditDept(res.user.department || departments[0]?.name || 'الأمن السيبراني');
    setEditStage(res.user.stage || 'المرحلة الأولى');

    // If logging in as Admin (fhsfczero@gmail.com), immediately open admin panel!
    if (res.user.isAdmin && onGoToAdminTab) {
      onGoToAdminTab();
    }
  };

  // Handle Register
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (regPassword !== regConfirmPassword) {
      setRegError('كلمة المرور وتأكيدها غير متطابقين');
      return;
    }

    const res = registerLocalUser(regName, regEmail, regPassword, regDept, regStage);
    if (!res.success || !res.user) {
      setRegError(res.error || 'تعذر إنشاء الحساب');
      return;
    }

    onUserAuthChange(res.user);
    setEditName(res.user.name);
    setEditDept(res.user.department);
    setEditStage(res.user.stage);
  };

  // Handle Save Profile
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setSaveError(null);

    const updates: Partial<LocalUserAccount> = {
      name: editName.trim() || currentUser.name,
      department: editDept,
      stage: editStage
    };

    if (editPassword.trim()) {
      if (editPassword.trim().length < 4) {
        setSaveError('كلمة المرور الجديدة يجب أن تكون 4 أحرف أو أرقام على الأقل');
        return;
      }
      updates.password = editPassword.trim();
    }

    const res = updateLocalUserProfile(currentUser.email, updates);
    if (!res.success || !res.user) {
      setSaveError(res.error || 'تعذر حفظ التعديلات');
      return;
    }

    onUserAuthChange(res.user);
    setEditPassword('');
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Handle Logout
  const handleLogout = () => {
    logoutLocalUser();
    onUserAuthChange(null);
  };

  return (
    <div className="space-y-4 sm:space-y-5 animate-in fade-in duration-200">
      {/* Top Navigation */}
      <div className="flex items-center justify-between px-1">
        <button
          onClick={onGoToHome}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 border border-black/20 dark:border-slate-700 text-xs font-black transition-colors cursor-pointer"
        >
          <ArrowRight className="w-3.5 h-3.5" />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-sm sm:text-base font-black text-slate-950 dark:text-white flex items-center gap-2">
          <User className="w-4 h-4 text-amber-500" />
          <span>الملف الشخصي والحساب</span>
        </h2>
      </div>

      {!currentUser ? (
        /* State 1: Not Logged In -> Local Sign In or Register Tabs */
        <div className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-5">
          {/* Header */}
          <div className="text-center space-y-1">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 via-yellow-400 to-amber-500 text-black border-2 border-black dark:border-transparent flex items-center justify-center mx-auto shadow-md shadow-amber-500/20 mb-3">
              <GraduationCap className="w-8 h-8 text-black" />
            </div>
            <h3 className="text-base sm:text-lg font-black text-slate-950 dark:text-white">
              نظام حسابات كتب سومر المهنية
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 font-bold max-w-sm mx-auto">
              سجّل دخولك أو أنشئ حسابك لحفظ كتبك المفضلة ومتابعة قراءاتك.
            </p>
          </div>

          {/* Mode Switcher Buttons */}
          <div className="grid grid-cols-2 p-1 bg-amber-100/70 dark:bg-slate-800 rounded-2xl border-2 border-black/20 dark:border-slate-700 max-w-sm mx-auto">
            <button
              type="button"
              onClick={() => {
                setAuthMode('login');
                setLoginError(null);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                authMode === 'login'
                  ? 'bg-white dark:bg-slate-900 text-black dark:text-white shadow-xs border border-black/20 dark:border-slate-600'
                  : 'text-slate-600 dark:text-slate-400 hover:text-black dark:hover:text-white'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>تسجيل الدخول</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setAuthMode('register');
                setRegError(null);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                authMode === 'register'
                  ? 'bg-white dark:bg-slate-900 text-black dark:text-white shadow-xs border border-black/20 dark:border-slate-600'
                  : 'text-slate-600 dark:text-slate-400 hover:text-black dark:hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>إنشاء حساب جديد</span>
            </button>
          </div>

          {/* TAB 1: LOGIN FORM */}
          {authMode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4 max-w-sm mx-auto text-right">
              {loginError && (
                <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-300 dark:border-red-900 rounded-xl text-xs text-red-700 dark:text-red-300 font-bold flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{loginError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                  البريد الإلكتروني:
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="student@example.com"
                    className="w-full pl-3 pr-9 py-2.5 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none dir-ltr text-right"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                  كلمة المرور:
                </label>
                <div className="relative">
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2.5 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none dir-ltr text-right"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute left-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-500 hover:to-yellow-500 text-black border-2 border-black dark:border-transparent rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>تسجيل الدخول إلى حسابي</span>
              </button>
            </form>
          ) : (
            /* TAB 2: REGISTER FORM */
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5 max-w-md mx-auto text-right">
              {regError && (
                <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-300 dark:border-red-900 rounded-xl text-xs text-red-700 dark:text-red-300 font-bold flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{regError}</span>
                </div>
              )}

              {/* Name */}
              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                  الاسم الكامل للطالب:
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="مثال: علي حسن كاظم"
                    className="w-full pl-3 pr-9 py-2.5 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                  البريد الإلكتروني:
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="student@example.com"
                    className="w-full pl-3 pr-9 py-2.5 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none dir-ltr text-right"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
                </div>
              </div>

              {/* Department */}
              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                  القسم المهني:
                </label>
                <select
                  value={regDept}
                  onChange={(e) => setRegDept(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none"
                >
                  {departments.map((dept) => (
                    <option key={dept.id || dept.name} value={dept.name}>
                      {dept.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Stage */}
              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                  المرحلة الدراسية:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['المرحلة الأولى', 'المرحلة الثانية', 'المرحلة الثالثة'] as const).map((stg) => (
                    <button
                      key={stg}
                      type="button"
                      onClick={() => setRegStage(stg)}
                      className={`py-2 px-1 text-center rounded-xl text-xs font-bold border-2 transition-all cursor-pointer ${
                        regStage === stg
                          ? 'bg-amber-400 dark:bg-amber-500/20 text-black dark:text-amber-300 border-black dark:border-amber-400 shadow-xs'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-black/20 dark:border-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {stg}
                    </button>
                  ))}
                </div>
              </div>

              {/* Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                    كلمة المرور:
                  </label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-8 pr-8 py-2 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs font-bold text-slate-950 dark:text-white outline-none dir-ltr text-right"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5"
                    >
                      {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1">
                    تأكيد كلمة المرور:
                  </label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      required
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-8 pr-8 py-2 bg-white dark:bg-slate-800 border-2 border-black/30 dark:border-slate-700 focus:border-amber-500 rounded-xl text-xs font-bold text-slate-950 dark:text-white outline-none dir-ltr text-right"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white border-2 border-black dark:border-transparent rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer mt-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>إنشاء الحساب وبدء الاستخدام</span>
              </button>
            </form>
          )}
        </div>
      ) : (
        /* State 2: Logged In -> Edit Profile, Statistics & Admin Controls */
        <div className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-5">
          {/* Avatar and Info Header */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 pb-4 border-b border-black/10 dark:border-slate-800">
            <div className="relative shrink-0">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-400 via-yellow-400 to-amber-500 text-black border-2 border-black dark:border-transparent flex items-center justify-center font-black text-3xl shadow-md">
                {(currentUser.name || currentUser.email || 'U')[0].toUpperCase()}
              </div>
              {currentUser.isAdmin && (
                <span className="absolute -bottom-1 -right-1 bg-amber-500 text-black p-1 rounded-lg border border-black shadow-xs" title="المسؤول">
                  <ShieldCheck className="w-4 h-4" />
                </span>
              )}
            </div>

            <div className="flex-1 text-center sm:text-right space-y-1">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-950 dark:text-white">
                    {currentUser.name}
                  </h3>
                  <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                    {currentUser.email}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleLogout}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 rounded-xl text-xs font-bold transition-colors cursor-pointer self-center sm:self-start"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>تسجيل الخروج</span>
                </button>
              </div>

              {currentUser.isAdmin && (
                <div className="flex flex-wrap items-center gap-2 mt-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-100 dark:bg-amber-950/70 border border-amber-400 text-amber-950 dark:text-amber-300 text-xs font-black shadow-2xs">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>👑 حساب المسؤول والمطور مفعل</span>
                  </div>
                  {onGoToAdminTab && (
                    <button
                      type="button"
                      onClick={onGoToAdminTab}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition-all cursor-pointer shadow-xs"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>فتح لوحة الإدارة من الشريط</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Quick Statistics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-right">
            <div className="p-3 bg-amber-50/70 dark:bg-slate-800/60 rounded-2xl border border-black/10 dark:border-slate-800 flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <Heart className="w-4 h-4 fill-rose-500" />
              </div>
              <div>
                <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400">المفضلة</span>
                <span className="text-xs font-black text-slate-950 dark:text-white">{favoritesCount} كتب</span>
              </div>
            </div>

            <div className="p-3 bg-amber-50/70 dark:bg-slate-800/60 rounded-2xl border border-black/10 dark:border-slate-800 flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-cyan-100 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
                <History className="w-4 h-4" />
              </div>
              <div>
                <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400">آخر المشاهدة</span>
                <span className="text-xs font-black text-slate-950 dark:text-white">{recentCount} كتب</span>
              </div>
            </div>

            <div className="col-span-2 sm:col-span-1 p-3 bg-amber-50/70 dark:bg-slate-800/60 rounded-2xl border border-black/10 dark:border-slate-800 flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0">
                <GraduationCap className="w-4 h-4" />
              </div>
              <div>
                <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400">المدرسة</span>
                <span className="text-xs font-black text-slate-950 dark:text-white">سومر المهنية</span>
              </div>
            </div>
          </div>

          {/* Edit Form */}
          <form onSubmit={handleSaveProfile} className="space-y-4 text-right">
            <h4 className="text-xs sm:text-sm font-black text-slate-950 dark:text-white flex items-center gap-1.5">
              <Edit3 className="w-4 h-4 text-amber-500" />
              <span>تعديل المعلومات الدراسية والاسم</span>
            </h4>

            {saveError && (
              <div className="p-2.5 bg-red-50 dark:bg-red-950/50 border border-red-300 dark:border-red-900 rounded-xl text-xs text-red-700 dark:text-red-300 font-bold flex items-center gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{saveError}</span>
              </div>
            )}

            {/* Display Name Input */}
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1.5">
                الاسم الكامل:
              </label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="أدخل اسمك..."
                className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-800 border-2 border-black dark:border-slate-700 focus:border-amber-500 dark:focus:border-amber-400 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none transition-all"
              />
            </div>

            {/* Department Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1.5">
                القسم المهني الخاص بك:
              </label>
              <select
                value={editDept}
                onChange={(e) => setEditDept(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-800 border-2 border-black dark:border-slate-700 focus:border-amber-500 dark:focus:border-amber-400 rounded-xl text-xs sm:text-sm font-bold text-slate-950 dark:text-white outline-none transition-all"
              >
                {departments.map((dept) => (
                  <option key={dept.id || dept.name} value={dept.name}>
                    {dept.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Stage Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1.5">
                المرحلة الدراسية:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['المرحلة الأولى', 'المرحلة الثانية', 'المرحلة الثالثة'] as const).map((stg) => (
                  <button
                    key={stg}
                    type="button"
                    onClick={() => setEditStage(stg)}
                    className={`py-2 px-1 text-center rounded-xl text-xs font-bold border-2 transition-all cursor-pointer ${
                      editStage === stg
                        ? 'bg-amber-400 dark:bg-amber-500/20 text-black dark:text-amber-300 border-black dark:border-amber-400 shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-black/20 dark:border-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {stg}
                  </button>
                ))}
              </div>
            </div>

            {/* Password Change (Optional) */}
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-300 mb-1.5">
                تغيير كلمة المرور (اتركه فارغاً إذا كنت لا ترغب بتغييرها):
              </label>
              <input
                type="password"
                value={editPassword}
                onChange={(e) => setEditPassword(e.target.value)}
                placeholder="كلمة مرور جديدة..."
                className="w-full px-3.5 py-2 bg-white dark:bg-slate-800 border-2 border-black dark:border-slate-700 focus:border-amber-500 dark:focus:border-amber-400 rounded-xl text-xs font-bold text-slate-950 dark:text-white outline-none transition-all dir-ltr text-right"
              />
            </div>

            {/* Save Success Alert */}
            {saveSuccess && (
              <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-400 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
                <Check className="w-4 h-4 shrink-0" />
                <span>تم حفظ التعديلات بنجاح!</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-500 hover:to-yellow-500 text-black border-2 border-black dark:border-transparent rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>حفظ التعديلات</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
