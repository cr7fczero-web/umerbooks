import React, { useState } from 'react';
import { 
  CloudUpload, 
  FileText, 
  Link as LinkIcon, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  UploadCloud, 
  Globe2, 
  Layers, 
  Server,
  Loader2,
  KeyRound,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Cloud,
  RefreshCw,
  PlusCircle,
  Trash2,
  FolderPlus,
  BookOpen,
  ArrowRight,
  LogOut,
  Search,
  ExternalLink
} from 'lucide-react';
import { Book, DepartmentId, StageId, DepartmentItem } from '../types';
import { apiUrl, isStaticHost, savePdfToIndexedDB } from '../lib/storage';
import { 
  DEPARTMENT_ICON_OPTIONS, 
  COLOR_THEMES, 
  getDepartmentIcon, 
  getColorThemeClasses,
  DEFAULT_DEPARTMENTS 
} from '../lib/departments';
import { AdminStatsDashboard } from './AdminStatsDashboard';

interface AdminPanelProps {
  adminPin: string;
  isCloudConnected?: boolean;
  onPinChanged: (newPin: string) => void;
  onAddBook: (newBook: {
    title: string;
    dept: string;
    stage: string;
    url: string;
    fileName?: string;
    fileSize?: number;
  }) => Promise<boolean>;
  onExportBackup: () => void;
  onImportBackup: (books: Book[]) => Promise<boolean>;
  onSyncAllToCloud?: () => Promise<boolean>;
  totalBooksCount: number;
  books?: Book[];
  departments?: DepartmentItem[];
  onAddDepartment?: (dept: {
    name: string;
    title?: string;
    description?: string;
    iconName: string;
    colorTheme?: string;
  }) => Promise<boolean>;
  onDeleteDepartment?: (deptId: string) => Promise<boolean>;
  onDeleteBook?: (bookId: string) => Promise<boolean>;
  onExitAdmin?: () => void;
  currentUserEmail?: string | null;
  onSignOut?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  adminPin,
  isCloudConnected = true,
  onPinChanged,
  onAddBook,
  onExportBackup,
  onImportBackup,
  onSyncAllToCloud,
  totalBooksCount,
  books = [],
  departments = DEFAULT_DEPARTMENTS,
  onAddDepartment,
  onDeleteDepartment,
  onDeleteBook,
  onExitAdmin,
  currentUserEmail,
  onSignOut
}) => {
  const [title, setTitle] = useState('');
  const [dept, setDept] = useState<DepartmentId>(departments[0]?.name || 'إلكترونيك السيطرة والخزن');
  const [stage, setStage] = useState<StageId>('المرحلة الأولى');
  const [inputMode, setInputMode] = useState<'upload' | 'url'>('url');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [directUrl, setDirectUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSyncingCloud, setIsSyncingCloud] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);
  const [uploadStatusText, setUploadStatusText] = useState<string | null>(null);

  // New Department Form State
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptDesc, setNewDeptDesc] = useState('');
  const [newDeptIcon, setNewDeptIcon] = useState('Stethoscope');
  const [newDeptColor, setNewDeptColor] = useState('emerald');
  const [isSubmittingDept, setIsSubmittingDept] = useState(false);
  const [deptSuccessMsg, setDeptSuccessMsg] = useState<string | null>(null);
  const [deptErrorMsg, setDeptErrorMsg] = useState<string | null>(null);
  const [deletingDeptId, setDeletingDeptId] = useState<string | null>(null);
  const [deletingBookId, setDeletingBookId] = useState<string | null>(null);
  const [bookToDelete, setBookToDelete] = useState<{ id: string; title: string } | null>(null);
  const [activeAdminTab, setActiveAdminTab] = useState<'books' | 'departments' | 'all-books' | 'stats' | 'settings'>('books');
  const [manageBooksSearch, setManageBooksSearch] = useState('');

  // Change PIN state
  const [showPinChange, setShowPinChange] = useState(false);
  const [newPinValue, setNewPinValue] = useState('');
  const [pinChangeLoading, setPinChangeLoading] = useState(false);
  const [pinChangeMsg, setPinChangeMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChangePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPinValue.trim() || newPinValue.trim().length < 4) {
      setPinChangeMsg({ type: 'error', text: 'يجب أن يتكون رمز الحماية الجديد من 4 خانات على الأقل.' });
      return;
    }

    setPinChangeLoading(true);
    setPinChangeMsg(null);

    const effectivePin = adminPin || 
      sessionStorage.getItem('sumer_admin_pin') || 
      localStorage.getItem('sumer_admin_pin') || 
      'devsomr11';

    try {
      const res = await fetch(apiUrl(`/api/admin/change-pin?adminPin=${encodeURIComponent(effectivePin)}`), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-pin': effectivePin
        },
        body: JSON.stringify({ newPin: newPinValue.trim(), adminPin: effectivePin })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setPinChangeMsg({ type: 'success', text: 'تم تغيير رمز الحماية بنجاح! احفظ الرمز الجديد لدخولك القادم.' });
        onPinChanged(newPinValue.trim());
        setNewPinValue('');
      } else {
        setPinChangeMsg({ type: 'error', text: data.error || 'تعذر تغيير رمز الحماية.' });
      }
    } catch {
      setPinChangeMsg({ type: 'error', text: 'حدث خطأ في الاتصال بالخادم.' });
    } finally {
      setPinChangeLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
        setErrorMessage('يرجى اختيار ملف بصيغة PDF فقط.');
        setSelectedFile(null);
        return;
      }
      setSelectedFile(file);
      setErrorMessage(null);
    }
  };

  // Helper to normalize Google Drive / external links
  const normalizeUrl = (url: string) => {
    const trimmed = url.trim();
    // Convert Google Drive share link to preview link for clean iframe embedding
    const driveMatch = trimmed.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (driveMatch && driveMatch[1]) {
      return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
    }
    return trimmed;
  };

  const uploadChunkWithRetry = async (formData: FormData, retries = 2): Promise<any> => {
    const effectivePin = adminPin || 
      sessionStorage.getItem('sumer_admin_pin') || 
      localStorage.getItem('sumer_admin_pin') || 
      'devsomr11';

    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const res = await fetch(apiUrl(`/api/upload/chunk?adminPin=${encodeURIComponent(effectivePin)}`), {
          method: 'POST',
          headers: {
            'x-admin-pin': effectivePin
          },
          body: formData
        });

        if (res.ok) {
          return await res.json();
        }

        // Detect 404 (e.g. Netlify static hosting where upload endpoint does not exist)
        if (res.status === 404) {
          return { isStaticHost404: true };
        }

        const errData = await res.json().catch(() => ({}));
        if (attempt === retries) {
          throw new Error(errData.error || `تعذر رفع جزء من الملف (رمز الاستجابة: ${res.status})`);
        }
      } catch (err: any) {
        if (err.name === 'TypeError' || err.message?.includes('Failed to fetch')) {
          if (attempt === retries) {
            return { isStaticHost404: true };
          }
        }
        if (attempt === retries) throw err;
        await new Promise((r) => setTimeout(r, 600 * attempt));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setUploadProgress(null);
    setUploadPercent(null);
    setUploadStatusText(null);

    if (!title.trim()) {
      setErrorMessage('يرجى إدخال اسم الكتاب.');
      return;
    }

    setIsSubmitting(true);

    try {
      let finalUrl = '';
      let uploadedFileName = '';
      let uploadedFileSize = 0;
      let isLocalFallback = false;

      if (inputMode === 'upload') {
        if (!selectedFile) {
          setErrorMessage('يرجى اختيار ملف PDF لرفعه أو التبديل لوضع الرابط المباشر.');
          setIsSubmitting(false);
          return;
        }

        if (isStaticHost()) {
          // Client is running on Netlify / static host: directly save in client IndexedDB storage!
          setUploadPercent(40);
          setUploadStatusText('تم تفعيل التخزين الذكي (بيئة Netlify)... جارٍ حفظ الكتاب في ذاكرة جهازك...');
          const localBookId = `local_pdf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          finalUrl = await savePdfToIndexedDB(localBookId, selectedFile, selectedFile.name);
          uploadedFileName = selectedFile.name;
          uploadedFileSize = selectedFile.size;
          setUploadPercent(100);
          isLocalFallback = true;
        } else {
          // Chunked upload: 1.5MB per chunk (fast, bypasses Cloud Run/Nginx 32MB limits, shows real-time progress)
          const CHUNK_SIZE = 1.5 * 1024 * 1024;
          const totalChunks = Math.ceil(selectedFile.size / CHUNK_SIZE);
          const uploadId = `upl_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
          let lastResponse: any = null;

          setUploadPercent(0);
          setUploadStatusText(`بدء تجزئة ورفع الكتاب (${(selectedFile.size / (1024 * 1024)).toFixed(1)} ميغابايت)...`);

          for (let i = 0; i < totalChunks; i++) {
            const start = i * CHUNK_SIZE;
            const end = Math.min(selectedFile.size, start + CHUNK_SIZE);
            const chunkBlob = selectedFile.slice(start, end);

            const effectivePin = adminPin || 
              sessionStorage.getItem('sumer_admin_pin') || 
              localStorage.getItem('sumer_admin_pin') || 
              'devsomr11';

            const chunkFormData = new FormData();
            chunkFormData.append('adminPin', effectivePin);
            chunkFormData.append('uploadId', uploadId);
            chunkFormData.append('chunkIndex', String(i));
            chunkFormData.append('totalChunks', String(totalChunks));
            chunkFormData.append('fileName', selectedFile.name);
            chunkFormData.append('totalSize', String(selectedFile.size));
            chunkFormData.append('chunk', chunkBlob, selectedFile.name);

            const currentMB = (end / (1024 * 1024)).toFixed(1);
            const totalMB = (selectedFile.size / (1024 * 1024)).toFixed(1);
            const percent = Math.round(((i + 1) / totalChunks) * 100);

            setUploadPercent(percent);
            setUploadStatusText(`جارٍ الرفع السريع: ${percent}% (تم رفع ${currentMB} من ${totalMB} ميغابايت - الجزء ${i + 1} من ${totalChunks})`);

            lastResponse = await uploadChunkWithRetry(chunkFormData, 2);

            if (lastResponse?.isStaticHost404) {
              break;
            }
          }

          if (lastResponse?.isStaticHost404) {
            setUploadStatusText('الخادم غير متصل بالرفع المباشر (استضافة ثابتة). جارٍ الحفظ الذكي في ذاكرة جهازك...');
            const localBookId = `local_pdf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
            finalUrl = await savePdfToIndexedDB(localBookId, selectedFile, selectedFile.name);
            uploadedFileName = selectedFile.name;
            uploadedFileSize = selectedFile.size;
            isLocalFallback = true;
          } else if (!lastResponse || !lastResponse.url) {
            throw new Error('لم يتم استلام رابط الملف المكتمل من الخادم.');
          } else {
            finalUrl = lastResponse.url;
            uploadedFileName = lastResponse.fileName || selectedFile.name;
            uploadedFileSize = lastResponse.fileSize || selectedFile.size;
          }
        }
      } else {
        if (!directUrl.trim()) {
          setErrorMessage('يرجى كتابة رابط الـ PDF المباشر (مثل رابط Google Drive أو Netlify).');
          setIsSubmitting(false);
          return;
        }
        finalUrl = normalizeUrl(directUrl);
      }

      setUploadStatusText('جارٍ حفظ بيانات الكتاب ونشره...');
      setUploadProgress('جارٍ النشر...');

      const success = await onAddBook({
        title: title.trim(),
        dept,
        stage,
        url: finalUrl,
        fileName: uploadedFileName || undefined,
        fileSize: uploadedFileSize || undefined
      });

      if (success) {
        if (isLocalFallback) {
          setSuccessMessage(`تم بنجاح حفظ ونشر كتاب (${title}) في قسم (${dept}) - ${stage}! أصبح متاحاً وجاهزاً للقراءة فوراً. (تنبيه المشرف: موقعك مستضاف على Netlify وهو استضافة ثابتة، لذا حُفظ الملف محلياً؛ لمشاركة الكتب مع كافة الطلاب دون سيرفر، ننصحك باستخدام تبويب «رابط مباشر - Google Drive»).`);
        } else {
          setSuccessMessage(`تم بنجاح نشر كتاب (${title}) في قسم (${dept}) - ${stage}! سيظهر الآن فوراً لكل الطلاب في كافة الأجهزة والمتصفحات.`);
        }
        setTitle('');
        setSelectedFile(null);
        setDirectUrl('');
        setUploadPercent(null);
        setUploadStatusText(null);
        const fileInput = document.getElementById('admin-file-input') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
      } else {
        setErrorMessage('حدث خطأ أثناء حفظ الكتاب. يرجى المحاولة مرة أخرى.');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'حدث خطأ غير متوقع أثناء الرفع.');
    } finally {
      setIsSubmitting(false);
      setUploadProgress(null);
      setUploadPercent(null);
      setUploadStatusText(null);
    }
  };

  const handleJsonRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (Array.isArray(json)) {
          const ok = await onImportBackup(json);
          if (ok) {
            setSuccessMessage(`تم استيراد ${json.length} كتاب بنجاح إلى الخادم!`);
          } else {
            setErrorMessage('فشل استيراد النسخة الاحتياطية.');
          }
        } else {
          setErrorMessage('صيغة ملف النسخة الاحتياطية غير صحيحة.');
        }
      } catch (error) {
        setErrorMessage('فشل قراءة ملف JSON.');
      }
    };
    reader.readAsText(file);
  };

  const handleAddDepartmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeptSuccessMsg(null);
    setDeptErrorMsg(null);

    if (!newDeptName.trim()) {
      setDeptErrorMsg('يرجى كتابة اسم القسم المهني.');
      return;
    }

    if (!onAddDepartment) return;

    setIsSubmittingDept(true);
    try {
      const ok = await onAddDepartment({
        name: newDeptName.trim(),
        title: newDeptName.trim(),
        description: newDeptDesc.trim() || `المناهج والكتب التخصصية لـ ${newDeptName.trim()}`,
        iconName: newDeptIcon,
        colorTheme: newDeptColor
      });

      if (ok) {
        setDeptSuccessMsg(`تم بنجاح إضافة قسم (${newDeptName.trim()}) وتقسيمه تلقائياً إلى 3 مراحل دراسية (الأولى، الثانية، الثالثة)!`);
        setNewDeptName('');
        setNewDeptDesc('');
      } else {
        setDeptErrorMsg('تعذر حفظ القسم الجديد.');
      }
    } catch (err: any) {
      setDeptErrorMsg(err.message || 'حدث خطأ أثناء حفظ القسم.');
    } finally {
      setIsSubmittingDept(false);
    }
  };

  const handleDeleteDepartmentSubmit = async (deptId: string, deptName: string) => {
    if (!window.confirm(`هل أنت متأكد من حذف قسم (${deptName})؟ لن يتم حذف الكتب تلقائياً ولكن القسم سيختفي من واجهة الطلاب.`)) {
      return;
    }
    if (!onDeleteDepartment) return;

    setDeletingDeptId(deptId);
    try {
      await onDeleteDepartment(deptId);
      setDeptSuccessMsg(`تم حذف قسم (${deptName}) بنجاح.`);
    } catch (err: any) {
      setDeptErrorMsg(err.message || 'فشل حذف القسم.');
    } finally {
      setDeletingDeptId(null);
    }
  };

  const handleDeleteBookSubmit = (bookId: string, bookTitle: string) => {
    setBookToDelete({ id: bookId, title: bookTitle });
  };

  const handleConfirmDeleteBook = async () => {
    if (!bookToDelete || !onDeleteBook) return;
    const { id, title: bookTitle } = bookToDelete;
    setDeletingBookId(id);
    setBookToDelete(null);
    try {
      await onDeleteBook(id);
      setSuccessMessage(`تم حذف كتاب (${bookTitle}) بنجاح.`);
    } catch (err: any) {
      setErrorMessage(err.message || 'فشل حذف الكتاب.');
    } finally {
      setDeletingBookId(null);
    }
  };

  const filteredManageBooks = books.filter((b) =>
    b.title.toLowerCase().includes(manageBooksSearch.toLowerCase().trim()) ||
    b.dept.toLowerCase().includes(manageBooksSearch.toLowerCase().trim()) ||
    b.stage.toLowerCase().includes(manageBooksSearch.toLowerCase().trim())
  );

  return (
    <section id="admin-panel-section" className="mb-8 bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-teal-500 rounded-3xl p-4 sm:p-7 shadow-2xl transition-all">
      {/* Top Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-500 text-white flex items-center justify-center shadow-md shadow-teal-700/20">
            <CloudUpload className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
              لوحة إدارة موسوعة سومر المركزية
              <span className="bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-[11px] px-2.5 py-0.5 rounded-full font-bold">
                /admin
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
              إدارة الأقسام والمراحل والكتب والمزامنة السحابية اللحظية مع تطبيق الطلاب
            </p>
          </div>
        </div>

        {/* Global Sync Indicator & Exit Button */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl text-xs text-slate-600 dark:text-slate-300 font-bold">
            <Globe2 className="w-4 h-4 text-emerald-500 animate-pulse" />
            <span>الكتب:</span>
            <span className="bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded-md text-teal-700 dark:text-teal-400 font-black">{totalBooksCount}</span>
            <span className="mr-1 text-slate-400">|</span>
            <span>الأقسام:</span>
            <span className="bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded-md text-amber-700 dark:text-amber-400 font-black">{departments.length}</span>
          </div>

          {currentUserEmail && (
            <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 px-2.5 py-1 rounded-xl text-[11px] text-emerald-900 dark:text-emerald-300 font-black">
              <span>👤 {currentUserEmail}</span>
            </div>
          )}

          {onSignOut && (
            <button
              onClick={onSignOut}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-900/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-bold transition-colors cursor-pointer"
              title="تسجيل الخروج من حساب المشرف"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>تسجيل خروج الحساب</span>
            </button>
          )}

          {onExitAdmin && (
            <button
              onClick={onExitAdmin}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors cursor-pointer"
            >
              <span>إغلاق اللوحة</span>
            </button>
          )}
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="my-5 flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveAdminTab('books')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
            activeAdminTab === 'books'
              ? 'bg-teal-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>إضافة كتاب جديد</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('departments')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
            activeAdminTab === 'departments'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FolderPlus className="w-4 h-4" />
          <span>إضافة وإدارة الأقسام ({departments.length})</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('all-books')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
            activeAdminTab === 'all-books'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>إدارة وحذف الكتب ({books.length})</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('stats')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
            activeAdminTab === 'stats'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Globe2 className="w-4 h-4" />
          <span>الإحصائيات الحية</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('settings')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
            activeAdminTab === 'settings'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          <span>الأمان والنسخ الاحتياطي</span>
        </button>
      </div>

      {/* TAB 1: ADD BOOK FORM */}
      {activeAdminTab === 'books' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Solution Explanation Box */}
          <div className="bg-teal-50/80 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/80 rounded-2xl p-4 text-xs text-teal-950 dark:text-teal-200 flex items-start gap-3">
            <Cloud className="w-5 h-5 text-teal-700 dark:text-teal-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed space-y-1.5 flex-1">
              <strong className="font-extrabold text-teal-900 dark:text-teal-300 flex items-center gap-1.5 text-xs sm:text-sm">
                <span>المزامنة السحابية الفورية:</span>
                <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] px-2 py-0.5 rounded-full font-black">
                  مزامنة لحظية نشطة
                </span>
              </strong>
              <p className="text-slate-700 dark:text-slate-300">
                • <strong>طريقة النشر السريع لجميع الطلاب:</strong> اختر القسم والمرحلة وضع رابط ملف الـ PDF من <strong>Google Drive</strong> (أو ارفعه مباشرة). بمجرد النقر على «حفظ ونشر الكتاب»، يُحفظ في السحابة فوراً ويظهر لكل الطلاب في العراق بدون الحاجة لتحديث التطبيق من المتجر.
              </p>
            </div>
          </div>

          {/* Success / Error Alerts */}
          {successMessage && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-xl text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Book Addition Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Title */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  اسم الكتاب أو المنهج <span className="text-rose-500">*</span>
                </label>
                <input
                  id="admin-book-title-input"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: العلوم الصناعية - الكهرباء"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 text-slate-900 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-medium transition-all outline-none"
                />
              </div>

              {/* Department (Dynamic, includes all default & custom departments) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  القسم المهني <span className="text-rose-500">*</span>
                </label>
                <select
                  id="admin-book-dept-select"
                  value={dept}
                  onChange={(e) => setDept(e.target.value as DepartmentId)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 text-slate-900 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-medium transition-all outline-none"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.name || d.dept}>
                      {d.title || d.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Stage (Three stages) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  المرحلة الدراسية <span className="text-rose-500">*</span>
                </label>
                <select
                  id="admin-book-stage-select"
                  value={stage}
                  onChange={(e) => setStage(e.target.value as StageId)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 text-slate-900 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-medium transition-all outline-none"
                >
                  <option value="المرحلة الأولى">المرحلة الأولى</option>
                  <option value="المرحلة الثانية">المرحلة الثانية</option>
                  <option value="المرحلة الثالثة">المرحلة الثالثة (الوزاري)</option>
                </select>
              </div>
            </div>

        {/* Input Mode Toggle (File Upload vs Direct Link) */}
        <div className="bg-slate-50 dark:bg-slate-800/70 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">طريقة توفير ملف الـ PDF:</span>
            <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold">
              <button
                type="button"
                onClick={() => setInputMode('upload')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  inputMode === 'upload'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                رفع ملف من جهازك
              </button>
              <button
                type="button"
                onClick={() => setInputMode('url')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  inputMode === 'url'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                رابط Google Drive أو رابط مباشر
              </button>
            </div>
          </div>

          {inputMode === 'upload' ? (
            <div>
              <label 
                htmlFor="admin-file-input"
                className="border-2 border-dashed border-slate-300 hover:border-teal-500 bg-white rounded-xl p-5 text-center cursor-pointer block transition-colors group"
              >
                <UploadCloud className="w-8 h-8 mx-auto text-slate-400 group-hover:text-teal-600 transition-colors mb-2" />
                {selectedFile ? (
                  <div className="space-y-1">
                    <span className="text-xs sm:text-sm font-bold text-teal-900 block truncate max-w-md mx-auto">
                      📄 {selectedFile.name}
                    </span>
                    <span className="text-[11px] text-slate-500 block">
                      الحجم: {(selectedFile.size / (1024 * 1024)).toFixed(2)} ميغابايت - انقر للتغيير
                      {selectedFile.size > 30 * 1024 * 1024 && (
                        <span className="text-teal-700 font-bold mr-1.5">
                          (حجم كبير: سيتم رفعه بسلاسة عبر نظام الأجزاء الذكية)
                        </span>
                      )}
                    </span>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <span className="text-xs sm:text-sm font-bold text-slate-700 block">
                      انقر لاختيار ملف PDF من جهازك أو اسحبه هنا
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      يدعم كافة الأحجام والكتب الكبيرة مع مؤشر نسبة الرفع والسرعة
                    </span>
                  </div>
                )}
                <input
                  id="admin-file-input"
                  type="file"
                  accept="application/pdf,.pdf"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            </div>
          ) : (
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <LinkIcon className="w-3.5 h-3.5 text-teal-700" />
                <span>رابط PDF المباشر:</span>
              </label>
              <input
                id="admin-book-url-input"
                type="url"
                value={directUrl}
                onChange={(e) => setDirectUrl(e.target.value)}
                placeholder="https://drive.google.com/file/d/... أو أي رابط مباشر"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 rounded-xl text-xs sm:text-sm font-medium outline-none dir-ltr text-left"
              />
              <p className="text-[11px] text-slate-500">
                يمكنك وضع رابط مباشر أو رابط مشاركة من Google Drive (سيتم تجهيزه تلقائياً ليعمل كقارئ إلكتروني للطلاب).
              </p>
            </div>
          )}
        </div>

        {/* Real-time Chunked Upload Progress Bar */}
        {uploadPercent !== null && (
          <div className="w-full bg-teal-50/80 border border-teal-200 rounded-xl p-3.5 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between text-xs font-bold text-teal-950">
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-teal-700 shrink-0" />
                <span>{uploadStatusText || 'جارٍ الرفع...'}</span>
              </span>
              <span className="bg-teal-700 text-white px-2.5 py-0.5 rounded-full text-[11px] font-mono shrink-0 shadow-xs">
                {uploadPercent}%
              </span>
            </div>
            {/* Visual Bar Track */}
            <div className="w-full bg-slate-200/90 h-3 rounded-full overflow-hidden p-0.5">
              <div 
                className="bg-linear-to-r from-teal-600 to-emerald-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${uploadPercent}%` }}
              />
            </div>
            <p className="text-[10px] text-teal-800 text-right">
              ⚡ <strong>تقنية التجزئة السريعة:</strong> يتم رفع الكتاب على أجزاء صغيرة متتابعة لتفادي انقطاع الاتصال ومشاكل بطء الإنترنت والشبكات الضعيفة.
            </p>
          </div>
        )}

        {/* Submit Button & Simple Indicator */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          {uploadProgress && uploadPercent === null && (
            <div className="text-xs text-teal-700 font-bold flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
              <span>{uploadProgress}</span>
            </div>
          )}

          <div className="flex items-center gap-2 mr-auto w-full sm:w-auto">
            <button
              id="admin-submit-book-btn"
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto px-6 py-2.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-sm shadow-teal-900/20 transition-all cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{uploadPercent !== null ? `جارٍ الرفع (${uploadPercent}%)...` : 'جارٍ النشر العام...'}</span>
                </>
              ) : (
                <>
                  <CloudUpload className="w-4 h-4" />
                  <span>نشر الكتاب لجميع المتصفحات</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
    )}

      {/* TAB 2: DEPARTMENTS MANAGER (ADD & MANAGE VOCATIONAL DEPARTMENTS WITH 3 AUTOMATIC STAGES) */}
      {activeAdminTab === 'departments' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Header Info Banner */}
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 sm:p-5 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md shadow-amber-500/20">
              <FolderPlus className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <span>إضافة قسم مهني جديد</span>
                <span className="text-[10px] font-black bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 px-2 py-0.5 rounded-full">
                  تقسيم تلقائي لـ 3 مراحل
                </span>
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                عند إضافة أي قسم مهني جديد (مثل الأجهزة الطبية، الليزر، ميكانيك السيارات، النفط...)، سيقوم النظام تلقائياً بتقسيمه إلى ثلاث مراحل دراسية: <strong>المرحلة الأولى • المرحلة الثانية • المرحلة الثالثة</strong>، وسيظهر فوراً في واجهة الطلاب مع أيقونته الخاصة.
              </p>
            </div>
          </div>

          {/* Department Success / Error Alerts */}
          {deptSuccessMsg && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{deptSuccessMsg}</span>
            </div>
          )}

          {deptErrorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-xl text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{deptErrorMsg}</span>
            </div>
          )}

          {/* New Department Form */}
          <form onSubmit={handleAddDepartmentSubmit} className="bg-slate-50 dark:bg-slate-800/60 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Department Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  اسم القسم التخصصي <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newDeptName}
                  onChange={(e) => setNewDeptName(e.target.value)}
                  placeholder="مثال: الأجهزة الطبية، الليزر، ميكانيك وتكييف..."
                  className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-slate-900 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-medium outline-none"
                />
              </div>

              {/* Department Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  وصف مختصر للتخصص (اختياري)
                </label>
                <input
                  type="text"
                  value={newDeptDesc}
                  onChange={(e) => setNewDeptDesc(e.target.value)}
                  placeholder="مثال: صيانة وتشغيل الأجهزة التشخيصية والمختبرية..."
                  className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-slate-900 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-medium outline-none"
                />
              </div>
            </div>

            {/* Department Color Theme */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                لون السمة والبطاقة:
              </label>
              <div className="flex flex-wrap items-center gap-2">
                {COLOR_THEMES.map((theme) => (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => setNewDeptColor(theme.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      newDeptColor === theme.id
                        ? `${theme.bg} ${theme.text} ${theme.border} ring-2 ring-amber-400`
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-400'
                    }`}
                  >
                    <span className={`w-2.5 h-2.5 rounded-full ${theme.bg} border ${theme.border}`} />
                    <span>{theme.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Selectable Icon Library */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                اختر أيقونة مناسبة للقسم:
              </label>
              <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-56 overflow-y-auto p-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl">
                {DEPARTMENT_ICON_OPTIONS.map((item) => {
                  const ItemIcon = item.icon;
                  const isSelected = newDeptIcon === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setNewDeptIcon(item.id)}
                      className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center gap-1 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-400 ring-2 ring-amber-400/40'
                          : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-amber-400/50'
                      }`}
                    >
                      <ItemIcon className="w-5 h-5" />
                      <span className="text-[10px] font-bold line-clamp-1">{item.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Live Preview & Stages Breakdown */}
            <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
              <div className="text-[11px] font-bold text-slate-500 flex items-center justify-between">
                <span>معاينة تقسيم القسم تلقائياً:</span>
                <span className="text-emerald-700 dark:text-emerald-400 font-extrabold">3 مراحل دراسية مجهزة فوراً</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-teal-900 dark:text-teal-200">
                  <span className="font-black block">١. المرحلة الأولى</span>
                  <span className="text-[10px] text-teal-700 dark:text-teal-400">كتب ومناهج الصف الأول</span>
                </div>
                <div className="p-2.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-sky-900 dark:text-sky-200">
                  <span className="font-black block">٢. المرحلة الثانية</span>
                  <span className="text-[10px] text-sky-700 dark:text-sky-400">كتب ومناهج الصف الثاني</span>
                </div>
                <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
                  <span className="font-black block">٣. المرحلة الثالثة</span>
                  <span className="text-[10px] text-amber-700 dark:text-amber-400">الامتحان الوزاري التخصصي</span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end pt-1">
              <button
                type="submit"
                disabled={isSubmittingDept}
                className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-amber-600/20 transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isSubmittingDept ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>جارٍ حفظ القسم في السحابة...</span>
                  </>
                ) : (
                  <>
                    <FolderPlus className="w-4 h-4" />
                    <span>حفظ ونشر القسم الجديد في السحابة</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* List of Current Departments */}
          <div className="space-y-3">
            <h4 className="text-xs sm:text-sm font-black text-slate-800 dark:text-slate-100 flex items-center justify-between">
              <span>الأقسام المتاحة حالياً في الموسوعة ({departments.length})</span>
              <span className="text-[11px] font-bold text-slate-500">محدثة سحابياً</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {departments.map((d) => {
                const DeptIcon = getDepartmentIcon(d.iconName);
                const theme = getColorThemeClasses(d.colorTheme);
                const bookCount = books.filter((b) => b.dept === d.name || b.dept === d.dept).length;

                return (
                  <div
                    key={d.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 flex items-start justify-between gap-3 shadow-xs"
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-xl ${theme.iconBg} flex items-center justify-center shrink-0`}>
                        <DeptIcon className="w-5 h-5" />
                      </div>
                      <div className="space-y-0.5">
                        <h5 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white leading-tight">
                          {d.title || d.name}
                        </h5>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                          {d.description || `مناهج ${d.name}`}
                        </p>
                        <div className="flex items-center gap-1.5 pt-1">
                          <span className="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md">
                            {bookCount} كتب
                          </span>
                          <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold">
                            3 مراحل
                          </span>
                        </div>
                      </div>
                    </div>

                    {d.isCustom && onDeleteDepartment && (
                      <button
                        type="button"
                        onClick={() => handleDeleteDepartmentSubmit(d.id, d.name)}
                        disabled={deletingDeptId === d.id}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                        title="حذف هذا القسم"
                      >
                        {deletingDeptId === d.id ? (
                          <Loader2 className="w-4 h-4 animate-spin text-rose-500" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ALL BOOKS MANAGEMENT & DELETION */}
      {activeAdminTab === 'all-books' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100">
                مكتبة الكتب الشاملة والتحكم بالحذف ({books.length})
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                يمكنك البحث وتصفية أي كتاب وحذفه نهائياً من قاعدة البيانات السحابية
              </p>
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={manageBooksSearch}
                onChange={(e) => setManageBooksSearch(e.target.value)}
                placeholder="ابحث باسم الكتاب أو القسم..."
                className="w-full pr-8 pl-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold outline-none"
              />
            </div>
          </div>

          {filteredManageBooks.length === 0 ? (
            <div className="text-center py-10 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <BookOpen className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-500">لا توجد كتب مطابقة لبحثك</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[460px] overflow-y-auto p-1">
              {filteredManageBooks.map((b) => (
                <div
                  key={b.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3 hover:border-slate-300 dark:hover:border-slate-700 transition-colors shadow-2xs"
                >
                  <div className="space-y-1 min-w-0">
                    <h5 className="text-xs sm:text-sm font-black text-slate-900 dark:text-slate-100 truncate">
                      {b.title}
                    </h5>
                    <div className="flex items-center gap-2 flex-wrap text-[10px] font-bold text-slate-500">
                      <span className="bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 px-2 py-0.5 rounded-md">
                        {b.dept}
                      </span>
                      <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md">
                        {b.stage}
                      </span>
                      {b.url && (
                        <a
                          href={b.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5"
                        >
                          <ExternalLink className="w-2.5 h-2.5" />
                          <span>فتح الرابط</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {onDeleteBook && (
                    <button
                      type="button"
                      onClick={() => handleDeleteBookSubmit(b.id, b.title)}
                      disabled={deletingBookId === b.id}
                      className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer shrink-0"
                      title="حذف هذا الكتاب نهائياً من السحابة"
                    >
                      {deletingBookId === b.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: LIVE STATISTICS */}
      {activeAdminTab === 'stats' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="pb-1">
            <h3 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100">
              إحصائيات القراء والفتح المباشرة
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              بيانات حية وفعلية 100% عن استخدام الطلاب لموسوعة سومر والكتب الأكثر قراءة
            </p>
          </div>
          <AdminStatsDashboard books={books} />
        </div>
      )}

      {/* TAB 5: SECURITY & BACKUP SETTINGS */}
      {activeAdminTab === 'settings' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100">
              إعدادات الأمان، رمز الحماية، والنسخ الاحتياطي
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              تغيير كلمة المرور الخاصة برابط الإدارة وتصدير نسخة احتياطية لجميع البيانات
            </p>
          </div>

          {/* Change PIN Form */}
          <form
            onSubmit={handleChangePinSubmit}
            className="p-4 sm:p-5 bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-2xl space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black text-amber-950 dark:text-amber-300">
                <ShieldCheck className="w-4 h-4 text-amber-700 dark:text-amber-400" />
                <span>تعيين رمز حماية سري جديد للوحة المسؤول (/admin)</span>
              </div>
              <span className="text-[11px] text-amber-800 dark:text-amber-400 font-medium">الرمز الحالي مفعل</span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              اختر رمزاً من 4 أرقام أو حروف يسهل تذكره لتأمين بوابة الإدارة.
            </p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <input
                type="text"
                value={newPinValue}
                onChange={(e) => setNewPinValue(e.target.value)}
                placeholder="أدخل الرمز السري الجديد (مثال: sumer2025)..."
                className="flex-1 px-3 py-2 bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 focus:border-amber-600 focus:ring-2 focus:ring-amber-500/20 rounded-xl text-xs font-bold outline-none"
              />
              <button
                type="submit"
                disabled={pinChangeLoading}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                {pinChangeLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                <span>حفظ الرمز الجديد</span>
              </button>
            </div>

            {pinChangeMsg && (
              <div
                className={`text-xs font-bold p-2.5 rounded-xl flex items-center gap-2 ${
                  pinChangeMsg.type === 'success'
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : 'bg-red-100 text-red-900 border border-red-300'
                }`}
              >
                {pinChangeMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-700 shrink-0" />
                )}
                <span>{pinChangeMsg.text}</span>
              </div>
            )}
          </form>

          {/* Backup & Sync Tools */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
            <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
              أدوات النسخ الاحتياطي والمزامنة السحابية:
            </h4>
            <div className="flex flex-wrap items-center gap-2.5">
              {onSyncAllToCloud && (
                <button
                  type="button"
                  disabled={isSyncingCloud}
                  onClick={async () => {
                    setIsSyncingCloud(true);
                    const ok = await onSyncAllToCloud();
                    setIsSyncingCloud(false);
                    if (ok) {
                      setSuccessMessage('تمت مزامنة وحفظ جميع الكتب على السحابة الإلكترونية (Firebase) بنجاح!');
                    } else {
                      setErrorMessage('حدث خطأ أثناء المزامنة السحابية.');
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/60 dark:hover:bg-teal-900 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
                  title="مزامنة الكتب الحالية مع السحابة لتظهر للجميع"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-teal-700 dark:text-teal-400 ${isSyncingCloud ? 'animate-spin' : ''}`} />
                  <span>مزامنة كافة البيانات مع السحابة</span>
                </button>
              )}

              <button
                type="button"
                onClick={onExportBackup}
                className="flex items-center gap-1.5 px-3 py-2 bg-white dark:bg-slate-900 hover:bg-slate-100 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                title="تصدير ملف JSON يحتوي على جميع الكتب"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تصدير نسخة احتياطية (JSON)</span>
              </button>

              <label className="flex items-center gap-1.5 px-3 py-2 bg-white dark:bg-slate-900 hover:bg-slate-100 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer">
                <UploadCloud className="w-3.5 h-3.5" />
                <span>استيراد نسخة احتياطية</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleJsonRestore}
                  className="hidden"
                />
              </label>

              <a
                href="/api/download/standalone-html"
                download="index.html"
                className="flex items-center gap-1.5 px-3 py-2 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                <span>تحميل نسخة مستقلة (Windows 7)</span>
              </a>
            </div>
          </div>
        </div>
      )}
      {/* Custom Confirmation Modal for Deleting Books (avoids window.confirm iFrame blockage) */}
      {bookToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border-2 border-rose-500 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-right">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="text-base sm:text-lg font-black text-slate-950 dark:text-white">
                تأكيد حذف الكتاب نهائياً
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-bold leading-relaxed">
                هل أنت متأكد من رغبتك بحذف كتاب <span className="text-rose-600 font-black">"{bookToDelete.title}"</span> من السحابة وقاعدة البيانات؟
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleConfirmDeleteBook}
                className="flex-1 py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-black transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Trash2 className="w-4 h-4" />
                <span>نعم، احذف الكتاب</span>
              </button>

              <button
                type="button"
                onClick={() => setBookToDelete(null)}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer"
              >
                <span>إلغاء</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
