import React from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  ChevronLeft, 
  BookOpen, 
  Fuel,
  Volume2,
  Disc,
  Power
} from 'lucide-react';

interface ElectricDepartmentCardProps {
  onSelect: () => void;
  booksCount: number;
}

export const ElectricDepartmentCard: React.FC<ElectricDepartmentCardProps> = ({
  onSelect,
  booksCount
}) => {
  return (
    <motion.div
      id="dept-card-الكهرباء"
      onClick={onSelect}
      whileHover={{
        scale: 1.025,
        y: -4,
        boxShadow: '0 0 35px rgba(245, 158, 11, 0.38)'
      }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
      className="group relative bg-gradient-to-b from-white via-amber-50/50 to-amber-100/40 dark:from-zinc-950 dark:via-zinc-900 dark:to-amber-950/70 border-2 border-amber-300 dark:border-amber-600/70 hover:border-amber-500 dark:hover:border-yellow-400 rounded-3xl p-6 flex flex-col justify-between shadow-lg shadow-amber-100/50 dark:shadow-xl dark:shadow-amber-950/40 cursor-pointer overflow-hidden transition-colors duration-300"
    >
      {/* Heavy Machinery Diamond Tread / Metal Plate Texture */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-15 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:12px_12px]" 
      />

      {/* Industrial Warning Hazard Stripes Accent on Top */}
      <div className="absolute top-0 inset-x-0 h-2 bg-[repeating-linear-gradient(45deg,#f59e0b,#f59e0b_10px,#fbbf24_10px,#fbbf24_20px)] dark:bg-[repeating-linear-gradient(45deg,#000,#000_10px,#f59e0b_10px,#f59e0b_20px)] opacity-70 dark:opacity-80" />

      {/* High-Voltage Electrical Energy Pulse Beam */}
      <motion.div
        className="absolute top-2 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-amber-500 dark:via-amber-400 to-transparent pointer-events-none"
        animate={{
          x: ['-100%', '100%'],
          opacity: [0, 1, 0]
        }}
        transition={{
          duration: 2.2,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />

      {/* Vibration & Heat Wave Ambient Glow */}
      <motion.div
        className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/15 dark:bg-amber-500/20 rounded-full blur-2xl pointer-events-none"
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.3, 0.65, 0.3]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
      <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-orange-600/10 dark:bg-orange-600/20 rounded-full blur-xl pointer-events-none" />

      {/* Card Machinery Body */}
      <div className="relative z-10 pt-1">
        <div className="flex items-center justify-between mb-4">
          {/* Heavy Diesel Generator Rotor Wheel Icon */}
          <div className="relative">
            <motion.div
              className="absolute -inset-1 rounded-2xl bg-amber-500/20 dark:bg-amber-500/30 blur-xs pointer-events-none"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.4, 0.9, 0.4]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            />
            <div className="relative w-14 h-14 rounded-2xl bg-white dark:bg-zinc-950 border-2 border-amber-300 dark:border-amber-500/80 flex items-center justify-center text-amber-600 dark:text-yellow-400 shadow-md shadow-amber-100 dark:shadow-black group-hover:scale-110 group-hover:border-amber-500 dark:group-hover:border-yellow-300 transition-all">
              <Disc className="w-8 h-8 animate-spin text-amber-600 dark:text-amber-400 group-hover:text-amber-700 dark:group-hover:text-yellow-300 [animation-duration:6s]" />
              <Zap className="w-4 h-4 fill-amber-500 dark:fill-amber-400 text-amber-600 dark:text-amber-300 absolute" />
            </div>
          </div>

          <div className="flex flex-col items-end gap-1">
            <span className="font-mono text-[10px] text-amber-800 dark:text-amber-200 bg-amber-100/80 dark:bg-amber-950/90 border border-amber-300 dark:border-amber-600/70 px-2.5 py-0.5 rounded-md flex items-center gap-1 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-pulse" />
              <span>DIESEL GEN // 1500 RPM</span>
            </span>
            <span className="text-[11px] font-mono font-bold text-amber-700 dark:text-amber-300/90 flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>{booksCount} كتب ومناهج</span>
            </span>
          </div>
        </div>

        {/* Industrial Metal Tag Plate */}
        <div className="mb-2.5 bg-white/80 dark:bg-black/60 border border-amber-200 dark:border-zinc-800 rounded-xl p-2.5 shadow-xs dark:shadow-inner">
          <div className="flex items-center justify-between text-[11px] font-mono text-amber-700 dark:text-amber-400/90 mb-1">
            <span className="flex items-center gap-1">
              <Fuel className="w-3.5 h-3.5 text-orange-500 dark:text-orange-400" />
              <span>محرك الديزل والتوليد</span>
            </span>
            <span className="text-slate-400 dark:text-zinc-500 text-[10px]">CUMMINS / PERKINS</span>
          </div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white group-hover:text-amber-700 dark:group-hover:text-yellow-300 transition-colors flex items-center gap-1.5">
            <span>قسم الكهرباء</span>
          </h3>
        </div>

        <h4 className="text-xs font-mono font-bold text-amber-700 dark:text-amber-300/90 mb-2">
          محركات الديزل، المولدات التزامنية، ومحولات القدرة
        </h4>

        <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed line-clamp-2">
          مناهج المولدات الكهربائية الحثية والتزامنية، لوحات ATS للتحويل التلقائي، والآلات الكهربائية لجميع المراحل.
        </p>

        {/* Live Generator Dashboard Snippet */}
        <div className="mt-3.5 py-1.5 px-3 rounded-xl bg-white/90 dark:bg-zinc-950/90 border border-amber-200 dark:border-amber-900/60 text-[11px] font-mono text-slate-700 dark:text-zinc-300 flex items-center justify-between shadow-xs dark:shadow-none">
          <div className="flex items-center gap-2">
            <span className="text-amber-700 dark:text-amber-400 font-bold">1500 RPM</span>
            <span className="text-slate-300 dark:text-zinc-600">|</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">50.0 Hz</span>
            <span className="text-slate-300 dark:text-zinc-600">|</span>
            <span className="text-amber-600 dark:text-yellow-400 font-bold">400 V</span>
          </div>
          <span className="text-amber-700 dark:text-amber-400 font-bold group-hover:text-amber-800 dark:group-hover:text-yellow-300 flex items-center gap-0.5">
            <Power className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
            <span>تشغيل</span>
          </span>
        </div>
      </div>

      {/* Generator Card Footer Button */}
      <div className="relative z-10 mt-5 pt-3.5 border-t border-amber-200 dark:border-zinc-800 flex items-center justify-between text-xs font-mono font-bold text-amber-700 dark:text-amber-400 group-hover:text-amber-800 dark:group-hover:text-yellow-300">
        <span className="flex items-center gap-1.5">
          <Volume2 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>دخول غرفة المولد وتحديد المرحلة</span>
        </span>
        <div className="flex items-center gap-1 group-hover:translate-x-[-4px] transition-transform">
          <span>START</span>
          <ChevronLeft className="w-4 h-4 text-amber-600 dark:text-amber-400" />
        </div>
      </div>
    </motion.div>
  );
};
