import React, { useState } from 'react';
import { 
  ArrowRight, 
  Eye, 
  Download, 
  Trash2, 
  Search, 
  Copy, 
  Check, 
  Zap, 
  Disc,
  Fuel,
  Power,
  Gauge
} from 'lucide-react';
import { Book, StageId } from '../types';

interface ElectricBooksVaultProps {
  currentStage: StageId;
  books: Book[];
  isAdmin: boolean;
  onBackToStages: () => void;
  onReadBook: (book: Book) => void;
  onDeleteBook: (id: string) => Promise<boolean>;
  onOpenAdmin: () => void;
}

export const ElectricBooksVault: React.FC<ElectricBooksVaultProps> = ({
  currentStage,
  books,
  isAdmin,
  onBackToStages,
  onReadBook,
  onDeleteBook,
  onOpenAdmin
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [bookToDelete, setBookToDelete] = useState<Book | null>(null);

  // Books filtered to Electrical dept + current stage
  const stageBooks = books.filter(
    (b) => b.dept === 'الكهرباء' && b.stage === currentStage
  );

  const filteredBooks = stageBooks.filter((b) =>
    b.title.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const handleCopyLink = (book: Book) => {
    const absoluteUrl = book.url.startsWith('http')
      ? book.url
      : `${window.location.origin}${book.url}`;
    
    navigator.clipboard.writeText(absoluteUrl);
    setCopiedId(book.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (book: Book) => {
    const link = document.createElement('a');
    link.href = book.url;
    link.download = `${book.title}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = (book: Book) => {
    setBookToDelete(book);
  };

  const confirmDeleteBook = async () => {
    if (!bookToDelete) return;
    const target = bookToDelete;
    setBookToDelete(null);
    setDeletingId(target.id);
    try {
      await onDeleteBook(target.id);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-zinc-950 border-2 border-amber-300 dark:border-amber-600/70 shadow-xl dark:shadow-2xl dark:shadow-black text-slate-900 dark:text-zinc-100 font-sans transition-all duration-500">
      {/* Industrial Machine Diamond Tread Texture */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-5 dark:opacity-15 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:16px_16px]" 
      />

      {/* Industrial Hazard Warning Strip on top */}
      <div className="absolute top-0 inset-x-0 h-2 bg-[repeating-linear-gradient(45deg,#1e293b,#1e293b_12px,#f59e0b_12px,#f59e0b_24px)] opacity-80 dark:opacity-90" />

      {/* Generator Control Dashboard Top Bar */}
      <div className="relative z-10 border-b border-slate-200 dark:border-zinc-800 bg-slate-50/95 dark:bg-zinc-900/95 backdrop-blur-md px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 pt-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 pl-2 border-l border-slate-300 dark:border-zinc-700">
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block animate-pulse" />
            <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
            <span className="w-3 h-3 rounded-full bg-sky-500 inline-block" />
          </div>

          <button
            onClick={onBackToStages}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-zinc-300 hover:text-amber-700 dark:hover:text-amber-400 bg-white dark:bg-zinc-800 hover:bg-amber-50 dark:hover:bg-zinc-750 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-zinc-700 transition-all cursor-pointer group shadow-xs"
          >
            <ArrowRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform text-amber-600 dark:text-amber-400" />
            <span>رجوع إلى سرعات ومراحل المولد</span>
          </button>
        </div>

        {/* Center Breadcrumb */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
            <Disc className="w-3.5 h-3.5 animate-spin [animation-duration:4s]" />
            <span>GENERATOR_OUTPUT</span>
          </span>
          <span className="text-slate-400 dark:text-zinc-600">/</span>
          <span className="text-slate-700 dark:text-zinc-300 font-bold">قسم الكهرباء والمولدات</span>
          <span className="text-slate-400 dark:text-zinc-600">/</span>
          <span className="text-amber-800 dark:text-yellow-300 font-bold bg-amber-100 dark:bg-amber-950/80 border border-amber-300 dark:border-amber-800/80 px-2 py-0.5 rounded">
            {currentStage}
          </span>
        </div>

        {/* Right Status */}
        <div className="flex items-center gap-2 font-mono text-[11px] text-amber-600 dark:text-amber-400">
          <Power className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span className="hidden sm:inline">OUTPUT_ENERGIZED</span>
        </div>
      </div>

      {/* Main Body */}
      <div className="relative z-10 p-5 sm:p-8 space-y-6">
        
        {/* Machine Output Header Banner */}
        <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-amber-50 via-white to-amber-50/70 dark:from-zinc-900 dark:via-amber-950/50 dark:to-zinc-900 border border-amber-200 dark:border-amber-500/40 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm dark:shadow-xl">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-500/20 border border-amber-200 dark:border-amber-500/50 text-amber-800 dark:text-amber-300 font-mono text-[11px] font-bold flex items-center gap-1.5">
                <Fuel className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                <span>GENERATOR OUTPUT FEED // {currentStage}</span>
              </span>
              <span className="text-xs text-slate-500 dark:text-zinc-400 font-mono">
                [1500 RPM // 50Hz // 400V]
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <span>خزينة كتب ومناهج قسم الكهرباء</span>
              <span className="text-amber-500 text-xl">⚙️</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-300 max-w-xl leading-relaxed">
              جميع الكتب المقررة والمناهج الوزارية التخصصية لـ {currentStage} جاهزة للقراءة والتحميل الفوري بدون تأخير.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-2xl px-4 py-3 text-right shadow-xs dark:shadow-inner">
              <span className="text-[10px] font-mono text-slate-500 dark:text-zinc-400 block">AVAILABLE MANUALS</span>
              <span className="text-xl font-mono font-black text-amber-600 dark:text-amber-400">
                {stageBooks.length} كتب ومناهج
              </span>
            </div>
          </div>
        </div>

        {/* Search & Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-500 dark:text-amber-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="البحث في كتب ومناهج المولدات والكهرباء..."
              className="w-full pl-4 pr-10 py-2.5 bg-slate-50 dark:bg-zinc-950 border border-slate-300 dark:border-zinc-800 focus:border-amber-500 dark:focus:border-amber-400 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-zinc-500 outline-none transition-all font-mono"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 dark:text-zinc-500 hover:text-slate-600 dark:hover:text-zinc-300 font-mono"
              >
                [مسح]
              </button>
            )}
          </div>

          {isAdmin && (
            <button
              onClick={onOpenAdmin}
              className="flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl shadow-md dark:shadow-lg dark:shadow-black transition-all cursor-pointer font-mono"
            >
              <Zap className="w-4 h-4 fill-slate-950" />
              <span>[+] إضافة ونشر كتاب جديد</span>
            </button>
          )}
        </div>

        {/* Books Grid */}
        {filteredBooks.length === 0 ? (
          <div className="bg-slate-50 dark:bg-zinc-950/70 border-2 border-dashed border-slate-300 dark:border-zinc-800 rounded-2xl p-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 flex items-center justify-center mx-auto text-amber-600 dark:text-amber-400 shadow-sm">
              <Disc className="w-8 h-8 animate-spin [animation-duration:6s]" />
            </div>
            <div className="space-y-1 font-mono">
              <h4 className="text-base font-black text-slate-800 dark:text-zinc-200">
                NO GENERATOR MANUALS CATALOGED
              </h4>
              <p className="text-xs text-slate-500 dark:text-zinc-400 max-w-md mx-auto">
                {searchQuery
                  ? 'لا توجد نتائج تطابق استعلام البحث المدخل.'
                  : 'لم يتم إدراج كتب لهذه المرحلة بعد. يمكن للمسؤول إضافتها فوراً من لوحة الإدارة.'}
              </p>
            </div>
            {isAdmin && (
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-amber-700 dark:text-amber-400 hover:text-amber-800 dark:hover:text-yellow-300 bg-white dark:bg-zinc-900 border border-slate-300 dark:border-zinc-700 px-4 py-2 rounded-xl transition-colors cursor-pointer shadow-xs"
              >
                <span>فتح لوحة النشر وإضافة كتاب</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredBooks.map((book) => {
              const isDeleting = deletingId === book.id;
              const isCopied = copiedId === book.id;

              return (
                <div
                  key={book.id}
                  className="group relative rounded-2xl bg-white dark:bg-zinc-900/90 border-2 border-slate-200 dark:border-zinc-800 hover:border-amber-400 dark:hover:border-amber-400 p-5 flex flex-col justify-between shadow-md dark:shadow-xl hover:shadow-amber-500/20 dark:hover:shadow-black transition-all duration-300 hover:-translate-y-1"
                >
                  {/* Rotor Ambient Glow */}
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl pointer-events-none group-hover:bg-amber-500/20 transition-all" />

                  <div>
                    {/* Top Row: Machine Tag & Delete */}
                    <div className="flex items-center justify-between mb-3.5">
                      <span className="font-mono text-[10px] text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-zinc-950 border border-amber-200 dark:border-zinc-700 px-2.5 py-0.5 rounded-md flex items-center gap-1.5">
                        <Disc className="w-3 h-3 text-amber-600 dark:text-amber-400 animate-spin [animation-duration:6s]" />
                        <span>GENERATOR_DOC // PDF</span>
                      </span>

                      {isAdmin && (
                        <button
                          onClick={() => handleDelete(book)}
                          disabled={isDeleting}
                          className="text-rose-500 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 p-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                          title="حذف من النظام"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Book Title */}
                    <h3 className="text-base font-black text-slate-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-yellow-300 transition-colors mb-2 leading-snug">
                      {book.title}
                    </h3>

                    <div className="flex items-center gap-2 font-mono text-[11px] text-slate-500 dark:text-zinc-400 mb-4">
                      <span>المرحلة الدراسية:</span>
                      <span className="text-amber-600 dark:text-amber-400 font-bold">{book.stage}</span>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-zinc-800 font-mono">
                    {/* Primary Read Button */}
                    <button
                      onClick={() => onReadBook(book)}
                      className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer group-hover:scale-[1.02]"
                    >
                      <Eye className="w-4 h-4" />
                      <span>قراءة وتصفح الكتاب المباشر</span>
                    </button>

                    {/* Secondary Download / Copy */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleDownload(book)}
                        className="py-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-750 text-slate-700 dark:text-zinc-300 hover:text-slate-900 dark:hover:text-white rounded-lg text-[11px] font-bold border border-slate-200 dark:border-zinc-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Download className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                        <span>تحميل</span>
                      </button>

                      <button
                        onClick={() => handleCopyLink(book)}
                        className="py-1.5 bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 dark:hover:bg-zinc-750 text-slate-700 dark:text-zinc-300 hover:text-slate-900 dark:hover:text-white rounded-lg text-[11px] font-bold border border-slate-200 dark:border-zinc-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                            <span className="text-emerald-600 dark:text-emerald-400">تم النسخ!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-slate-500 dark:text-zinc-400" />
                            <span>نسخ الرابط</span>
                          </>
                        )}
                      </button>
                    </div>

                    {book.url && (
                      <a
                        href={book.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full text-center block text-[10px] text-slate-500 dark:text-zinc-400 hover:text-amber-600 dark:hover:text-amber-300 pt-1 transition-colors"
                      >
                        [فتح الرابط الأصلي في نافذة مستقلة ↗]
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footer Substation Note */}
        <div className="border-t border-slate-200 dark:border-zinc-800 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-500 dark:text-zinc-400">
          <span>SUMER DIESEL GENERATOR ELECTRICAL VAULT // 50Hz 400V</span>
          <span className="text-amber-600 dark:text-amber-400 font-bold">ALL TEXTBOOKS SYNCED WITH CLOUD // SAFE</span>
        </div>
      </div>

      {/* Custom Confirmation Modal for Deleting Books */}
      {bookToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-zinc-900 border-2 border-rose-500 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-right">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="text-base sm:text-lg font-black text-slate-950 dark:text-white">
                تأكيد حذف الكتاب
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-bold leading-relaxed">
                هل أنت متأكد من حذف كتاب <span className="text-rose-600 font-black">"{bookToDelete.title}"</span> من المنصة؟
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={confirmDeleteBook}
                className="flex-1 py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-black transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Trash2 className="w-4 h-4" />
                <span>نعم، احذف الكتاب</span>
              </button>

              <button
                type="button"
                onClick={() => setBookToDelete(null)}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer"
              >
                <span>إلغاء</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
