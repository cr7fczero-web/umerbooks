import React from 'react';
import { motion } from 'framer-motion';
import { 
  ShieldCheck, 
  Terminal, 
  Lock, 
  ChevronLeft, 
  BookOpen, 
  Sparkles,
  Binary,
  Radio
} from 'lucide-react';
import { Book } from '../types';

interface CyberDepartmentCardProps {
  onSelect: () => void;
  booksCount: number;
}

export const CyberDepartmentCard: React.FC<CyberDepartmentCardProps> = ({
  onSelect,
  booksCount
}) => {
  return (
    <motion.div
      id="dept-card-الأمن السيبراني"
      onClick={onSelect}
      whileHover={{
        scale: 1.025,
        y: -4,
        boxShadow: '0 0 35px rgba(16, 185, 129, 0.35)'
      }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
      className="group relative bg-gradient-to-b from-white via-emerald-50/50 to-emerald-100/40 dark:from-slate-950 dark:via-slate-900 dark:to-emerald-950/80 border-2 border-emerald-200 dark:border-emerald-500/60 hover:border-emerald-400 dark:hover:border-emerald-400 rounded-3xl p-6 flex flex-col justify-between shadow-lg shadow-emerald-100/50 dark:shadow-lg dark:shadow-emerald-950/40 cursor-pointer overflow-hidden transition-colors duration-300"
    >
      {/* Background Matrix/Grid scanlines */}
      <div className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-25 bg-[linear-gradient(to_right,#059669_1px,transparent_1px),linear-gradient(to_bottom,#059669_1px,transparent_1px)] bg-[size:16px_16px]" />
      
      {/* Digital Data Signal Beam traveling along top edge */}
      <motion.div
        className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-emerald-500 dark:via-emerald-400 to-transparent pointer-events-none"
        animate={{
          x: ['-100%', '100%'],
          opacity: [0, 1, 0]
        }}
        transition={{
          duration: 2.5,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />

      {/* Ambient Cyber Pulse Aura */}
      <motion.div
        className="absolute -top-12 -right-12 w-32 h-32 bg-emerald-500/15 dark:bg-emerald-500/20 rounded-full blur-2xl pointer-events-none"
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.3, 0.6, 0.3]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />

      {/* Cyber Card Header */}
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="relative">
            <motion.div
              className="absolute -inset-1 rounded-2xl bg-emerald-500/20 dark:bg-emerald-500/30 blur-xs pointer-events-none"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.4, 0.9, 0.4]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            />
            <div className="relative w-14 h-14 rounded-2xl bg-white dark:bg-black/70 border-2 border-emerald-200 dark:border-emerald-500/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-md shadow-emerald-100 dark:shadow-emerald-950/60 group-hover:scale-110 group-hover:border-emerald-400 transition-all">
              <ShieldCheck className="w-7 h-7 animate-pulse text-emerald-600 dark:text-emerald-400" />
            </div>
          </div>

          <div className="flex flex-col items-end gap-1">
            <span className="font-mono text-[10px] text-emerald-800 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-800/80 px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-ping" />
              <span>TERMINAL OS</span>
            </span>
            <span className="text-[11px] font-mono font-bold text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{booksCount} كتب</span>
            </span>
          </div>
        </div>

        {/* Title */}
        <div className="mb-2">
          <div className="flex items-center gap-1.5 font-mono text-[11px] text-emerald-700 dark:text-emerald-400/90 mb-0.5">
            <Terminal className="w-3.5 h-3.5" />
            <span>ROOT_NODE // نظام الأمن</span>
          </div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors flex items-center gap-1.5">
            <span>قسم الأمن السيبراني</span>
            <Lock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </h3>
        </div>

        <h4 className="text-xs font-mono font-bold text-emerald-700 dark:text-emerald-400/80 mb-2">
          حماية الأنظمة، التشفير والدفاع الرقمي
        </h4>

        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
          مناهج أمن المعلومات، تحليل الثغرات، اختبار الاختراق، والتحقيق الجنائي الرقمي لجميع المراحل.
        </p>

        {/* Mini interactive code cue */}
        <div className="mt-3 py-1.5 px-3 rounded-xl bg-white/90 dark:bg-black/40 border border-emerald-200 dark:border-emerald-900/40 text-[10px] font-mono text-emerald-700 dark:text-emerald-500 flex items-center justify-between shadow-xs dark:shadow-none">
          <span>&gt; sys_boot: ready</span>
          <span className="text-emerald-600 dark:text-emerald-400/70 font-bold">اضغط للدخول ⚡</span>
        </div>
      </div>

      {/* Cyber Card Footer */}
      <div className="relative z-10 mt-5 pt-3.5 border-t border-emerald-100 dark:border-emerald-900/60 flex items-center justify-between text-xs font-mono font-bold text-emerald-700 dark:text-emerald-400 group-hover:text-emerald-800 dark:group-hover:text-emerald-300">
        <span className="flex items-center gap-1.5">
          <span>تشغيل نظام الأمن السيبراني</span>
        </span>
        <div className="flex items-center gap-1 group-hover:translate-x-[-4px] transition-transform">
          <span>ENTER</span>
          <ChevronLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
        </div>
      </div>
    </motion.div>
  );
};
