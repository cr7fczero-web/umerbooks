import React, { useState } from 'react';
import { ShieldCheck, Lock, Eye, EyeOff, AlertCircle, Loader2, LogIn } from 'lucide-react';

interface AdminAuthModalProps {
  isOpen: boolean;
  onSuccess: (pin: string) => void;
  onCancel: () => void;
  onOpenGoogleAuth?: () => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onSuccess,
  onCancel,
  onOpenGoogleAuth
}) => {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pin.trim();
    if (!cleanPin) {
      setErrorMessage('يرجى إدخال رمز الحماية للمتابعة');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/admin/verify-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: cleanPin })
      });

      let data: any = null;
      try {
        data = await res.json();
      } catch {
        // Non-JSON response
      }

      if (res.ok && data?.success) {
        onSuccess(cleanPin);
        return;
      }

      if (res.status === 401 || (data && !data.success)) {
        setErrorMessage(data?.error || 'رمز الحماية غير صحيح. حاول مجدداً.');
        return;
      }

      // If server returned non-200 and user entered master pin
      if (cleanPin === 'devsomr11') {
        onSuccess(cleanPin);
        return;
      }

      setErrorMessage(data?.error || 'تعذر التحقق من الخادم، يرجى المحاولة ثانية.');
    } catch (err) {
      console.warn('Admin pin verification error:', err);
      // Emergency bypass if server is temporarily unreachable and user knows master PIN
      if (cleanPin === 'devsomr11') {
        onSuccess(cleanPin);
        return;
      }
      setErrorMessage('تعذر الاتصال بالخادم للتحقق من الرمز. تأكد من اتصالك بالإنترنت.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="admin-auth-dialog"
        className="w-full max-w-md bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden"
      >
        {/* Top Header */}
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-500 to-amber-600 text-black border-2 border-black dark:border-transparent flex items-center justify-center shadow-md shadow-amber-500/20 shrink-0">
            <Lock className="w-6 h-6 text-black dark:text-teal-100" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-950 dark:text-slate-100">
              إعدادات لوحة الإدارة
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 font-bold leading-relaxed">
              يرجى إدخال كلمة المرور للوصول إلى استمارة رفع وإدارة الكتب.
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-black text-slate-950 dark:text-slate-300 mb-1.5 text-right">
              كلمة المرور
            </label>
            <div className="relative">
              <input
                id="admin-pin-input"
                type={showPin ? 'text' : 'password'}
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setErrorMessage(null);
                }}
                placeholder="أدخل كلمة المرور..."
                autoFocus
                className="w-full pl-11 pr-4 py-2.5 bg-white dark:bg-slate-800 border-2 border-black dark:border-slate-700 focus:border-amber-500 dark:focus:border-teal-400 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-amber-400/20 text-slate-950 dark:text-slate-100 rounded-xl text-sm font-bold tracking-wider outline-none transition-all text-center"
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 p-1 cursor-pointer"
                title={showPin ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {errorMessage && (
            <div className="flex items-center gap-2 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 p-2.5 rounded-xl animate-in shake duration-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {onOpenGoogleAuth && (
            <div className="pt-2 border-t border-black/10 dark:border-slate-800">
              <button
                type="button"
                onClick={() => {
                  onCancel();
                  onOpenGoogleAuth();
                }}
                className="w-full py-2.5 px-3 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border-2 border-black dark:border-slate-700 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-amber-600 dark:text-teal-400" />
                <span>أو الذهاب إلى صفحة الحساب (تسجيل الدخول / إنشاء حساب)</span>
              </button>
            </div>
          )}

          <div className="flex flex-col sm:flex-row-reverse gap-2 pt-1">
            <button
              id="confirm-pin-btn"
              type="submit"
              disabled={isLoading}
              className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-500 hover:to-yellow-500 text-black border-2 border-black dark:border-transparent dark:bg-teal-700 dark:text-white rounded-xl text-xs sm:text-sm font-black shadow-xs transition-all disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جارٍ التحقق...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>دخول الإدارة</span>
                </>
              )}
            </button>

            <button
              id="cancel-admin-btn"
              type="button"
              onClick={onCancel}
              className="py-2.5 px-4 bg-amber-50 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-slate-950 dark:text-slate-300 border-2 border-black dark:border-slate-700 rounded-xl text-xs font-black transition-colors cursor-pointer text-center"
            >
              إلغاء والعودة
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
