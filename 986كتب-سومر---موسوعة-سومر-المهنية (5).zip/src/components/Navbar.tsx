import React, { useState, useRef, useEffect } from 'react';
import { 
  GraduationCap, 
  EllipsisVertical, 
  Unlock, 
  Cloud, 
  CloudOff, 
  Sun, 
  Moon, 
  RefreshCw, 
  Info, 
  Lock, 
  X,
  ShieldAlert,
  LogIn,
  UserCheck
} from 'lucide-react';
import { ActiveReadersBadge } from './ActiveReadersBadge';

interface NavbarProps {
  isAdmin: boolean;
  isCloudConnected?: boolean;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  onToggleAdmin: () => void;
  onOpenAdminAuth?: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  onOpenAbout: () => void;
  onHomeClick: () => void;
  currentDept?: string;
  currentStage?: string;
  currentUserEmail?: string | null;
  onOpenGoogleAuth?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  isAdmin,
  isCloudConnected = true,
  isDarkMode = false,
  onToggleDarkMode,
  onToggleAdmin,
  onOpenAdminAuth,
  onRefreshData,
  isRefreshing = false,
  onOpenAbout,
  onHomeClick,
  currentUserEmail,
  onOpenGoogleAuth
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const logoClicksRef = useRef<number[]>([]);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  // Logo click always navigates smoothly to home
  const handleLogoClick = () => {
    onHomeClick();
  };

  return (
    <header className="sticky top-0 z-40 bg-[#fffdf9]/95 dark:bg-slate-900/90 backdrop-blur-xl border-b-2 border-black dark:border-slate-800 shadow-xs transition-all duration-300">
      {/* Top Accent Strip */}
      <div className="h-[2.5px] w-full bg-gradient-to-r from-amber-500 via-yellow-400 via-amber-400 to-yellow-500 opacity-95" />

      <div className="max-w-6xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2 sm:gap-3">
        {/* Brand */}
        <button
          id="brand-logo-btn"
          onClick={handleLogoClick}
          className="flex items-center gap-2.5 text-right focus:outline-none group cursor-pointer select-none"
          title="الرئيسية"
        >
          <div className="relative">
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-500 to-amber-600 text-black border-2 border-black dark:border-transparent flex items-center justify-center shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform duration-200">
              <GraduationCap className="w-5 h-5 drop-shadow-xs" />
            </div>
          </div>
          <div className="flex flex-col text-right">
            <h1 className="text-base sm:text-lg font-black text-slate-950 dark:text-transparent dark:bg-gradient-to-r dark:from-teal-300 dark:via-emerald-400 dark:to-cyan-300 dark:bg-clip-text tracking-tight leading-none">
              كتب سومر
            </h1>
            <span className="text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-400 flex items-center gap-1 mt-0.5">
              <span>المكتبة المهنية</span>
              {isCloudConnected ? (
                <span className="inline-flex items-center gap-0.5 text-[9px] text-amber-950 dark:text-emerald-300 bg-amber-100 dark:bg-emerald-950/60 border border-black/20 dark:border-transparent px-1.5 py-0.2 rounded-md font-bold">
                  <Cloud className="w-2.5 h-2.5 text-amber-700 dark:text-emerald-400" />
                  <span>سحابة</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-0.5 text-[9px] text-slate-800 dark:text-slate-400 bg-amber-50 dark:bg-slate-800 border border-black/20 dark:border-transparent px-1.5 py-0.2 rounded-md font-bold">
                  <CloudOff className="w-2.5 h-2.5 text-slate-500" />
                  <span>محلي</span>
                </span>
              )}
            </span>
          </div>
        </button>

        {/* Actions & Status */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Day / Night Theme Toggle Button */}
          {onToggleDarkMode && (
            <button
              id="dark-mode-toggle-btn"
              onClick={onToggleDarkMode}
              className="p-2 sm:p-2.5 rounded-xl bg-amber-50 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-slate-950 dark:text-amber-300 border-2 border-black dark:border-slate-700 flex items-center justify-center transition-all cursor-pointer shadow-xs"
              title={isDarkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
            >
              {isDarkMode ? (
                <Sun className="w-4 h-4 text-amber-400 animate-spin [animation-duration:12s]" />
              ) : (
                <Moon className="w-4 h-4 text-slate-950" />
              )}
            </button>
          )}

          {/* Admin Mode Badge & Toggle - Only shown when in admin mode */}
          {isAdmin && (
            <div className="flex items-center gap-1 bg-amber-100 dark:bg-amber-950/50 border-2 border-black dark:border-amber-800/60 text-amber-950 dark:text-amber-200 px-2 py-1 rounded-xl text-[11px] font-black shadow-xs">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-600"></span>
              </span>
              <Unlock className="w-3 h-3 text-amber-900 dark:text-amber-400" />
              <span className="hidden xs:inline">المسؤول</span>
              <button
                id="exit-admin-btn"
                onClick={onToggleAdmin}
                className="bg-white dark:bg-slate-900 text-amber-950 dark:text-amber-200 hover:bg-amber-200 dark:hover:bg-slate-800 border-2 border-black dark:border-amber-700 px-1.5 py-0.5 rounded-md font-black text-[10px] transition-colors cursor-pointer"
              >
                خروج
              </button>
            </div>
          )}

          {/* Active Students & Book Opens Live Statistic (100% Genuine, placed next to 3 dots) */}
          <ActiveReadersBadge />

          {/* Three dots / Menu Popover */}
          <div className="relative" ref={menuRef}>
            <button
              id="about-app-btn"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-amber-50 hover:bg-amber-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-950 dark:text-slate-200 border-2 border-black dark:border-slate-700 flex items-center justify-center transition-colors cursor-pointer shadow-xs"
              title="القائمة والخيارات"
            >
              <EllipsisVertical className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-72 sm:w-80 bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3.5 py-1.5 border-b border-black/10 dark:border-slate-800 flex items-center justify-between text-xs font-black text-slate-700 dark:text-slate-500">
                  <span>خيارات التطبيق</span>
                  <button
                    onClick={() => setIsMenuOpen(false)}
                    className="p-1 text-slate-500 hover:text-black dark:text-slate-400 dark:hover:text-slate-200 rounded-md cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Dedication Banner - هذا العمل من قبل الطالب سجاد محمد وهو إهداء لمدرسة سومر المهنية */}
                <div className="m-2 p-3 bg-gradient-to-br from-amber-100/90 via-yellow-50 to-amber-50 dark:from-slate-800 dark:via-slate-800/90 dark:to-slate-800 border-2 border-black dark:border-teal-700/60 rounded-xl text-right shadow-xs">
                  <div className="flex items-center gap-1.5 text-amber-950 dark:text-teal-300 font-black text-xs mb-1">
                    <GraduationCap className="w-4 h-4 text-amber-700 dark:text-teal-400 shrink-0" />
                    <span>إهداء وتقدير</span>
                  </div>
                  <p className="text-[11.5px] leading-relaxed text-black dark:text-slate-200 font-semibold">
                    هذا العمل من قبل الطالب{' '}
                    <span className="font-extrabold text-amber-900 dark:text-teal-300 underline decoration-amber-500 decoration-1">
                      سجاد محمد
                    </span>{' '}
                    وهو إهداء لمدرسة سومر المهنية.
                  </p>
                </div>

                <div className="p-1 space-y-0.5">
                  {onOpenGoogleAuth && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        onOpenGoogleAuth();
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        {currentUserEmail ? (
                          <UserCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                        ) : (
                          <LogIn className="w-4 h-4 text-amber-700 dark:text-teal-400" />
                        )}
                        <span>{currentUserEmail ? 'حسابي' : 'تسجيل الدخول / إنشاء حساب'}</span>
                      </div>
                      {currentUserEmail && (
                        <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 px-1.5 py-0.5 rounded font-mono truncate max-w-[90px]">
                          {currentUserEmail.split('@')[0]}
                        </span>
                      )}
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenAbout();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right"
                  >
                    <Info className="w-4 h-4 text-amber-700 dark:text-teal-400" />
                    <span>حول التطبيق والمطور</span>
                  </button>

                  {onRefreshData && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        onRefreshData();
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right"
                    >
                      <RefreshCw className={`w-4 h-4 text-amber-700 dark:text-teal-400 ${isRefreshing ? 'animate-spin' : ''}`} />
                      <span>تحديث الكتب من السحابة</span>
                    </button>
                  )}

                  {onToggleDarkMode && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        onToggleDarkMode();
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-right"
                    >
                      {isDarkMode ? (
                        <>
                          <Sun className="w-4 h-4 text-amber-500" />
                          <span>التحويل للوضع النهاري</span>
                        </>
                      ) : (
                        <>
                          <Moon className="w-4 h-4 text-slate-900" />
                          <span>التحويل للوضع الليلي</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
