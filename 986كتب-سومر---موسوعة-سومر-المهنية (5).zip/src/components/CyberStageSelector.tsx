import React from 'react';
import { motion } from 'framer-motion';
import { 
  Shield, 
  Cpu, 
  Lock, 
  ArrowRight, 
  BookOpen, 
  ChevronLeft,
  Award,
  Zap,
  CheckCircle2,
  Binary
} from 'lucide-react';
import { StageId, Book } from '../types';

interface CyberStageSelectorProps {
  books: Book[];
  onBackToDepts: () => void;
  onSelectStage: (stage: StageId) => void;
}

interface StageDetail {
  id: StageId;
  arabicNum: string;
  codename: string;
  securityLevel: string;
  description: string;
  topics: string[];
  protocol: string;
  badge?: string;
  accentColor: string;
  borderGlow: string;
  bgGlow: string;
}

const CYBER_STAGES: StageDetail[] = [
  {
    id: 'المرحلة الأولى',
    arabicNum: '01',
    codename: 'FOUNDATION_ZERO // التأسيس',
    securityLevel: 'LEVEL 1 - RECONNAISSANCE',
    description: 'المفاهيم التأسيسية لأمن الشبكات، معمارية الحواسيب، والبروتوكولات الأولية.',
    topics: ['أساسيات الحماية الرقمية', 'مبادئ التشفير المتماثل', 'معمارية الشبكات LAN/WAN'],
    protocol: 'PORT 8080 // ACTIVE',
    accentColor: 'text-emerald-700 dark:text-emerald-400',
    borderGlow: 'hover:border-emerald-500 hover:shadow-emerald-500/20',
    bgGlow: 'bg-emerald-100 dark:bg-emerald-950/30'
  },
  {
    id: 'المرحلة الثانية',
    arabicNum: '02',
    codename: 'CYBER_DEFENSE_CORE // الدفاع المتقدم',
    securityLevel: 'LEVEL 2 - SYSTEM HARDENING',
    description: 'حماية جدران الحماية (Firewalls)، كشف الاختراقات IDS/IPS، وهندسة التشفير.',
    topics: ['إدارة جدران الحماية والـ VPN', 'تحليل الثغرات البرمجية', 'أمن النظم وقواعد البيانات'],
    protocol: 'PORT 4430 // SECURE',
    accentColor: 'text-cyan-700 dark:text-cyan-400',
    borderGlow: 'hover:border-cyan-500 hover:shadow-cyan-500/20',
    bgGlow: 'bg-cyan-100 dark:bg-cyan-950/30'
  },
  {
    id: 'المرحلة الثالثة',
    arabicNum: '03',
    codename: 'ROOT_EXAM_APEX // المرحلة الوزارية',
    securityLevel: 'LEVEL 3 - ADVANCED OPS',
    description: 'المناهج الوزارية المنتهية، اختبار الاختراق الأخلاقي، والتحقيق الجنائي الرقمي (Forensics).',
    topics: ['التحقيق الجنائي الرقمي', 'اختبار الاختراق والتقييم الأمني', 'المناهج الوزارية المعتمدة'],
    protocol: 'PORT 9999 // CLASSIFIED',
    badge: 'الامتحان الوزاري النهائي',
    accentColor: 'text-amber-700 dark:text-amber-400',
    borderGlow: 'hover:border-amber-500 hover:shadow-amber-500/20',
    bgGlow: 'bg-amber-100 dark:bg-amber-950/30'
  }
];

export const CyberStageSelector: React.FC<CyberStageSelectorProps> = ({
  books,
  onBackToDepts,
  onSelectStage
}) => {
  return (
    <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-slate-950 border border-emerald-300 dark:border-emerald-500/30 shadow-xl dark:shadow-2xl dark:shadow-emerald-950/50 text-slate-900 dark:text-slate-100 font-sans transition-all duration-500">
      {/* Dynamic Cyber Grid & Scanline Background */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-20 bg-[linear-gradient(to_right,#059669_1px,transparent_1px),linear-gradient(to_bottom,#059669_1px,transparent_1px)] bg-[size:28px_28px]" 
      />
      <div 
        className="absolute inset-0 pointer-events-none bg-radial from-transparent via-slate-100/50 dark:via-slate-950/70 to-slate-100 dark:to-slate-950 opacity-90" 
      />

      {/* Futuristic Header / OS Top Window Bar */}
      <div className="relative z-10 border-b border-slate-200 dark:border-emerald-900/60 bg-slate-50/95 dark:bg-slate-900/90 backdrop-blur-md px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDepts}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-400 bg-white dark:bg-slate-800/80 hover:bg-emerald-50 dark:hover:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700/70 transition-all cursor-pointer group shadow-xs"
          >
            <ArrowRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform text-emerald-600 dark:text-emerald-400" />
            <span>خروج إلى كافة الأقسام</span>
          </button>
        </div>

        {/* Center OS Identity */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span className="text-emerald-700 dark:text-emerald-400 font-black tracking-wider">مناهج قسم الأمن السيبراني</span>
          <span className="text-slate-400 dark:text-slate-600">|</span>
          <span className="text-slate-600 dark:text-slate-400 hidden sm:inline">مدرسة سومر المهنية</span>
        </div>

        {/* Live Status Indicators */}
        <div className="flex items-center gap-2 text-xs font-mono text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <span className="hidden sm:inline">مزامنة سحابية نشطة</span>
        </div>
      </div>

      {/* Main Terminal Window Body */}
      <div className="relative z-10 p-5 sm:p-8 space-y-6">
        {/* Hero Section of Cybersecurity Dept */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-emerald-50 via-white to-emerald-50/70 dark:from-emerald-950/40 dark:via-slate-900/60 dark:to-cyan-950/30 border border-emerald-200 dark:border-emerald-500/20 shadow-sm dark:shadow-xl">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-500/20 border border-emerald-200 dark:border-emerald-500/40 text-emerald-800 dark:text-emerald-300 font-mono text-[11px] font-bold">
                CYBER SECURITY // الأمن السيبراني وحماية النظم
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
              <span>قسم الأمن السيبراني</span>
              <Lock className="w-6 h-6 text-emerald-600 dark:text-emerald-400 inline" />
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm max-w-2xl leading-relaxed">
              اختر المرحلة الدراسية المحددة للولوج إلى مناهج التشفير، الحماية الجنائية الرقمية، واختبار الاختراق المعتمدة وزارياً.
            </p>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end justify-between border-t sm:border-t-0 sm:border-r border-slate-200 dark:border-slate-800 pt-3 sm:pt-0 sm:pr-6 gap-2">
            <div className="text-right">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">الكتب المتوفرة للقسم</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400">
                {books.filter((b) => b.dept === 'الأمن السيبراني').length} كتب ومناهج
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>متاح للقراءة والتحميل</span>
            </div>
          </div>
        </div>

        {/* 3 Cyber Stage Cards (The System Levels) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-mono font-bold text-slate-700 dark:text-slate-400 tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>SELECT PROTOCOL LEVEL // تحديد المرحلة الدراسية:</span>
            </h3>
            <span className="text-[11px] font-mono text-emerald-700 dark:text-emerald-500/80">3 PROTOCOLS LOADED</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {CYBER_STAGES.map((st, sIdx) => {
              const stageBooks = books.filter(
                (b) => b.dept === 'الأمن السيبراني' && b.stage === st.id
              );

              return (
                <motion.div
                  key={st.id}
                  id={`cyber-stage-card-${st.id}`}
                  onClick={() => onSelectStage(st.id)}
                  whileHover={{
                    scale: 1.025,
                    y: -4,
                    boxShadow: '0 0 30px rgba(16, 185, 129, 0.25)'
                  }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                  className={`group relative rounded-2xl bg-white dark:bg-slate-900/90 border-2 border-slate-200 dark:border-slate-800 ${st.borderGlow} p-6 flex flex-col justify-between shadow-md dark:shadow-xl cursor-pointer overflow-hidden transition-colors duration-300`}
                >
                  {/* Digital Data Signal Beam traveling along top edge */}
                  <motion.div
                    className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-emerald-500 dark:via-emerald-400 to-transparent pointer-events-none"
                    animate={{
                      x: ['-100%', '100%'],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2.5,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.4
                    }}
                  />

                  {/* Subtle Scanning Grid Line for Cyber Data Pulse */}
                  <motion.div
                    className="absolute inset-x-0 h-10 bg-gradient-to-b from-emerald-500/0 via-emerald-500/5 to-emerald-500/0 pointer-events-none"
                    animate={{
                      top: ['-20%', '120%']
                    }}
                    transition={{
                      duration: 3.5,
                      repeat: Infinity,
                      ease: 'linear',
                      delay: sIdx * 0.6
                    }}
                  />

                  {/* Glowing background accent with Framer Motion hover response */}
                  <motion.div
                    className={`absolute -right-16 -top-16 w-36 h-36 ${st.bgGlow} rounded-full blur-2xl pointer-events-none opacity-40 dark:opacity-100`}
                    animate={{
                      scale: [1, 1.25, 1],
                      opacity: [0.35, 0.6, 0.35]
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: 'easeInOut',
                      delay: sIdx * 0.5
                    }}
                  />

                  {/* Card Header with Hex/Codename */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-mono text-[10px] text-slate-700 dark:text-slate-400 border border-slate-200 dark:border-slate-800 px-2 py-0.5 rounded bg-slate-100/80 dark:bg-black/50 flex items-center gap-1.5">
                        <motion.span
                          className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400"
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ duration: 1.2, repeat: Infinity, delay: sIdx * 0.2 }}
                        />
                        <span>{st.protocol}</span>
                      </span>
                      {st.badge && (
                        <span className="inline-flex items-center gap-1 bg-amber-100 dark:bg-amber-500/20 border border-amber-200 dark:border-amber-500/40 text-amber-800 dark:text-amber-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono">
                          <Award className="w-3 h-3" />
                          <span>{st.badge}</span>
                        </span>
                      )}
                    </div>

                    {/* Level Number & Name with Concentric Pulse Ring */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative">
                        <motion.div
                          className="absolute -inset-1 rounded-xl bg-emerald-400/20 blur-xs pointer-events-none"
                          animate={{
                            scale: [1, 1.15, 1],
                            opacity: [0.4, 0.9, 0.4]
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: 'easeInOut',
                            delay: sIdx * 0.3
                          }}
                        />
                        <div className={`relative w-12 h-12 rounded-xl bg-slate-50 dark:bg-black/70 border border-slate-200 dark:border-slate-700/90 flex items-center justify-center font-mono font-black text-lg ${st.accentColor} group-hover:border-current group-hover:shadow-md transition-all`}>
                          {st.arabicNum}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-base font-black text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                          {st.id}
                        </h4>
                        <span className="font-mono text-[10px] text-emerald-700 dark:text-slate-400 block tracking-tight">
                          {st.codename}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                      {st.description}
                    </p>

                    {/* Key Topics pill list */}
                    <div className="space-y-1.5 mb-5 border-t border-slate-200 dark:border-slate-800/80 pt-3">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">
                        محاور المنهج:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {st.topics.map((top, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[10px] bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700/50 flex items-center gap-1 font-mono"
                          >
                            <span className="w-1 h-1 rounded-full bg-emerald-500 dark:bg-emerald-400" />
                            <span>{top}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer action button */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800/90 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-mono text-slate-600 dark:text-slate-300">
                      <BookOpen className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span className="font-bold text-slate-900 dark:text-white">{stageBooks.length}</span>
                      <span className="text-slate-500">كتب متاحة</span>
                    </div>

                    <div className={`flex items-center gap-1.5 text-xs font-mono font-bold ${st.accentColor} group-hover:translate-x-[-4px] transition-transform`}>
                      <span>دخول النظام</span>
                      <ChevronLeft className="w-4 h-4" />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Footer Terminal Note */}
        <div className="bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-pulse" />
            <span>نظام الربط السحابي معتمد ومشفر بالكامل مع خوادم Firebase الموثقة.</span>
          </div>
          <span className="text-[11px] text-emerald-700 dark:text-emerald-500/90 font-bold">
            CYBER_DEFENSE_LAB // SUMER
          </span>
        </div>
      </div>
    </div>
  );
};
