import React, { useState } from 'react';
import { 
  ArrowRight, 
  FileText, 
  Eye, 
  Download, 
  Trash2, 
  Search, 
  Copy, 
  Check, 
  PlusCircle, 
  FolderOpen,
  Share2,
  ExternalLink,
  Heart
} from 'lucide-react';
import { Book, DepartmentId, StageId } from '../types';

interface BooksViewProps {
  currentDept: DepartmentId;
  currentStage: StageId;
  books: Book[];
  isAdmin: boolean;
  onBackToStages: () => void;
  onReadBook: (book: Book) => void;
  onDeleteBook: (id: string) => Promise<boolean>;
  onOpenAdmin: () => void;
  favoriteIds?: string[];
  onToggleFavorite?: (bookId: string) => void;
}

export const BooksView: React.FC<BooksViewProps> = ({
  currentDept,
  currentStage,
  books,
  isAdmin,
  onBackToStages,
  onReadBook,
  onDeleteBook,
  onOpenAdmin,
  favoriteIds = [],
  onToggleFavorite = (_bookId: string) => {}
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [bookToDelete, setBookToDelete] = useState<Book | null>(null);

  // Filter by dept & stage
  const stageBooks = books.filter(
    (b) => b.dept === currentDept && b.stage === currentStage
  );

  // Filter by search query
  const filteredBooks = stageBooks.filter((b) =>
    b.title.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const handleCopyLink = (book: Book) => {
    // If relative URL like /uploads/..., make it absolute with current origin
    const absoluteUrl = book.url.startsWith('http')
      ? book.url
      : `${window.location.origin}${book.url}`;
    
    navigator.clipboard.writeText(absoluteUrl);
    setCopiedId(book.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (book: Book) => {
    const link = document.createElement('a');
    link.href = book.url;
    link.download = `${book.title}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = (book: Book) => {
    setBookToDelete(book);
  };

  const confirmDeleteBook = async () => {
    if (!bookToDelete) return;
    const target = bookToDelete;
    setBookToDelete(null);
    setDeletingId(target.id);
    try {
      await onDeleteBook(target.id);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <section className="space-y-6">
      {/* Top Header & Breadcrumbs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#fffdf9] dark:bg-slate-900 p-4 rounded-2xl border-2 border-black dark:border-slate-800 shadow-[0_2px_10px_rgba(0,0,0,0.05)]">
        <button
          id="back-to-stages-btn"
          onClick={onBackToStages}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-black text-slate-950 dark:text-slate-300 hover:text-amber-800 dark:hover:text-teal-400 transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4 text-amber-700 dark:text-teal-400" />
          <span>رجوع إلى المراحل الدراسية</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <span className="bg-amber-100 dark:bg-slate-800 border-2 border-black dark:border-transparent text-slate-950 dark:text-slate-200 text-xs font-black px-3 py-1 rounded-xl shadow-2xs">
            {currentDept}
          </span>
          <span className="text-black dark:text-slate-600 font-bold">/</span>
          <span className="bg-amber-200 dark:bg-teal-950/60 border-2 border-black dark:border-teal-800 text-slate-950 dark:text-teal-300 text-xs font-black px-3 py-1 rounded-xl shadow-2xs">
            {currentStage}
          </span>
        </div>
      </div>

      {/* Search & Meta Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <Search className="w-4 h-4 text-amber-600 dark:text-slate-500 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="search-books-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن اسم الكتاب أو المنهج..."
            className="w-full pr-10 pl-4 py-2.5 bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 focus:border-amber-500 dark:focus:border-teal-400 focus:ring-2 focus:ring-amber-400/20 text-slate-950 dark:text-slate-100 rounded-xl text-xs sm:text-sm font-bold outline-none shadow-xs placeholder:text-slate-500"
          />
        </div>

        {isAdmin && (
          <button
            id="add-book-cta-btn"
            onClick={onOpenAdmin}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black border-2 border-black dark:bg-teal-700 dark:text-white rounded-xl text-xs sm:text-sm font-black shadow-xs hover:from-amber-500 hover:to-yellow-500 transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>إضافة كتاب جديد لهذا القسم</span>
          </button>
        )}
      </div>

      {/* Books Grid or Empty State */}
      {filteredBooks.length === 0 ? (
        <div className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 mx-auto flex items-center justify-center">
            <FolderOpen className="w-8 h-8" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-lg font-black text-slate-800 dark:text-slate-100">
              {searchQuery ? 'لا توجد نتائج مطابقة لبحثك' : 'لا توجد كتب مضافة حتى الآن لهذا القسم والمرحلة'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {searchQuery
                ? 'جرب البحث بكلمات أخرى أو امسح شريط البحث.'
                : isAdmin
                  ? 'يمكنك إضافة ونشر كتب الـ PDF الآن من خلال استمارة الإدارة أعلاه.'
                  : 'سيتم نشر وتوفير المناهج والكتب التخصصية لهذا القسم قريباً عبر المنصة.'}
            </p>
          </div>
          {isAdmin && !searchQuery && (
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-2 px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>إضافة كتاب جديد الآن</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredBooks.map((book) => {
            const isCopied = copiedId === book.id;
            const isDeleting = deletingId === book.id;

            return (
              <div
                id={`book-card-${book.id}`}
                key={book.id}
                className="bg-[#fffdf9] dark:bg-slate-900 border-2 border-black dark:border-slate-800 rounded-2xl p-5 shadow-[0_4px_16px_rgba(0,0,0,0.06),0_1px_4px_rgba(217,119,6,0.12)] hover:shadow-[0_8px_24px_rgba(217,119,6,0.22)] hover:border-black transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Top info */}
                  <div className="flex items-start gap-3.5 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-rose-950/40 border-2 border-black dark:border-rose-900/60 text-amber-950 dark:text-rose-400 flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                      <FileText className="w-6 h-6 text-black dark:text-rose-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm sm:text-base font-black text-slate-950 dark:text-slate-100 leading-snug mb-1 truncate">
                        {book.title}
                      </h4>
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                        <span className="bg-amber-100 dark:bg-teal-950/60 text-amber-950 dark:text-teal-300 border border-black/30 dark:border-transparent font-bold px-2 py-0.5 rounded-md">
                          {book.stage}
                        </span>
                        {book.fileSize && (
                          <span className="text-slate-600 dark:text-slate-500 font-bold">
                            {(book.fileSize / (1024 * 1024)).toFixed(1)} MB
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 border-t-2 border-black/10 dark:border-slate-800 flex items-center gap-2">
                  {/* Read PDF Button */}
                  <button
                    id={`read-book-btn-${book.id}`}
                    onClick={() => onReadBook(book)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black border-2 border-black dark:border-transparent dark:bg-teal-700 dark:text-white rounded-xl text-xs font-black shadow-xs hover:from-amber-500 hover:to-yellow-500 transition-colors cursor-pointer"
                    title="قراءة الكتاب في قارئ PDF"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>قراءة</span>
                  </button>

                  {/* Download Button */}
                  <button
                    id={`download-book-btn-${book.id}`}
                    onClick={() => handleDownload(book)}
                    className="p-2 bg-amber-50 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-black dark:text-slate-200 border-2 border-black dark:border-transparent rounded-xl text-xs font-black transition-colors cursor-pointer"
                    title="تحميل ملف الـ PDF"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  {/* Favorite Toggle Button */}
                  <button
                    id={`fav-book-btn-${book.id}`}
                    onClick={() => onToggleFavorite(book.id)}
                    className={`p-2 rounded-xl text-xs font-black border-2 transition-colors cursor-pointer ${
                      favoriteIds.includes(book.id)
                        ? 'bg-rose-100 dark:bg-rose-950/70 text-rose-600 border-black dark:border-transparent'
                        : 'bg-amber-50 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-slate-600 hover:text-rose-500 border-black dark:border-transparent'
                    }`}
                    title={favoriteIds.includes(book.id) ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                  >
                    <Heart className={`w-4 h-4 ${favoriteIds.includes(book.id) ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>

                  {/* Copy Link Button */}
                  <button
                    id={`copy-book-btn-${book.id}`}
                    onClick={() => handleCopyLink(book)}
                    className={`p-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      isCopied
                        ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300'
                        : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
                    }`}
                    title="نسخ الرابط لمشاركته"
                  >
                    {isCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>

                  {/* Delete Button (if admin) */}
                  {isAdmin && (
                    <button
                      id={`delete-book-btn-${book.id}`}
                      onClick={() => handleDelete(book)}
                      disabled={isDeleting}
                      className="p-2 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
                      title="حذف الكتاب من الخادم"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {/* Custom Confirmation Modal for Deleting Books */}
      {bookToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border-2 border-rose-500 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 text-right">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="text-base sm:text-lg font-black text-slate-950 dark:text-white">
                تأكيد حذف الكتاب
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-bold leading-relaxed">
                هل أنت متأكد من حذف كتاب <span className="text-rose-600 font-black">"{bookToDelete.title}"</span> من المنصة؟
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={confirmDeleteBook}
                className="flex-1 py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-black transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Trash2 className="w-4 h-4" />
                <span>نعم، احذف الكتاب</span>
              </button>

              <button
                type="button"
                onClick={() => setBookToDelete(null)}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer"
              >
                <span>إلغاء</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
