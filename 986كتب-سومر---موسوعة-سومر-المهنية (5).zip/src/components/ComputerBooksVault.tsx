import React, { useState } from 'react';
import { 
  ArrowRight, 
  Eye, 
  Download, 
  Trash2, 
  Search, 
  Copy, 
  Check, 
  Cpu, 
  CircuitBoard,
  Layers,
  HardDrive
} from 'lucide-react';
import { Book, StageId } from '../types';

interface ComputerBooksVaultProps {
  currentStage: StageId;
  books: Book[];
  isAdmin: boolean;
  onBackToStages: () => void;
  onReadBook: (book: Book) => void;
  onDeleteBook: (id: string) => Promise<boolean>;
  onOpenAdmin: () => void;
}

export const ComputerBooksVault: React.FC<ComputerBooksVaultProps> = ({
  currentStage,
  books,
  isAdmin,
  onBackToStages,
  onReadBook,
  onDeleteBook,
  onOpenAdmin
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Books filtered to Computer dept + current stage
  const stageBooks = books.filter(
    (b) => b.dept === 'الحاسبات' && b.stage === currentStage
  );

  const filteredBooks = stageBooks.filter((b) =>
    b.title.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const handleCopyLink = (book: Book) => {
    const absoluteUrl = book.url.startsWith('http')
      ? book.url
      : `${window.location.origin}${book.url}`;
    
    navigator.clipboard.writeText(absoluteUrl);
    setCopiedId(book.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (book: Book) => {
    const link = document.createElement('a');
    link.href = book.url;
    link.download = `${book.title}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async (book: Book) => {
    if (confirm(`هل أنت متأكد من رغبتك بحذف كتاب "${book.title}"؟ سيتم حذفه من كافة المتصفحات.`)) {
      setDeletingId(book.id);
      await onDeleteBook(book.id);
      setDeletingId(null);
    }
  };

  return (
    <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-slate-950 border-2 border-indigo-200 dark:border-indigo-500/60 shadow-xl dark:shadow-2xl dark:shadow-indigo-950/50 text-slate-900 dark:text-slate-100 font-sans transition-all duration-500">
      {/* Motherboard circuit background pattern */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-20 bg-[linear-gradient(to_right,#6366f1_1px,transparent_1px),linear-gradient(to_bottom,#6366f1_1px,transparent_1px)] bg-[size:24px_24px]" 
      />
      <div 
        className="absolute inset-0 pointer-events-none bg-radial from-transparent via-slate-100/50 dark:via-slate-950/70 to-slate-100 dark:to-slate-950 opacity-90" 
      />

      {/* Control Top Bar */}
      <div className="relative z-10 border-b border-slate-200 dark:border-indigo-900/60 bg-slate-50/95 dark:bg-slate-900/90 backdrop-blur-md px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 pl-2 border-l border-slate-300 dark:border-slate-700">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 dark:bg-indigo-400 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 dark:bg-cyan-400 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500 dark:bg-purple-400 inline-block" />
          </div>

          <button
            onClick={onBackToStages}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 hover:text-indigo-700 dark:hover:text-indigo-300 bg-white dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-slate-750 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 transition-all cursor-pointer group shadow-xs"
          >
            <ArrowRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform text-indigo-600 dark:text-indigo-400" />
            <span>رجوع إلى مستويات عتاد الحاسوب</span>
          </button>
        </div>

        {/* Center Breadcrumb */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1">
            <Cpu className="w-3.5 h-3.5" />
            <span>COMPUTER_LIBRARY</span>
          </span>
          <span className="text-slate-400 dark:text-slate-600">/</span>
          <span className="text-slate-700 dark:text-slate-300 font-bold">قسم الحاسبات</span>
          <span className="text-slate-400 dark:text-slate-600">/</span>
          <span className="text-indigo-700 dark:text-indigo-300 font-bold bg-indigo-100 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-800/80 px-2 py-0.5 rounded">
            {currentStage}
          </span>
        </div>

        {/* Right Status */}
        <div className="flex items-center gap-2 font-mono text-[11px] text-indigo-600 dark:text-indigo-400">
          <CircuitBoard className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <span className="hidden sm:inline">BUS_READY</span>
        </div>
      </div>

      {/* Main Body */}
      <div className="relative z-10 p-5 sm:p-8 space-y-6">
        
        {/* Header Banner */}
        <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-indigo-50 via-white to-purple-50 dark:from-slate-900 dark:via-indigo-950/50 dark:to-slate-900 border border-indigo-200 dark:border-indigo-500/40 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm dark:shadow-xl">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-500/20 border border-indigo-200 dark:border-indigo-500/50 text-indigo-800 dark:text-indigo-300 font-mono text-[11px] font-bold flex items-center gap-1.5">
                <CircuitBoard className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                <span>HARDWARE ARCHIVES // {currentStage}</span>
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                [x86-64 / ARM / NETWORKS]
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <span>خزينة كتب ومناهج قسم الحاسبات</span>
              <span className="text-indigo-500 text-xl">💻</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed">
              جميع الكتب المقررة لـ {currentStage} في صيانة الحواسيب، معمارية المعالجات، الشبكات، والبرمجيات متاحة للقراءة والتحميل الفوري.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl px-4 py-3 text-right shadow-xs dark:shadow-inner">
              <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 block">CATALOGED MANUALS</span>
              <span className="text-xl font-mono font-black text-indigo-600 dark:text-indigo-400">
                {stageBooks.length} كتب ومناهج
              </span>
            </div>
          </div>
        </div>

        {/* Search & Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-500 dark:text-indigo-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="البحث في كتب الحاسبات، الصيانة، والمعمارية..."
              className="w-full pl-4 pr-10 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 focus:border-indigo-500 dark:focus:border-indigo-400 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 outline-none transition-all font-mono"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 font-mono"
              >
                [مسح]
              </button>
            )}
          </div>

          {isAdmin && (
            <button
              onClick={onOpenAdmin}
              className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs px-4 py-2.5 rounded-xl shadow-md dark:shadow-lg dark:shadow-indigo-950/40 transition-all cursor-pointer font-mono"
            >
              <Cpu className="w-4 h-4" />
              <span>[+] إضافة ونشر كتاب حاسبات جديد</span>
            </button>
          )}
        </div>

        {/* Books Grid */}
        {filteredBooks.length === 0 ? (
          <div className="bg-slate-50 dark:bg-slate-950/70 border-2 border-dashed border-slate-300 dark:border-slate-800 rounded-2xl p-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-center mx-auto text-indigo-600 dark:text-indigo-400 shadow-sm">
              <Cpu className="w-8 h-8 animate-pulse" />
            </div>
            <div className="space-y-1 font-mono">
              <h4 className="text-base font-black text-slate-800 dark:text-slate-200">
                NO COMPUTER MANUALS CATALOGED
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                {searchQuery
                  ? 'لا توجد نتائج تطابق استعلام البحث المدخل.'
                  : 'لم يتم إدراج كتب لهذه المرحلة بعد. يمكن للمسؤول إضافتها فوراً من لوحة الإدارة.'}
              </p>
            </div>
            {isAdmin && (
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-indigo-700 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-4 py-2 rounded-xl transition-colors cursor-pointer shadow-xs"
              >
                <span>فتح لوحة النشر وإضافة كتاب</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredBooks.map((book) => {
              const isDeleting = deletingId === book.id;
              const isCopied = copiedId === book.id;

              return (
                <div
                  key={book.id}
                  className="group relative rounded-2xl bg-white dark:bg-slate-900/90 border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-400 p-5 flex flex-col justify-between shadow-md dark:shadow-xl hover:shadow-indigo-500/20 dark:hover:shadow-indigo-950/40 transition-all duration-300 hover:-translate-y-1"
                >
                  {/* Silicon ambient glow */}
                  <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl pointer-events-none group-hover:bg-indigo-500/20 transition-all" />

                  <div>
                    {/* Top Tag & Delete */}
                    <div className="flex items-center justify-between mb-3.5">
                      <span className="font-mono text-[10px] text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-slate-950 border border-indigo-200 dark:border-slate-700 px-2.5 py-0.5 rounded-md flex items-center gap-1.5">
                        <Cpu className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                        <span>COMPUTER_DOC // PDF</span>
                      </span>

                      {isAdmin && (
                        <button
                          onClick={() => handleDelete(book)}
                          disabled={isDeleting}
                          className="text-rose-500 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 p-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                          title="حذف من النظام"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Book Title */}
                    <h3 className="text-base font-black text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-200 transition-colors mb-2 leading-snug">
                      {book.title}
                    </h3>

                    <div className="flex items-center gap-2 font-mono text-[11px] text-slate-500 dark:text-slate-400 mb-4">
                      <span>المرحلة الدراسية:</span>
                      <span className="text-indigo-600 dark:text-indigo-400 font-bold">{book.stage}</span>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800 font-mono">
                    {/* Primary Read Button */}
                    <button
                      onClick={() => onReadBook(book)}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer group-hover:scale-[1.02]"
                    >
                      <Eye className="w-4 h-4" />
                      <span>قراءة وتصفح الكتاب المباشر</span>
                    </button>

                    {/* Secondary Download / Copy */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleDownload(book)}
                        className="py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg text-[11px] font-bold border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        <span>تحميل</span>
                      </button>

                      <button
                        onClick={() => handleCopyLink(book)}
                        className="py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg text-[11px] font-bold border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                            <span className="text-emerald-600 dark:text-emerald-400">تم النسخ!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                            <span>نسخ الرابط</span>
                          </>
                        )}
                      </button>
                    </div>

                    {book.url && (
                      <a
                        href={book.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full text-center block text-[10px] text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-300 pt-1 transition-colors"
                      >
                        [فتح الرابط الأصلي في نافذة مستقلة ↗]
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footer Note */}
        <div className="border-t border-slate-200 dark:border-slate-800 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-500 dark:text-slate-400">
          <span>SUMER COMPUTER ARCHITECTURE VAULT // HIGH SPEED BUS</span>
          <span className="text-indigo-600 dark:text-indigo-400 font-bold">ALL TEXTBOOKS SAVED & SECURED IN CLOUD</span>
        </div>
      </div>
    </div>
  );
};
