import React from 'react';

interface IraqiFlagProps {
  className?: string;
  showBorder?: boolean;
}

/**
 * Official Flag of the Republic of Iraq
 * 3:2 ratio: Red (#CE1126), White (#FFFFFF) with green Takbir "الله أكبر", Black (#000000)
 */
export const IraqiFlag: React.FC<IraqiFlagProps> = ({ 
  className = "w-7 h-[18px] sm:w-8 sm:h-[20px]",
  showBorder = true
}) => {
  return (
    <div 
      className={`inline-flex items-center justify-center shrink-0 rounded-xs overflow-hidden select-none ${
        showBorder ? 'border border-black/30 dark:border-white/20 shadow-xs' : ''
      } ${className}`}
      title="علم جمهورية العراق (الله أكبر)"
    >
      <svg
        viewBox="0 0 900 600"
        className="w-full h-full object-cover"
        xmlns="http://www.w3.org/2000/svg"
        role="img"
        aria-label="علم العراق - الله أكبر"
      >
        {/* Top Stripe: Red */}
        <rect width="900" height="200" fill="#CE1126" />
        
        {/* Middle Stripe: White */}
        <rect y="200" width="900" height="200" fill="#FFFFFF" />
        
        {/* Bottom Stripe: Black */}
        <rect y="400" width="900" height="200" fill="#000000" />
        
        {/* Center: Takbir "الله أكبر" in traditional emerald green */}
        <g fill="#007A3D" textAnchor="middle">
          {/* Main bold calligraphy */}
          <text
            x="450"
            y="342"
            fontFamily="'Noto Kufi Arabic', 'Amiri', 'Traditional Arabic', 'Segoe UI', Tahoma, Arial, sans-serif"
            fontSize="136"
            fontWeight="900"
            letterSpacing="3"
            stroke="#007A3D"
            strokeWidth="3"
            paintOrder="stroke fill"
          >
            الله أكبر
          </text>
        </g>
      </svg>
    </div>
  );
};
