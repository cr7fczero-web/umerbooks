import React from 'react';
import { motion } from 'framer-motion';
import { 
  ChevronLeft, 
  BookOpen, 
  Cpu, 
  Radio, 
  CircuitBoard,
  Activity,
  Zap,
  Layers
} from 'lucide-react';

interface ElectronicsDepartmentCardProps {
  onSelect: () => void;
  booksCount: number;
}

export const ElectronicsDepartmentCard: React.FC<ElectronicsDepartmentCardProps> = ({
  onSelect,
  booksCount
}) => {
  return (
    <motion.div
      id="dept-card-إلكترونيك السيطرة والخزن"
      onClick={onSelect}
      whileHover={{
        scale: 1.025,
        y: -4,
        boxShadow: '0 0 35px rgba(20, 184, 166, 0.38)'
      }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
      className="group relative bg-gradient-to-b from-white via-teal-50/50 to-teal-100/40 dark:from-slate-950 dark:via-slate-900 dark:to-teal-950/80 border-2 border-teal-200 dark:border-teal-500/70 hover:border-teal-400 dark:hover:border-cyan-400 rounded-3xl p-6 flex flex-col justify-between shadow-lg shadow-teal-100/50 dark:shadow-xl dark:shadow-teal-950/40 cursor-pointer overflow-hidden transition-colors duration-300"
    >
      {/* Silicon Wafer & Transistor Micro-circuit Matrix Pattern */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10 dark:opacity-20 bg-[radial-gradient(#14b8a6_1px,transparent_1px)] [background-size:14px_14px]" 
      />

      {/* Gate Conduction & Oscilloscope Wave Signal Pulse */}
      <motion.div
        className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-teal-500 dark:via-cyan-400 to-transparent pointer-events-none"
        animate={{
          x: ['-100%', '100%'],
          opacity: [0, 1, 0]
        }}
        transition={{
          duration: 2.2,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />

      {/* Transistor Semiconductor Ambient Cyan/Teal Glow */}
      <motion.div
        className="absolute -top-10 -right-10 w-36 h-36 bg-teal-500/15 dark:bg-teal-500/25 rounded-full blur-2xl pointer-events-none"
        animate={{
          scale: [1, 1.25, 1],
          opacity: [0.3, 0.65, 0.3]
        }}
        transition={{
          duration: 3.2,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
      <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-cyan-600/10 dark:bg-cyan-600/20 rounded-full blur-xl pointer-events-none" />

      {/* Card Body */}
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          {/* Silicon Transistor BJT/MOSFET Emblem with Gate Pulse Ring */}
          <div className="relative">
            <motion.div
              className="absolute -inset-1 rounded-2xl bg-teal-500/20 dark:bg-teal-500/30 blur-xs pointer-events-none"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.4, 0.9, 0.4]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            />
            <div className="relative w-14 h-14 rounded-2xl bg-white dark:bg-slate-950 border-2 border-teal-200 dark:border-teal-500/80 flex items-center justify-center text-teal-600 dark:text-teal-400 shadow-md shadow-teal-100 dark:shadow-teal-950 group-hover:scale-110 group-hover:border-teal-400 dark:group-hover:border-cyan-300 group-hover:text-teal-700 dark:group-hover:text-cyan-200 transition-all">
              <CircuitBoard className="w-8 h-8 text-teal-600 dark:text-teal-400 group-hover:text-teal-700 dark:group-hover:text-cyan-300 animate-pulse" />
              <span className="absolute -bottom-1 -right-1 px-1 py-0.2 rounded-md bg-teal-100 dark:bg-teal-900 border border-teal-300 dark:border-teal-600/80 text-[7px] font-mono text-teal-800 dark:text-cyan-200 font-bold">
                MOSFET
              </span>
            </div>
          </div>

          <div className="flex flex-col items-end gap-1">
            <span className="font-mono text-[10px] text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/90 border border-teal-200 dark:border-teal-600/70 px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500 dark:bg-cyan-400 animate-ping" />
              <span>TRANSISTOR ARRAY // ACTIVE</span>
            </span>
            <span className="text-[11px] font-mono font-bold text-teal-700 dark:text-teal-300 flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>{booksCount} كتب ومناهج</span>
            </span>
          </div>
        </div>

        {/* Title Tag */}
        <div className="mb-2.5 bg-white/80 dark:bg-black/60 border border-teal-100 dark:border-teal-950/80 rounded-xl p-2.5 shadow-xs dark:shadow-inner">
          <div className="flex items-center justify-between text-[11px] font-mono text-teal-700 dark:text-teal-400 mb-1">
            <span className="flex items-center gap-1">
              <Activity className="w-3.5 h-3.5 text-teal-600 dark:text-cyan-400" />
              <span>الترانزستورات ومنظومات السيطرة</span>
            </span>
            <span className="text-slate-400 dark:text-slate-500 text-[10px]">BJT / FET / PLC</span>
          </div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-cyan-200 transition-colors flex items-center gap-1.5">
            <span>قسم إلكترونيك السيطرة والخزن</span>
          </h3>
        </div>

        <h4 className="text-xs font-mono font-bold text-teal-700 dark:text-teal-300/90 mb-2">
          الترانزستورات، مكبرات العمليات، وأنظمة PLC والخزن
        </h4>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
          مناهج العناصر الإلكترونية الدقيقة، أنظمة السيطرة التلقائية، المعالجات الدقيقة، وخلايا الذاكرة الرقمية.
        </p>

        {/* Transistor Bias & Logic Levels */}
        <div className="mt-3.5 py-1.5 px-3 rounded-xl bg-white/90 dark:bg-slate-950/90 border border-teal-100 dark:border-teal-900/60 text-[11px] font-mono text-slate-700 dark:text-slate-300 flex items-center justify-between shadow-xs dark:shadow-none">
          <div className="flex items-center gap-2">
            <span className="text-teal-700 dark:text-teal-400 font-bold flex items-center gap-1">
              <span>Vgs: 3.3V</span>
            </span>
            <span className="text-slate-300 dark:text-slate-700">|</span>
            <span className="text-cyan-600 dark:text-cyan-400 font-bold">NPN / PNP</span>
            <span className="text-slate-300 dark:text-slate-700">|</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">GAIN: x100</span>
          </div>
          <span className="text-teal-700 dark:text-teal-300 font-bold group-hover:text-teal-800 dark:group-hover:text-cyan-200">
            انحياز ⚡
          </span>
        </div>
      </div>

      {/* Card Footer Button */}
      <div className="relative z-10 mt-5 pt-3.5 border-t border-teal-100 dark:border-teal-950/80 flex items-center justify-between text-xs font-mono font-bold text-teal-700 dark:text-teal-400 group-hover:text-teal-800 dark:group-hover:text-cyan-200">
        <span className="flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
          <span>فحص دارات الترانزستور والكتب</span>
        </span>
        <div className="flex items-center gap-1 group-hover:translate-x-[-4px] transition-transform">
          <span>GATE</span>
          <ChevronLeft className="w-4 h-4 text-teal-600 dark:text-teal-400" />
        </div>
      </div>
    </motion.div>
  );
};
