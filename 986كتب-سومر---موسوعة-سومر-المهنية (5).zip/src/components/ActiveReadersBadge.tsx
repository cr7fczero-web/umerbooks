import React, { useState, useEffect, useRef } from 'react';
import { Users, BookOpen, Clock, Activity, ChevronDown } from 'lucide-react';
import { subscribeToReaderStats, ReaderStats } from '../lib/cloudStats';

export const ActiveReadersBadge: React.FC = () => {
  const [stats, setStats] = useState<ReaderStats>({
    totalOpens: 0,
    activeStudents: 1,
    activePercentage: 100,
    lastUpdated: new Date().toISOString()
  });

  const [isOpen, setIsOpen] = useState(false);
  const [justUpdated, setJustUpdated] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = subscribeToReaderStats((newStats) => {
      setStats(newStats);
      setJustUpdated(true);
      const timer = setTimeout(() => setJustUpdated(false), 1500);
      return () => clearTimeout(timer);
    });

    return () => unsubscribe();
  }, []);

  // Close popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  return (
    <div className="relative" ref={popoverRef}>
      {/* Live Badge Trigger */}
      <button
        type="button"
        id="active-students-stat-btn"
        onClick={() => setIsOpen(!isOpen)}
        className={`group flex items-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl border-2 transition-all duration-300 cursor-pointer shadow-xs ${
          justUpdated
            ? 'bg-emerald-50 dark:bg-emerald-950/80 border-black dark:border-emerald-500 scale-105'
            : 'bg-amber-50/90 dark:bg-slate-800/90 hover:bg-amber-100 dark:hover:bg-slate-750 border-black dark:border-slate-700/80 text-slate-950 dark:text-white'
        }`}
        title="انقر لعرض تفاصيل إحصائية فتح الكتب والطلاب النشطين"
      >
        {/* Live Green Pulsing Indicator */}
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
        </span>

        {/* Active Readers Counter */}
        <div className="flex items-center gap-1.5 font-sans">
          <Users className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <div className="flex items-baseline gap-1">
            <span className="text-xs sm:text-sm font-black font-mono text-slate-900 dark:text-slate-100">
              {stats.activeStudents}
            </span>
            <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 hidden md:inline">
              طالباً نشطاً
            </span>
            <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 md:hidden">
              نشط
            </span>
          </div>
        </div>

        {/* Small chevron */}
        <ChevronDown 
          className={`w-3 h-3 text-slate-400 transition-transform duration-200 ${
            isOpen ? 'rotate-180 text-emerald-500' : 'group-hover:text-slate-600'
          }`} 
        />
      </button>

      {/* Popover Breakdown Dialog */}
      {isOpen && (
        <div 
          className="absolute left-0 sm:left-auto sm:right-0 mt-2 w-72 sm:w-80 bg-[#fffdf9] dark:bg-slate-900 rounded-2xl border-2 border-black dark:border-slate-700 p-4 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150 text-right font-sans"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-black/10 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
              <h4 className="text-xs font-black text-slate-950 dark:text-slate-100">
                إحصائيات المطالعة التفاعلية الحقيقية
              </h4>
            </div>
            <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-black/20 dark:border-emerald-800">
              عداد حقيقي مباشر
            </span>
          </div>

          {/* Stats Grid */}
          <div className="space-y-2.5">
            {/* 1. How many people opened a book */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-50/50 dark:bg-slate-800/70 border-2 border-black/80 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                  <BookOpen className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    كم شخص فتح كتاب
                  </p>
                  <p className="text-[10px] text-slate-400">
                    إجمالي مرات فتح وتصفح المناهج
                  </p>
                </div>
              </div>
              <span className="font-mono text-xs font-black text-slate-900 dark:text-white">
                {stats.totalOpens.toLocaleString('ar-IQ')}
              </span>
            </div>

            {/* 2. Active Students Count */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Users className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    عدد الطلاب النشطين
                  </p>
                  <p className="text-[10px] text-slate-400">
                    يقرؤون المناهج الدراسية حالياً
                  </p>
                </div>
              </div>
              <span className="font-mono text-xs font-black text-emerald-600 dark:text-emerald-400">
                {stats.activeStudents} طالب
              </span>
            </div>

            {/* 3. Activity Rate */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
                  <Activity className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    نسبة التفاعل اللحظي
                  </p>
                  <p className="text-[10px] text-slate-400">
                    معدل النشاط المستمر
                  </p>
                </div>
              </div>
              <span className="font-mono text-xs font-black text-cyan-600 dark:text-cyan-400">
                {stats.activePercentage}%
              </span>
            </div>
          </div>

          {/* Footer note: Updates every minute */}
          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 font-medium">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-500" />
              <span>تتحدث النسبة والمعدل كل دقيقة تلقائياً</span>
            </span>
            <span className="font-mono text-[9px] text-slate-400">
              ⏱️ 60s
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
